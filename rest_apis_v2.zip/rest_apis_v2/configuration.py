# 23 database credentials
host_23 = '172.16.130.23'
database_23 = 'TPLMaps'
port_23 = '5432'
username_23 = 'qgis.plugin'
password_23 = 'assigncity'
# 61 database credentials
host_61 = '172.16.14.61'
database_61 = 'TPLMaps'
port_61 = '6432'
username_61 = 'qgis.plugin'
password_61 = 'assigncity'
# Feature Indicators
pois = 1
roads = 2
cartography = 3
scale = 4
house = 5
# Mapping Layer To Feature
lyr_feat_mapping = {
    'pois': pois,
    'roads': roads,
    'carto': cartography,
    'scale': scale,
    'house': house,
}
# Level One Logs Mapping
l1_logs_mapping = {
    pois: 'poi_level_one_logs',
    roads: 'roads_level_one_logs',
    cartography: 'scale_carto_level_one_logs',
    scale: 'scale_carto_level_one_logs',
    house: 'house_level_one_logs',
}
# Error Message
unauthorized_error = {'Error': 'Invalid Token'}
no_token_req = "No Token Required"
token_req = "Token Required"
source_default = "No Source Provided"
