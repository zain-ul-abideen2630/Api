pois_distance_query = """{
	"_source":["name_displ"],
	"size" : 500,
    "query": {
        "bool" : {
            "must" : [{
                "match" : {
                	"name_displ" : {"query": "$1", "fuzziness": 2}
                }
            }],
            "filter" : {
                "geo_distance" : {
                    "distance" : "100m",
                    "location" : "$2"
                }
            }
        }
    }
}"""

pois_duplicate_names_query = """{
	"_source":["name_displ", "id"],
	"size" : 500,
    "query": {
        "bool" : {
            "must" : {
                "match_all" : {}
            },
            "filter" : {
                "geo_distance" : {
                    "distance" : "150m",
                    "location" : {
                        "lat" : $1,
                        "lon" : $2
                    }
                }
            }
        }
    }
}"""

water_body_intersection_check = """{
            "size":0,
			"_source" : ["name"],
            "query":{
                "bool": {
                    "must": {
                        "match_all": {}
                    },
                    "filter": [
                    	{
                    		"terms" : { "kind": ["water"]

                    		}
                    	},
                    	{
                        "geo_shape": {
                            "location": {
                                "shape": {
                                    "type": "point",
                                    "coordinates": [$1]
                                },
                                "relation": "CONTAINS"
                            }
                        }
                    }]
                }
            }
        }"""

nearest_road_intersection = """{
    "query":{
        "bool": {
            "must": {
                "match_all": {}
            },
            "filter": {
                "geo_shape": {
                    "location": {
                        "shape": $1,
                        "relation": "intersects"
                    }
                }
            }
        }
    }
}"""
