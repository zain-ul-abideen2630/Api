# rows = [{"id": 38601, "Surveyor": "Sharib Hussain", "city": "Karachi", "GPS POI": 0, "Date": "2019-07-11", "PlaceIT POI": 1, "PlaceIT Housing": 0, "Roads": 0, "SV Survey": 0, "area": "Korangi Creek,Ibrahim Hyderi", "GPS House": 0, "Grid ID": 262399}, {"id": 38562, "Surveyor": "Sharib Hussain", "city": "Karachi", "GPS POI": 0, "Date": "2019-07-10", "PlaceIT POI": 39, "PlaceIT Housing": 0, "Roads": 0, "SV Survey": 0, "area": "Korangi Creek,Ibrahim Hyderi", "GPS House": 0, "Grid ID": 262399}, {"id": 38515, "Surveyor": "Sharib Hussain", "city": "Karachi", "GPS POI": 0, "Date": "2019-07-09", "PlaceIT POI": 21, "PlaceIT Housing": 0, "Roads": 0, "SV Survey": 0, "area": "Korangi Creek,Ibrahim Hyderi", "GPS House": 0, "Grid ID": 262399}, {"id": 38507, "Surveyor": "Qasim Abbas", "city": "Karachi", "GPS POI": 0, "Date": "2019-07-09", "PlaceIT POI": 44, "PlaceIT Housing": 0, "Roads": 0, "SV Survey": 0, "area": "Korangi Creek,Ibrahim Hyderi", "GPS House": 0, "Grid ID": 262399}, {"id": 38566, "Surveyor": "Sharib Hussain", "city": "Karachi", "GPS POI": 0, "Date": "2019-07-10", "PlaceIT POI": 11, "PlaceIT Housing": 0, "Roads": 0, "SV Survey": 0, "area": "Ibrahim Hyderi", "GPS House": 0, "Grid ID": 262400}, {"id": 38516, "Surveyor": "Sharib Hussain", "city": "Karachi", "GPS POI": 0, "Date": "2019-07-09", "PlaceIT POI": 1, "PlaceIT Housing": 0, "Roads": 0, "SV Survey": 0, "area": "Ibrahim Hyderi", "GPS House": 0, "Grid ID": 262400}, {"id": 38509, "Surveyor": "Qasim Abbas", "city": "Karachi", "GPS POI": 0, "Date": "2019-07-09", "PlaceIT POI": 6, "PlaceIT Housing": 0, "Roads": 0, "SV Survey": 0, "area": "Ibrahim Hyderi", "GPS House": 0, "Grid ID": 262400}, {"id": 42597, "Surveyor": "Qasim Abbas/Sharib Hussain", "city": "Karachi", "GPS POI": 0, "Date": "2019-06-25", "PlaceIT POI": 0, "PlaceIT Housing": 0, "Roads": 0, "SV Survey": 843, "area": "Clifton,DHA", "GPS House": 0, "Grid ID": 264464}, {"id": 34998, "Surveyor": "Shaheryar Siddiqui", "city": "Karachi", "GPS POI": 0, "Date": "2019-03-25", "PlaceIT POI": 34, "PlaceIT Housing": 0, "Roads": 0, "SV Survey": 0, "area": "Clifton,DHA", "GPS House": 0, "Grid ID": 264464}, {"id": 32849, "Surveyor": "Sharib Hussain", "city": "Karachi", "GPS POI": 0, "Date": "2017-09-15", "PlaceIT POI": 37, "PlaceIT Housing": 0, "Roads": 0, "SV Survey": 0, "area": "Clifton,DHA", "GPS House": 0, "Grid ID": 264464}]


def find_indexes(p_list: list, value):
    return [i for i, val in enumerate(p_list) if val == value]


def data_corrector(data: list) -> list:
    output_list = []
    for row in data:

        if ',' in row['area']:

            areas = [record for record in row['area'].split(',')]
            for area in areas:
                rec_copy = row.copy()
                rec_copy['area'] = area
                output_list.append(rec_copy)
        else:
            output_list.append(row)
    return output_list


def grouper_id(data, employee):
    if employee == 'surveyor':
        gids = [gid["Grid ID"] for gid in data]
        out_data = []
        gid_dict = {}
        for gid in gids:
            if gid not in gid_dict.keys():
                gid_dict[gid] = find_indexes(gids, gid)

        for key in gid_dict.keys():
            standard_resp = {"city": "",
                             "priority": "",
                             "area": "",
                             "GPS POI": 0,
                             "Surveyor": "",
                             "SV Survey": 0,
                             "Grid ID": str(),
                             "id": 0,
                             "Roads": 0,
                             "PlaceIT POI": 0,
                             "Date": "",
                             "PlaceIT Housing": 0,
                             "GPS House": 0}

            standard_resp.update({'Grid ID': key})
            relevant_list = [item for index, item in enumerate(data) if index in gid_dict[key]]
            for item in relevant_list:
                if item['Surveyor'] not in standard_resp['Surveyor']:
                    standard_resp['Surveyor'] += item['Surveyor'] + ','
                if item['area'] not in standard_resp['area']:
                    standard_resp['area'] += item['area'] + ','
                if item['city'] not in standard_resp['city']:
                    standard_resp['city'] += item['city'] + ','
                if item['Date'] not in standard_resp['Date']:
                    standard_resp['Date'] += item['Date'] + ','
                if item['priority'] not in standard_resp['priority']:
                    standard_resp['priority'] += item['priority'] + ','

                standard_resp['Grid ID'] = item['Grid ID']
                standard_resp['GPS POI'] += item['GPS POI']
                standard_resp['Roads'] += item['Roads']
                standard_resp['PlaceIT POI'] += item['PlaceIT POI']
                standard_resp['GPS House'] += item['GPS House']
                standard_resp['PlaceIT Housing'] += item['PlaceIT Housing']
                standard_resp['id'] = item['id']
                standard_resp['SV Survey'] += item['SV Survey']
            out_data.append(standard_resp)
        return out_data

    else:
        gids = [gid["grid_id"] for gid in data]
        out_data = []
        gid_dict = {}
        for gid in gids:
            if gid not in gid_dict.keys():
                gid_dict[gid] = find_indexes(gids, gid)

        for key in gid_dict.keys():
            standard_resp = {"id": 0,
                             "priority": "",
                             "recorddate": "",
                             "poi_count": 0,
                             "road_count": 0,
                             "scale_count": 0,
                             "carto_count": 0,
                             "team": "",
                             "grid_id": str(),
                             "grid_priority": "",
                             "city": "",
                             "area": "",
                             "digitizer": "",
                             "house_count": 0,
                             "main_table_ids": [0]}

            standard_resp.update({'grid_id': key})
            relevant_list = [item for index, item in enumerate(data) if index in gid_dict[key]]
            for item in relevant_list:
                if item['digitizer'] not in standard_resp['digitizer']:
                    standard_resp['digitizer'] += item['digitizer'] + ','
                if item['recorddate'] not in standard_resp['recorddate']:
                    standard_resp['recorddate'] += item['recorddate'] + ','
                if item['area'] not in standard_resp['area']:
                    standard_resp['area'] += item['area'] + ','
                if item['city'] not in standard_resp['city']:
                    standard_resp['city'] += item['city'] + ','
                if item['priority'] not in standard_resp['priority']:
                    standard_resp['priority'] += item['priority'] + ','
                if item['team'] not in standard_resp['team']:
                    standard_resp['team'] += item['team'] + ','

                standard_resp['grid_id'] = item['grid_id']
                standard_resp['poi_count'] += item['poi_count']
                standard_resp['road_count'] += item['road_count']
                standard_resp['scale_count'] += item['scale_count']
                standard_resp['carto_count'] += item['carto_count']
                # standard_resp['team'] += item['team']
                standard_resp['id'] = item['id']
                standard_resp['grid_priority'] = item['grid_priority']
                standard_resp['house_count'] += item['house_count']
                standard_resp['main_table_ids'] = item['main_table_ids']
            out_data.append(standard_resp)
        return out_data


def grouper_date(data, employee):
    if employee == 'surveyor':
        gids = [gid["Date"] for gid in data]
        out_data = []
        gid_dict = {}
        for gid in gids:
            if gid not in gid_dict.keys():
                gid_dict[gid] = find_indexes(gids, gid)

        for key in gid_dict.keys():
            standard_resp = {"city": "",
                             "priority": "",
                             "area": "",
                             "GPS POI": 0,
                             "Surveyor": "",
                             "SV Survey": 0,
                             "Grid ID": str(),
                             "id": 0,
                             "Roads": 0,
                             "PlaceIT POI": 0,
                             "Date": "",
                             "PlaceIT Housing": 0,
                             "GPS House": 0}

            standard_resp.update({'Date': key})
            relevant_list = [item for index, item in enumerate(data) if index in gid_dict[key]]
            for item in relevant_list:
                if item['Surveyor'] not in standard_resp['Surveyor']:
                    standard_resp['Surveyor'] += item['Surveyor'] + ','
                if item['city'] not in standard_resp['city']:
                    standard_resp['city'] += item['city'] + ','
                if item['area'] not in standard_resp['area']:
                    standard_resp['area'] += item['area'] + ','
                if item['Date'] not in standard_resp['Date']:
                    standard_resp['Date'] = item['Date']
                if str(item['Grid ID']) not in standard_resp['Grid ID']:
                    standard_resp['Grid ID'] += str(item['Grid ID']) + ','
                if item['priority'] not in standard_resp['priority']:
                    standard_resp['priority'] += item['priority'] + ','

                standard_resp['GPS POI'] += item['GPS POI']
                standard_resp['SV Survey'] += item['SV Survey']
                standard_resp['id'] = item['id']
                standard_resp['Roads'] += item['Roads']
                standard_resp['PlaceIT POI'] += item['PlaceIT POI']
                standard_resp['GPS House'] += item['GPS House']
                standard_resp['PlaceIT Housing'] += item['PlaceIT Housing']
            out_data.append(standard_resp)
        return out_data

    else:
        gids = [gid["recorddate"] for gid in data]
        out_data = []
        gid_dict = {}
        for gid in gids:
            if gid not in gid_dict.keys():
                gid_dict[gid] = find_indexes(gids, gid)

        for key in gid_dict.keys():
            standard_resp = {
                             "id": 0,
                             "priority": "",
                             "recorddate": "",
                             "poi_count": 0,
                             "road_count": 0,
                             "scale_count": 0,
                             "carto_count": 0,
                             "team": "",
                             "grid_id": str(),
                             "grid_priority": "",
                             "city": "",
                             "area": "",
                             "digitizer": "",
                             "house_count": 0,
                             "main_table_ids": [0]}

            standard_resp.update({'recorddate': key})
            relevant_list = [item for index, item in enumerate(data) if index in gid_dict[key]]
            for item in relevant_list:
                if item['digitizer'] not in standard_resp['digitizer']:
                    standard_resp['digitizer'] += item['digitizer'] + ','
                if str(item['grid_id']) not in standard_resp['grid_id']:
                    standard_resp['grid_id'] += str(item['grid_id']) + ','
                if item['recorddate'] not in standard_resp['recorddate']:
                    standard_resp['recorddate'] = item['recorddate'] + ','

                if item['area'] not in standard_resp['area']:
                    standard_resp['area'] += item['area'] + ','
                if item['city'] not in standard_resp['city']:
                    standard_resp['city'] += item['city'] + ','
                if item['priority'] not in standard_resp['priority']:
                    standard_resp['priority'] += item['priority'] + ','
                if item['team'] not in standard_resp['team']:
                    standard_resp['team'] += item['team'] + ','

                standard_resp['poi_count'] += item['poi_count']
                standard_resp['road_count'] += item['road_count']
                standard_resp['scale_count'] += item['scale_count']
                standard_resp['carto_count'] += item['carto_count']
                # standard_resp['team'] = item['team']
                standard_resp['id'] = item['id']
                standard_resp['grid_priority'] = item['grid_priority']
                standard_resp['house_count'] += item['house_count']
                standard_resp['main_table_ids'] = item['main_table_ids']
            out_data.append(standard_resp)
        return out_data


def grouper_employee(data, employee):
    if employee == 'surveyor':
        gids = [gid["Surveyor"] for gid in data]
        out_data = []
        gid_dict = {}
        for gid in gids:
            if gid not in gid_dict.keys():
                gid_dict[gid] = find_indexes(gids, gid)

        for key in gid_dict.keys():
            standard_resp = {"city": "",
                             "priority": "",
                             "area": "",
                             "GPS POI": 0,
                             "Surveyor": "",
                             "SV Survey": 0,
                             "Grid ID": str(),
                             "id": 0,
                             "Roads": 0,
                             "PlaceIT POI": 0,
                             "Date": "",
                             "PlaceIT Housing": 0,
                             "GPS House": 0}

            standard_resp.update({'Surveyor': key})
            relevant_list = [item for index, item in enumerate(data) if index in gid_dict[key]]
            for item in relevant_list:
                if item['Surveyor'] not in standard_resp['Surveyor']:
                    standard_resp['Surveyor'] = item['Surveyor']
                if item['city'] not in standard_resp['city']:
                    standard_resp['city'] += item['city'] + ','
                if item['area'] not in standard_resp['area']:
                    standard_resp['area'] += item['area'] + ','
                if item['Date'] not in standard_resp['Date']:
                    standard_resp['Date'] += item['Date'] + ','
                if str(item['Grid ID']) not in standard_resp['Grid ID']:
                    standard_resp['Grid ID'] += str(item['Grid ID']) + ','
                if item['priority'] not in standard_resp['priority']:
                    standard_resp['priority'] += item['priority'] + ','

                standard_resp['GPS POI'] += item['GPS POI']
                standard_resp['SV Survey'] += item['SV Survey']
                standard_resp['id'] = item['id']
                standard_resp['Roads'] += item['Roads']
                standard_resp['PlaceIT POI'] += item['PlaceIT POI']
                standard_resp['GPS House'] += item['GPS House']
                standard_resp['PlaceIT Housing'] += item['PlaceIT Housing']

            out_data.append(standard_resp)
        return out_data
    else:
        gids = [gid["digitizer"] for gid in data]
        out_data = []
        gid_dict = {}
        for gid in gids:
            if gid not in gid_dict.keys():
                gid_dict[gid] = find_indexes(gids, gid)

        for key in gid_dict.keys():
            standard_resp = {"id": 0,
                             "priority": "",
                             "recorddate": "",
                             "poi_count": 0,
                             "road_count": 0,
                             "scale_count": 0,
                             "carto_count": 0,
                             "team": "",
                             "grid_id": str(),
                             "grid_priority": "",
                             "city": "",
                             "area": "",
                             "digitizer": "",
                             "house_count": 0,
                             "main_table_ids": [0]}

            standard_resp.update({'digitizer': key})
            relevant_list = [item for index, item in enumerate(data) if index in gid_dict[key]]
            for item in relevant_list:
                if item['digitizer'] not in standard_resp['digitizer']:
                    standard_resp['digitizer'] = item['digitizer'] + ','
                if str(item['grid_id']) not in standard_resp['grid_id']:
                    standard_resp['grid_id'] += str(item['grid_id']) + ','
                if item['recorddate'] not in standard_resp['recorddate']:
                    standard_resp['recorddate'] += item['recorddate'] + ','
                if item['area'] not in standard_resp['area']:
                    standard_resp['area'] += item['area'] + ','
                if item['city'] not in standard_resp['city']:
                    standard_resp['city'] += item['city'] + ','
                if item['priority'] not in standard_resp['priority']:
                    standard_resp['priority'] += item['priority'] + ','
                if item['team'] not in standard_resp['team']:
                    standard_resp['team'] += item['team'] + ','

                standard_resp['poi_count'] += item['poi_count']
                standard_resp['road_count'] += item['road_count']
                standard_resp['scale_count'] += item['scale_count']
                standard_resp['carto_count'] += item['carto_count']
                # standard_resp['team'] = item['team']
                standard_resp['id'] = item['id']
                standard_resp['grid_priority'] = item['grid_priority']
                standard_resp['house_count'] += item['house_count']
                standard_resp['main_table_ids'] = item['main_table_ids']
            out_data.append(standard_resp)
        return out_data


def grouper_city(data, employee):
    if employee == 'surveyor':
        gids = [gid["city"] for gid in data]
        out_data = []
        gid_dict = {}
        for gid in gids:
            if gid not in gid_dict.keys():
                gid_dict[gid] = find_indexes(gids, gid)

        for key in gid_dict.keys():
            standard_resp = {"city": "",
                             "priority": "",
                             "area": "",
                             "GPS POI": 0,
                             "Surveyor": "",
                             "SV Survey": 0,
                             "Grid ID": str(),
                             "id": 0,
                             "Roads": 0,
                             "PlaceIT POI": 0,
                             "Date": "",
                             "PlaceIT Housing": 0,
                             "GPS House": 0}

            standard_resp.update({'city': key})
            relevant_list = [item for index, item in enumerate(data) if index in gid_dict[key]]
            for item in relevant_list:
                if item['Surveyor'] not in standard_resp['Surveyor']:
                    standard_resp['Surveyor'] += item['Surveyor']
                if item['city'] not in standard_resp['city']:
                    standard_resp['city'] = item['city']
                if item['Date'] not in standard_resp['Date']:
                    standard_resp['Date'] += item['Date'] + ','
                if item['priority'] not in standard_resp['priority']:
                    standard_resp['priority'] += item['priority'] + ','

                if item['area'] not in standard_resp['area']:
                    standard_resp['area'] += item['area'] + ','
                if str(item['Grid ID']) not in standard_resp['Grid ID']:
                    standard_resp['Grid ID'] += str(item['Grid ID']) + ','
                standard_resp['GPS POI'] += item['GPS POI']
                standard_resp['SV Survey'] += item['SV Survey']
                standard_resp['id'] = item['id']
                standard_resp['Roads'] += item['Roads']
                standard_resp['PlaceIT POI'] += item['PlaceIT POI']
                standard_resp['GPS House'] += item['GPS House']
                standard_resp['PlaceIT Housing'] += item['PlaceIT Housing']

            out_data.append(standard_resp)
        return out_data
    else:
        gids = [gid["city"] for gid in data]
        out_data = []
        gid_dict = {}
        for gid in gids:
            if gid not in gid_dict.keys():
                gid_dict[gid] = find_indexes(gids, gid)

        for key in gid_dict.keys():
            standard_resp = {"id": 0,
                             "priority": "",
                             "recorddate": "",
                             "poi_count": 0,
                             "road_count": 0,
                             "scale_count": 0,
                             "carto_count": 0,
                             "team": "",
                             "grid_id": str(),
                             "grid_priority": "",
                             "city": "",
                             "area": "",
                             "digitizer": "",
                             "house_count": 0,
                             "main_table_ids": [0]}

            standard_resp.update({'city': key})
            relevant_list = [item for index, item in enumerate(data) if index in gid_dict[key]]
            for item in relevant_list:
                if item['digitizer'] not in standard_resp['digitizer']:
                    standard_resp['digitizer'] += item['digitizer'] + ','
                if str(item['grid_id']) not in standard_resp['grid_id']:
                    standard_resp['grid_id'] += str(item['grid_id']) + ','
                if item['recorddate'] not in standard_resp['recorddate']:
                    standard_resp['recorddate'] += item['recorddate'] + ','
                if item['area'] not in standard_resp['area']:
                    standard_resp['area'] += item['area'] + ','
                if item['city'] not in standard_resp['city']:
                    standard_resp['city'] = item['city'] + ','
                if item['priority'] not in standard_resp['priority']:
                    standard_resp['priority'] = item['priority'] + ','
                if item['team'] not in standard_resp['team']:
                    standard_resp['team'] += item['team'] + ','

                standard_resp['poi_count'] += item['poi_count']
                standard_resp['road_count'] += item['road_count']
                standard_resp['scale_count'] += item['scale_count']
                standard_resp['carto_count'] += item['carto_count']
                # standard_resp['team'] = item['team']
                standard_resp['id'] = item['id']
                standard_resp['grid_priority'] = item['grid_priority']
                standard_resp['house_count'] += item['house_count']
                standard_resp['main_table_ids'] = item['main_table_ids']
            out_data.append(standard_resp)
        return out_data


def grouper_area(data, employee):
    data = data_corrector(data)
    if employee == 'surveyor':
        gids = [gid["area"] for gid in data]
        out_data = []
        gid_dict = {}
        for gid in gids:
            if gid not in gid_dict.keys():
                gid_dict[gid] = find_indexes(gids, gid)

        for key in gid_dict.keys():
            standard_resp = {"city": "",
                             "priority": "",
                             "area": "",
                             "GPS POI": 0,
                             "Surveyor": "",
                             "SV Survey": 0,
                             "Grid ID": str(),
                             "id": 0,
                             "Roads": 0,
                             "PlaceIT POI": 0,
                             "Date": "",
                             "PlaceIT Housing": 0,
                             "GPS House": 0}

            standard_resp.update({'area': key})
            relevant_list = [item for index, item in enumerate(data) if index in gid_dict[key]]
            for item in relevant_list:
                if item['Surveyor'] not in standard_resp['Surveyor']:
                    standard_resp['Surveyor'] += item['Surveyor']
                if item['city'] not in standard_resp['city']:
                    standard_resp['city'] += item['city'] + ','
                if item['area'] not in standard_resp['area']:
                    standard_resp['area'] = item['area']
                if item['Date'] not in standard_resp['Date']:
                    standard_resp['Date'] += item['Date'] + ','
                if str(item['Grid ID']) not in standard_resp['Grid ID']:
                    standard_resp['Grid ID'] += str(item['Grid ID']) + ','
                if item['priority'] not in standard_resp['priority']:
                    standard_resp['priority'] += item['priority'] + ','

                standard_resp['GPS POI'] += item['GPS POI']
                standard_resp['SV Survey'] += item['SV Survey']
                standard_resp['id'] = item['id']
                standard_resp['Roads'] += item['Roads']
                standard_resp['PlaceIT POI'] += item['PlaceIT POI']
                standard_resp['GPS House'] += item['GPS House']
                standard_resp['PlaceIT Housing'] += item['PlaceIT Housing']

            out_data.append(standard_resp)
        return out_data
    else:
        gids = [gid["area"] for gid in data]
        out_data = []
        gid_dict = {}
        for gid in gids:
            if gid not in gid_dict.keys():
                gid_dict[gid] = find_indexes(gids, gid)

        for key in gid_dict.keys():
            standard_resp = {"id": 0,
                             "priority": "",
                             "recorddate": "",
                             "poi_count": 0,
                             "road_count": 0,
                             "scale_count": 0,
                             "carto_count": 0,
                             "team": "",
                             "grid_id": str(),
                             "grid_priority": "",
                             "city": "",
                             "area": "",
                             "digitizer": "",
                             "house_count": 0,
                             "main_table_ids": [0]}

            standard_resp.update({'area': key})
            relevant_list = [item for index, item in enumerate(data) if index in gid_dict[key]]
            for item in relevant_list:
                if item['digitizer'] not in standard_resp['digitizer']:
                    standard_resp['digitizer'] += item['digitizer'] + ','
                if str(item['grid_id']) not in standard_resp['grid_id']:
                    standard_resp['grid_id'] += str(item['grid_id']) + ','
                if item['recorddate'] not in standard_resp['recorddate']:
                    standard_resp['recorddate'] += item['recorddate'] + ','
                if item['area'] not in standard_resp['area']:
                    standard_resp['area'] = item['area']
                if item['city'] not in standard_resp['city']:
                    standard_resp['city'] += item['city'] + ','
                if item['priority'] not in standard_resp['priority']:
                    standard_resp['priority'] += item['priority'] + ','
                if item['team'] not in standard_resp['team']:
                    standard_resp['team'] += item['team'] + ','

                standard_resp['poi_count'] += item['poi_count']
                standard_resp['road_count'] += item['road_count']
                standard_resp['scale_count'] += item['scale_count']
                standard_resp['carto_count'] += item['carto_count']
                # standard_resp['team'] = item['team']
                standard_resp['id'] = item['id']
                standard_resp['grid_priority'] = item['grid_priority']
                standard_resp['house_count'] += item['house_count']
                standard_resp['main_table_ids'] = item['main_table_ids']
            out_data.append(standard_resp)
        return out_data


def grouper_priority(data, employee):
    data = data_corrector(data)

    if employee == 'surveyor':
        gids = [gid["priority"] for gid in data]
        out_data = []
        gid_dict = {}
        for gid in gids:
            if gid not in gid_dict.keys():
                gid_dict[gid] = find_indexes(gids, gid)

        for key in gid_dict.keys():
            standard_resp = {"city": "",
                             "priority": "",
                             "area": "",
                             "GPS POI": 0,
                             "Surveyor": "",
                             "SV Survey": 0,
                             "Grid ID": str(),
                             "id": 0,
                             "Roads": 0,
                             "PlaceIT POI": 0,
                             "Date": "",
                             "PlaceIT Housing": 0,
                             "GPS House": 0}

            standard_resp.update({'priority': key})
            relevant_list = [item for index, item in enumerate(data) if index in gid_dict[key]]
            for item in relevant_list:
                if item['Surveyor'] not in standard_resp['Surveyor']:
                    standard_resp['Surveyor'] += item['Surveyor'] + ','
                if item['city'] not in standard_resp['city']:
                    standard_resp['city'] += item['city'] + ','
                if item['area'] not in standard_resp['area']:
                    standard_resp['area'] += item['area'] + ','
                if item['Date'] not in standard_resp['Date']:
                    standard_resp['Date'] += item['Date'] + ','
                if str(item['Grid ID']) not in standard_resp['Grid ID']:
                    standard_resp['Grid ID'] += str(item['Grid ID']) + ','
                if item['priority'] not in standard_resp['priority']:
                    standard_resp['priority'] = item['priority']

                standard_resp['GPS POI'] += item['GPS POI']
                standard_resp['SV Survey'] += item['SV Survey']
                standard_resp['id'] = item['id']
                standard_resp['Roads'] += item['Roads']
                standard_resp['PlaceIT POI'] += item['PlaceIT POI']
                standard_resp['GPS House'] += item['GPS House']
                standard_resp['PlaceIT Housing'] += item['PlaceIT Housing']

            out_data.append(standard_resp)
        return out_data
    else:
        gids = [gid["priority"] for gid in data]
        out_data = []
        gid_dict = {}
        for gid in gids:
            if gid not in gid_dict.keys():
                gid_dict[gid] = find_indexes(gids, gid)

        for key in gid_dict.keys():
            standard_resp = {"id": 0,
                             "priority": "",
                             "recorddate": "",
                             "poi_count": 0,
                             "road_count": 0,
                             "scale_count": 0,
                             "carto_count": 0,
                             "team": "",
                             "grid_id": str(),
                             "grid_priority": "",
                             "city": "",
                             "area": "",
                             "digitizer": "",
                             "house_count": 0,
                             "main_table_ids": [0]}

            standard_resp.update({'priority': key})
            relevant_list = [item for index, item in enumerate(data) if index in gid_dict[key]]
            for item in relevant_list:
                if item['digitizer'] not in standard_resp['digitizer']:
                    standard_resp['digitizer'] += item['digitizer'] + ','
                if str(item['grid_id']) not in standard_resp['grid_id']:
                    standard_resp['grid_id'] += str(item['grid_id']) + ','
                if item['recorddate'] not in standard_resp['recorddate']:
                    standard_resp['recorddate'] += item['recorddate'] + ','
                if item['area'] not in standard_resp['area']:
                    standard_resp['area'] += item['area'] + ','
                if item['city'] not in standard_resp['city']:
                    standard_resp['city'] += item['city'] + ','
                if item['priority'] not in standard_resp['priority']:
                    standard_resp['priority'] = item['priority']
                if item['team'] not in standard_resp['team']:
                    standard_resp['team'] += item['team'] + ','

                standard_resp['poi_count'] += item['poi_count']
                standard_resp['road_count'] += item['road_count']
                standard_resp['scale_count'] += item['scale_count']
                standard_resp['carto_count'] += item['carto_count']
                # standard_resp['team'] = item['team']
                standard_resp['id'] = item['id']
                standard_resp['grid_priority'] = item['grid_priority']
                standard_resp['house_count'] += item['house_count']
                standard_resp['main_table_ids'] = item['main_table_ids']
            out_data.append(standard_resp)
        return out_data







# if __name__ == '__main__':
#     grouper_id(rows, 'digitizer')
#     grouper_date(rows, 'digitizer')
#     grouper_employee(rows, 'digitizer')




