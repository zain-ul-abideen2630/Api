import gc
from groupfunction import grouper_id, grouper_employee, grouper_date


class SurveyShowDetails:
    _required_params = ['date_from', 'date_to', 'areas', 'city', 'layers', 'priority', 'surveyor_name', 'id',
                        'employee', 'token', 'condition_grid', 'condition_date', 'condition_emp']
    _dot_string = '-----'
    header_names_surveyors = ['Grid ID', 'Date', 'PlaceIT POI', 'PlaceIT Housing', 'Roads', 'SV Survey', 'GPS POI',
                              'GPS House', 'Surveyor']
    header_names_digitizers = ['Grid ID', 'Date', 'POIs', 'Roads', 'House', 'Scale', 'Carto', 'Team', 'City',
                               'Area', 'Digitizer']

    @check_token_valid
    def _handleQuery(self, provided_params):
        print(provided_params)
        main_database.refreshDbConenction()
        _required_params = self._required_params
        # Checking whether we are getting all the requiredreturnsurveydropitemsall parameters. Incomplete parameters will result in an error
        all_params_provided = all(
            [False if param not in provided_params.keys() else True for param in _required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        print([param if param not in provided_params.keys() else True for param in _required_params])
        if not all_params_provided:
            return {'Error': 'Missing Parameter. Make Sure all parameters are present. Valid parameters are '
                             '{0}'.format(', '.join(_required_params))}
        date_from = provided_params['date_from'] if provided_params['date_from'] not in [None, '', 'null'] else None
        date_to = provided_params['date_to'] if provided_params['date_to'] not in [None, '', 'null'] else None
        areas = provided_params['areas'] if provided_params['areas'] else self._dot_string
        city = provided_params['city'] if provided_params['city'] else self._dot_string
        layers = provided_params['layers'] if provided_params['layers'] else self._dot_string
        priority = provided_params['priority'] if provided_params['priority'] else self._dot_string
        surveyor_name = provided_params['surveyor_name'] if provided_params['surveyor_name'] else self._dot_string
        employee = provided_params['employee'] if provided_params['employee'] else None
        id = provided_params['id'] if provided_params['id'] not in [None, '', 'null'] else None
        condition_grid = provided_params['condition_grid'] if provided_params['condition_grid'] else 'default'
        condition_date = provided_params['condition_date'] if provided_params['condition_date'] else 'default'
        condition_emp = provided_params['condition_emp'] if provided_params['condition_emp'] else 'default'

        blank_response = {
            "total": 0,
            "totalNotFiltered": 0,
            "rows": []
        }

        try:
            if not employee:
                raise Exception('Invalid')
            employee = employee.lower()
            if employee not in ('digitizer', 'surveyor'):
                raise Exception('Invalid')
            if date_from and isinstance(date_from, str):
                date_from = datetime.strptime(date_from, '%m/%d/%Y').date()
            if date_to and isinstance(date_to, str):
                date_to = datetime.strptime(date_to, '%m/%d/%Y').date()
            if employee == 'surveyor':
                resp = main_database.DbResultsQuery(
                    """select fn_show_details(%s, %s, %s, %s, %s, %s, %s, %s)
                    """, (date_from, date_to, city, areas, surveyor_name, layers, priority, id)
                )
            else:

                resp = main_database.DbResultsQuery(
                    """select fn_see_details_digitizer(%s, %s, %s, %s, %s,  %s, %s, %s)
                    """, (date_from, date_to, city, areas, surveyor_name, layers, priority, id)
                )
            final_resp = resp[0][0]
            if not final_resp:
                raise Exception('Empty Response')
        except:
            return blank_response

        final_response = blank_response
        final_response['rows'] = final_resp
        # final_response['results'] = final_resp
        final_resp = None
        if condition_grid in 'default':
            pass
        elif condition_grid in 'condition_grid':
            final_response['rows'] = grouper_id(final_response['rows'], employee)

        if condition_date in 'default':
            pass
        elif condition_date in 'condition_date':
            final_response['rows'] = grouper_date(final_response['rows'], employee)

        if condition_emp in 'default':
            pass
        elif condition_emp in 'condition_emp':
            final_response['rows'] = grouper_employee(final_response['rows'], employee)
        gc.collect()
        return final_response

    @api_logger
    def on_get(self, req, resp):
        params = req.params
        output = self._handleQuery(params)
        if output == conf.unauthorized_error:
            resp.status = falcon.HTTP_401
        resp.media = output

    @api_logger
    def on_post(self, req, resp):
        params = req.media
        output = self._handleQuery(params)
        if output == conf.unauthorized_error:
            resp.status = falcon.HTTP_401
        resp.media = output


class MapFitBounds:
    _required_params = ['list', 'token']
    _dot_string = '-----'
    dir = os.path.dirname(__file__)

    @check_token_valid
    def _handleQuery(self, provided_params):
        print(provided_params)
        main_database.refreshDbConenction()
        _required_params = self._required_params
        # Checking whether we are getting all the required parameters. Incomplete parameters will result in an error
        all_params_provided = all([False if param not in provided_params else True for param in _required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        if not all_params_provided:
            return {'Error': 'Missing Parameter. Make Sure all parameters are present. Valid parameters are '
                             '{0}'.format(', '.join(_required_params))}
        grid_list = provided_params['list'] if provided_params['list'] else None
        if grid_list:
            fitbound = main_database.DbResultsQuery(f"""select fn_get_grid_extent(array{grid_list})""")
            polygon = [list(map(lambda x: float(x), element.split(" ")[::-1])) for element in
                       fitbound[0][0].replace("BOX(", "")[:-1].split(",")]

            return {'Polygon': polygon}

    @api_logger
    def on_get(self, req, resp):
        params = req.params
        resp.media = self._handleQuery(params)

    @api_logger
    def on_post(self, req, resp):
        params = req.media
        resp.media = self._handleQuery(params)



api.add_route('/returnsurveydetails', SurveyShowDetails())
api.add_route('/mapfitbounds', MapFitBounds())