from waitress import serve
import falcon
from db_connector import DbConnect
from psycopg2.errorcodes import INTERNAL_ERROR
from dbConfiguration import DbConfig
from time import localtime
from falcon_cors import CORS
import datetime as dt
import requests, json
import xmltodict
from PyQt5.QtCore import *
from PyQt5.QtGui import QImage
from moviepy.video.io.VideoFileClip import VideoFileClip
import os
from io import BytesIO
from datetime import datetime
import time as tm
import uuid
from base64 import b64encode
from json import dumps
import configuration as conf
from psycopg2.errorcodes import INTERNAL_ERROR
import jwt
#from jwt.exceptions import DecodeError
import gc
from geojson import Feature, Point
import os
import requests
from groupfunction import grouper_id, grouper_employee, grouper_date, grouper_city, grouper_area, grouper_priority
from slackclient import SlackClient
from datetime import date
from datetime import datetime
from dateutil.relativedelta import relativedelta
from calendar import isleap
import time
from collections import defaultdict 
from datetime import datetime, timedelta 




cors = CORS(allow_all_origins=True, allow_all_headers=True, allow_credentials_all_origins=True, allow_all_methods=True)

main_database = DbConfig('172.16.130.23', 'TPLMaps', '6432', 'qgis.plugin', 'assigncity')
if not main_database.ConnectDb():
    raise Exception('Cannot Connect To 23 Server')

# logs_database = DbConfig('172.16.14.61', 'TPLMaps-logs', '5432', 'qgis.plugin', 'assigncity')
logs_database = DbConfig('172.16.130.23', 'TPLMaps', '6432', 'qgis.plugin', 'assigncity')
if not logs_database.ConnectDb():
    raise Exception('Cannot Connect To 61  Server')

main_data = DbConfig('172.16.130.61', 'TPLMaps', '5432', 'qgis.plugin', 'assigncity')
if not main_data.ConnectDb():
    raise Exception('Cannot Connect To 61 Server')    


def generateToken():
    output = b64encode(bytes(uuid.uuid4().hex.encode('utf-8'))).decode()
    return output.rstrip('=')


not_authorized = QImage('notauthorized.png')
not_found = QImage('notfound.png')


def getImageStream(pixmap):
    # Converting the Pixmap into a Bytes Like Object for sending
    buffer = QBuffer()
    buffer.open(QBuffer.ReadWrite)
    # Quality Decreased to decrease image size drastically without much compromise of image quality
    pixmap.save(buffer, 'JPG', 80)
    # Read QByteArray containing PNG into a StringIO.
    bytes_io = BytesIO(buffer.data())
    stream_len = bytes_io.getbuffer().nbytes
    buffer.close()
    return bytes_io, stream_len


def check_token_valid(func):
    def inner(*args, **kwargs):
        params = args[1]
        if 'token' in params.keys():
            success = False
            try:
                if params['token'] == '191294D1D1CC44C684A3959EB9388':
                    success = True
                else:
                    resp = requests.post('http://172.16.44.80:8011/authentication/checktoken',
                                         json={'token': params['token']}).json()
                    success = resp['Success']
                    if not success:
                        return {"Error": "Invalid Token"}
            except:
                pass
            if success:
                return func(*args, **kwargs)
            return conf.unauthorized_error
        else:
            return func(*args, **kwargs)
    return inner


def api_logger(func):
    def log_requests(*args, **kwargs):

        req = args[1]
        resp = args[2]
        req_params = args[0]._required_params

        token = conf.no_token_req if "token" not in req_params else conf.token_req

        value = None
        url = req._cached_uri
        if req.env['REQUEST_METHOD'] == 'GET':
            value = req.params
        elif req.env['REQUEST_METHOD'] == 'POST':
            value = req.media
        try:
            source = conf.source_default if 'source' not in value.keys() else jwt.decode(value['source'], 'secret',
                                                                                         algorithms=['HS256'])['source']
        except DecodeError:
            source = conf.source_default

        try:
            value['token'] = value.pop('amp;token')
        except Exception as e:
            print(e)

        if 'token' not in value.keys() and token != conf.no_token_req:
            resp.media = {'Error': token}
            return value

        try:
            if token != conf.no_token_req or 'token' in value.keys():
                token = req.params['token']
            ip, typeof, url, body = (req.remote_addr, req.env['REQUEST_METHOD'], req.url, req.params)
        except:
            if token != conf.no_token_req or 'token' in value.keys():
                token = req.media['token']
            ip, typeof, url, body = (req.remote_addr, req.env['REQUEST_METHOD'], req.url, req.media)
        main_database = DbConnect(conf.host_23, conf.database_23, conf.port_23, conf.username_23, conf.password_23)
        main_database.ConnectDb()
        try:
            main_database.DbModifyQuery(
                """insert into api_logging(ip,request_type,arguments,token,url,source)values(%s,%s,%s,%s,%s,%s)""",
                (ip, typeof, json.dumps(body), token, url, source))
        except INTERNAL_ERROR:
            main_database.refreshDbConenction()
            main_database.DbModifyQuery(
                """insert into api_logging(ip,request_type,arguments,token,url,source)values(%s,%s,%s,%s,%s,%s)""",
                (ip, typeof, json.dumps(body), token, url, source))

        return func(*args, **kwargs)
    return log_requests


class DaysDataSource:
    logs_started = 2017
    main_database.refreshDbConenction()
    logs_database.refreshDbConenction()
    main_data.refreshDbConenction()

    @staticmethod
    def _currentYear():
        return localtime().tm_year

    @staticmethod
    def _addedByYear(fid):
        resp = main_database.DbResultsQuery("""SELECT extract(year from added_time)::int as year FROM pois_level_one_logs
        WHERE feature_id = %s AND extract(year from added_time) is not null""", (fid,))
        return resp[0][0] if resp else False

    def _handleQuery(self, id):
        count_dict = {
            'null': 0,
            'QA': 0,
            'Production': 0,
            'Deprecated': 0
        }
        try:
            start_year = self._addedByYear(id)
            if not start_year:
                start_year = self.logs_started
            end_year = self._currentYear()

            count_dict = {
                'null': 0,
                'QA': 0,
                'Production': 0,
                'Deprecated': 0
            }
            queries_years_except_end_year = []

            for year in range(start_year, end_year + 1):  # Added one to take the end_year into account
                # 2017 doesn't have an year attached to the table name
                logs_table_name = 'users_log' if year < 2018 else 'users_log_{0}'.format(year)

                final_response = {}
                if year != end_year:
                    query = """(SELECT replace(REGEXP_REPLACE(REGEXP_REPLACE(cast(new_record -> 'data_status' AS text),
                    'QA_.*', 'QA'),'qa_.*', 'QA'), '"','') AS data_status,extract(epoch FROM operation_time)
                    as operation_time
                    FROM "{0}"
                    WHERE tbname LIKE '%{1}%' AND feature_id = {2}
                    ORDER BY operation_time)""".format(logs_table_name, 'poi', id)
                    queries_years_except_end_year.append(query)

                else:
                    # Executing the queries for previous years
                    if queries_years_except_end_year:
                        queries_years_except_end_year = ' UNION '.join(
                            queries_years_except_end_year) + ' ORDER BY operation_time'
                        response = logs_database.DbResultsQuery(queries_years_except_end_year)
                        for record in response:
                            data_status = record[0] if record[0] else 'null'
                            date_time = record[1]
                            final_response[date_time] = data_status

                    # Now executing this years query
                    query = "SELECT * FROM fn_logs_by_datasource_duration('{0}', {1})  ORDER BY operation_time".format(
                        'poi', id)
                    response = main_database.DbResultsQuery(query)
                    final_data_status = None
                    for record in response:
                        data_status = record[0]
                        date_time = record[1]
                        final_response[date_time] = data_status
                        final_data_status = data_status

                    if final_data_status:
                        now = tm.time() + 18000
                        final_response[now] = final_data_status

                    last_active_date = None
                    last_active_status = None
                    times = list(final_response.keys())
                    times.sort()

                    for time in times:
                        data_status = final_response[time]
                        if last_active_date:
                            days_passed = self.findDays(last_active_date, time)
                            if last_active_status == data_status:
                                count_dict[data_status] = count_dict[data_status] + days_passed
                            else:
                                count_dict[last_active_status] = count_dict[last_active_status] + days_passed

                        last_active_date = time
                        last_active_status = data_status

            count_dict = {key: abs(int(val)) for (key, val) in count_dict.items() if val}
            return count_dict
        except:
            return count_dict

    @staticmethod
    def findDays(min_date, max_date):
        return (max_date - min_date) / 86400.00

    @api_logger
    def on_get(self, req, resp):
        """Handles GET requests"""
        if 'id' not in req.params.keys():
            resp.media = {'Error': 'Provide Correct Arguments'}
            return
        id = req.params['id']
        resp.media = self._handleQuery(id)

    @api_logger
    def on_post(self, req, resp):
        """Handles POST requests"""
        if 'id' not in req.media.keys():
            resp.media = {'Error': 'Provide Correct Arguments'}
            return
        id = req.media['id']
        resp.media = self._handleQuery(id)


class ApiDocumentation:
    # List of all the required parameters in each request
    _required_params = ['name', 'request_type', 'category', 'endpoint', 'description', 'example', 'input_params',
                        'added_by', 'added_on']

   
    def on_get(self, req, resp):
        """Handles Get Request"""
        main_database.refreshDbConenction()
        result = main_database.DbResultsQuery("select fn_get_api()")[0][0]
        if not result:
            result = {}
            for param in self._required_params:
                result[param] = ''
            result = [result]
        resp.media = result

    
    def on_put(self, req, resp):
        """Handles Put Request"""
        main_database.refreshDbConenction()
        _required_params = self._required_params
        # Parameters provided to each request
        provided_params = req.media
        # Checking whether we are getting all the required parameters. Incomplete parameters will result in an error
        all_params_provided = all([False if param not in _required_params else True for param in _required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        if not all_params_provided:
            resp.media = {'Error': 'Missing Parameter. Make Sure all paramater are present. Valid Parameters are '
                                   '{0}'.format(', '.join(_required_params))}
            return
        # Inserting data into the database
        name = provided_params['name']
        request_type = provided_params['request_type']
        category = provided_params['category']
        endpoint = provided_params['endpoint']
        description = provided_params['description']
        example = provided_params['example']
        input_params = provided_params['input_params']
        added_by = provided_params['added_by']
        added_on = provided_params['added_on']

        main_database.DbModifyQuery(
            """INSERT INTO web_portal.web_api_details (name ,request_type ,category ,endpoint , description,
            example, input_params, added_by, added_on)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)""",
            (name, request_type, category, endpoint, description, example, input_params, added_by, added_on)
        )


class PoiOperationsByUser:
    main_database.refreshDbConenction()
    logs_database.refreshDbConenction()
    logs_started = 2017

    def _currentYear(self):
        return localtime().tm_year

    def _addedByYear(self, fid):
        # return False
        resp = main_database.DbResultsQuery("""SELECT extract(year from added_time)::int as year FROM pois_level_one_logs
            WHERE feature_id = %s AND extract(year from added_time) is not null""", (fid,))
        return resp[0][0] if resp else False

    def _handleQuery(self, fid):
        start_year = self._addedByYear(fid)
        if not start_year:
            start_year = self.logs_started
        end_year = self._currentYear()

        logs_by_date = {}
        for year in range(start_year, end_year + 1):  # Added one to take the end_year into account
            # 2017 doesn't have an year attached to the table name
            logs_table_name = 'users_log' if year < 2018 else 'users_log_{0}'.format(year)
            # We access the main database in case we are fetching from logs for the current year
            db_to_access = main_database if year == self._currentYear() else logs_database
            if year != end_year:
                query = """
                SELECT extract(epoch FROM operation_time::date)::bigint AS time_stamp, username, string_agg(operation,',') AS operations
                FROM
                (
                SELECT operation_time, username,
                CASE
                WHEN (cast(new_record -> 'data_status' as text)= '"Deprecated"' AND cast(old_record -> 'data_status' as text) != '"Deprecated"') THEN 'Deprecated'
                WHEN (cast(new_record -> 'data_status' as text)= '"Production"' AND cast(old_record -> 'data_status' as text) != '"Production"') THEN 'Production'
                ELSE operation END AS operation
                FROM "{0}"
                WHERE tbname LIKE '%{1}%' AND feature_id = {2} AND (new_record::text != old_record::text OR operation != 'UPDATE')
                ORDER BY operation_time, username
                ) tab1
                GROUP BY extract(epoch FROM operation_time::date), username
                Order by time_stamp;
                """.format(logs_table_name, 'poi', fid)
            else:
                query = """
                SELECT * FROM fn_logs_by_user_currentyear('{0}', {1})
                """.format('poi', fid)
            logs = db_to_access.DbResultsQuery(query)
            if logs:
                for log in logs:
                    if not log:
                        continue
                    op_date = int(log[0])
                    username = log[1]
                    operation = log[2].split(',')
                    logs_by_date[op_date] = {username: operation}
        return logs_by_date

    @api_logger
    def on_get(self, req, resp):
        """Handles GET requests"""
        if 'id' not in req.params.keys():
            resp.media = {'Error': 'Provide Correct Arguments'}
            return
        fid = req.params['id']
        resp.media = self._handleQuery(fid)

    @api_logger
    def on_post(self, req, resp):
        """Handles POST requests"""
        if 'id' not in req.media.keys():
            resp.media = {'Error': 'Provide Correct Arguments'}
            return
        fid = req.media['id']
        resp.media = self._handleQuery(fid)


class ReturnSurveyRecords:
    # List of all the required parameters in each request
    _required_params = ['start_date', 'end_date', 'city', 'areas', 'surveyor', 'survey_type', 'priority', 'employee','token']

    @check_token_valid
    def _handleQuery(self, provided_params):
        print(provided_params)
        _required_params = self._required_params
        # Checking whether we are getting all the required parameters. Incomplete parameters will result in an error
        all_params_provided = all([False if param not in provided_params else True for param in _required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        if not all_params_provided:
            return {'Error': 'Missing Parameter. Make Sure all parameters are present. Valid parameters are '
                             '{0}'.format(', '.join(_required_params))}

        blank_response_surveyor = {
            "grid_ids": [
            ],
            "summary": [
                {
                    "placeit_housing": 0,
                    "placeit_pois": 0,
                    "road": 0,
                    "video_tracker": 0
                }
            ]
        }

        blank_response_digitizer = {
            "grid_ids": [
            ],
            "summary": [
                {
                    "scale_count": 0,
                    "poi_count": 0,
                    "carto_count": 0,
                    "house_count": 0,
                    "road_count": 0,
                }
            ]
        }

        start_date = provided_params['start_date'] if provided_params['start_date'] else None
        end_date = provided_params['end_date'] if provided_params['end_date'] else None
        city = provided_params['city'] if provided_params['city'] else None
        areas = provided_params['areas'] if provided_params['areas'] else None
        surveyor = provided_params['surveyor'] if provided_params['surveyor'] else None
        survey_type = provided_params['survey_type'] if provided_params['survey_type'] else None
        priority = provided_params['priority'] if provided_params['priority'] else None
        employee = provided_params['employee'] if provided_params['employee'] else None

        try:
            if not employee:
                raise Exception('Invalid')
            employee = employee.lower()
            if employee not in ('digitizer', 'surveyor'):
                raise Exception('Inavlid')

            if employee == 'surveyor':
                resp = main_database.DbResultsQuery("""
                                select fn_show_summary_stats(%s, %s, %s, %s, %s, %s, %s);
                            """, (start_date, end_date, city, areas, surveyor, survey_type, priority)
                                                    )
            else:
                resp = main_database.DbResultsQuery("""
                                select fn_show_summary_stats_digitizer(%s, %s, %s, %s, %s, %s, %s);
                            """, (start_date, end_date, city, areas, surveyor, survey_type, priority)
                                                    )
            final_resp = resp[0][0]
            if employee == 'digitizer':
                final_resp['grid_id'] = final_resp['array_agg']
                final_resp.pop('array_agg')
                final_resp['summary'] = {}
                for item in ('poi_count', 'scale_count', 'carto_count', 'house_count', 'road_count'):
                    final_resp['summary'][item] = final_resp[item]
                    final_resp.pop(item)

            grid_id = None
            grid_ids = final_resp['grid_id']
            if grid_ids:
                grid_id = []
                for id in grid_ids:
                    grid_id.append({'grid_id': id})
                final_resp['grid_id'] = grid_id
            final_resp['summary'] = [final_resp['summary']]
            print(final_resp)

            return final_resp
        except Exception as e:
            print(e)
            if employee == 'surveyor':
                return blank_response_surveyor
            else:
                return blank_response_digitizer

    @api_logger
    def on_get(self, req, resp):
        params = req.params
        output = self._handleQuery(params)
        if output == conf.unauthorized_error:
            resp.status = falcon.HTTP_401
        resp.media = output

    @api_logger
    def on_post(self, req, resp):
        params = req.media
        output = self._handleQuery(params)
        if output == conf.unauthorized_error:
            resp.status = falcon.HTTP_401
        resp.media = output


class ReturnGridStats:
    # List of all the required parameters in each request
    _required_params = ['start_date', 'end_date', 'city', 'areas', 'surveyor', 'survey_type', 'priority', 'id',
                        'employee', 'token']

    @check_token_valid
    def _handleQuery(self, provided_params):
        print(provided_params)
        _required_params = self._required_params
        # Checking whether we are getting all the required parameters. Incomplete parameters will result in an error
        all_params_provided = all([False if param not in provided_params else True for param in _required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        if not all_params_provided:
            return {'Error': 'Missing Parameter. Make Sure all parameters are present. Valid parameters are '
                             '{0}'.format(', '.join(_required_params))}

        blank_response = {
            "summary": [
                {
                    "gps_housing": 0,
                    "gps_poi": 0,
                    "placeit_housing": 0,
                    "placeit_pois": 0,
                    "road": 0,
                    "video_tracker": 0
                }
            ]
        }

        start_date = provided_params['start_date'] if provided_params['start_date'] else None
        end_date = provided_params['end_date'] if provided_params['end_date'] else None
        city = provided_params['city'] if provided_params['city'] else None
        areas = provided_params['areas'] if provided_params['areas'] else None
        surveyor = provided_params['surveyor'] if provided_params['surveyor'] else None
        survey_type = provided_params['survey_type'] if provided_params['survey_type'] else None
        priority = provided_params['priority'] if provided_params['priority'] else None
        id = provided_params['id'] if provided_params['id'] else None
        employee = provided_params['employee'] if provided_params['employee'] else None

        try:
            if not employee:
                raise Exception('Invalid')
            employee = employee.lower()
            if employee not in ('digitizer', 'surveyor'):
                raise Exception('Inavlid')

            if employee == 'surveyor':
                resp = main_database.DbResultsQuery("""
                                select fn_show_grid_stats(%s, %s, %s, %s, %s, %s, %s, %s);
                            """, (start_date, end_date, city, areas, surveyor, survey_type, priority, id))
            else:
                resp = main_database.DbResultsQuery("""
                                select fn_show_summary_stats_digitizer_grid(%s, %s, %s, %s, %s, %s, %s, %s);
                            """, (start_date, end_date, city, areas, surveyor, survey_type, priority, id)

                                                )
            final_resp = resp[0][0]
            print(final_resp)
            if employee == 'digitizer':
                final_resp.pop('array_agg')
                final_resp = {'summary': final_resp}

            final_resp['summary'] = [final_resp['summary']]
            print(final_resp)
            return final_resp
        except Exception as e:
            print(e)
            return blank_response

    @api_logger
    def on_get(self, req, resp):
        params = req.params
        output = self._handleQuery(params)
        if output == conf.unauthorized_error:
            resp.status = falcon.HTTP_401
        resp.media = output

    @api_logger
    def on_post(self, req, resp):
        params = req.media
        output = self._handleQuery(params)
        if output == conf.unauthorized_error:
            resp.status = falcon.HTTP_401
        resp.media = output


class Versioner:
    _required_params = ['name']

    @check_token_valid
    def _handleQuery(self, params):
        # Do something here
        all_params_provided = all([False if param not in params else True for param in self._required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        if not all_params_provided:
            return {'Error': 'Missing Parameter. Make Sure all parameters are present. Valid parameters are '
                             '{0}'.format(', '.join(self._required_params))}
        try:
            response = requests.get("http://172.16.44.80:8081/tpl_plugin_repository.xml").text
        except:
            return {"version": 0.01}
        name = params['name']
        repository = json.loads(json.dumps(xmltodict.parse(response)))
        for plugin in repository['plugins']['pyqgis_plugin']:
            if plugin['@name'] == name:
                return {"version": plugin['@version']}
        return {'Error': 'Incorrect Plugin Name'}

    @api_logger
    def on_get(self, req, resp):
        params = req.params
        output = self._handleQuery(params)
        if output == conf.unauthorized_error:
            resp.status = falcon.HTTP_401
        resp.media = output

    @api_logger
    def on_post(self, req, resp):
        params = req.media
        output = self._handleQuery(params)
        if output == conf.unauthorized_error:
            resp.status = falcon.HTTP_401
        resp.media = output


class ReturnVideoSurveyImage:
    # List of all the required parameters in each request
    _required_params = ['id','token']
    _optional_params = ['width', 'height', 'frame']

    blank_response = {
        "Images": [
        ]
    }

    def checkParamsMissing(self, params):
        all_params_provided = all([False if param not in params else True for param in self._required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        if not all_params_provided:
            return {'Error': 'Missing Parameter. Make Sure all parameters are present. Valid parameters are '
                             '{0}'.format(', '.join(self._required_params))}
        return False

    def _parseVideo(self, videoPath):
        video = VideoFileClip(videoPath)
        date_time = os.path.basename(videoPath).split('.')[0].replace('VID_', '')
        try:
            date_time = dt.datetime.strptime(date_time, "%Y%m%d_%H%M%S")
        except:
            date_time = dt.datetime.strptime('_'.join(date_time.split('_')[1:]), "%Y%m%d_%H%M%S")
        return video, date_time.timestamp()

    def epochSecondToFrameNum(self, frame_sec, vid_st_time):
        seconds = frame_sec - vid_st_time
        if seconds > -1:
            return int(seconds)
        return None

    def _getVideo_Time(self, fid):
        try:
            main_database.refreshDbConenction()
            response = main_database.DbResultsQuery("SELECT file_dir_name, datetime "
                                                    "FROM video_track_points "
                                                    "WHERE id = %s", (fid,))[0]
            fileName = response[0]
            date_time = response[1].timestamp()
            response = None
            return fileName, date_time
        except:
            return None, None

    @check_token_valid
    def _handleQuery(self, provided_params):
        scaled_width = scaled_height = None
        params_missing = self.checkParamsMissing(provided_params)
        if params_missing:
            return params_missing
        pt_id = provided_params['id']
        if self._optional_params[0] in provided_params.keys() and self._optional_params[1] in provided_params.keys():
            scaled_width = provided_params[self._optional_params[0]]
            scaled_height = provided_params[self._optional_params[1]]
        frame_num = 1 if 'frame' not in provided_params.keys() else int(provided_params['frame'])
        fileName, date_time = self._getVideo_Time(pt_id)
        print(fileName, date_time, 'dile_date')
        if not fileName:
            print('here')
            # return {'Error': 'Provided Id has no associated Video File'}
            return getImageStream(not_found)
        if not date_time:
            # return {'Error': 'Provided Id has no associated Time'}
            return getImageStream(not_found)
        # Fetching Video Object along with the Video Start Ttime
        video, video_start_time = self._parseVideo(fileName)
        if frame_num > video.fps:
            return getImageStream(not_found)
        # Getting frame to fetch
        frame_time = self.epochSecondToFrameNum(frame_sec=date_time, vid_st_time=video_start_time)
        if not frame_time:
            # return {'Error': 'Provided Id has no associated Frame'}
            return getImageStream(not_found)
        if frame_time == 1:
            frame = video.get_frame(frame_time)
        else:
            frame = [x for x in video.subclip(frame_time, frame_time + 1).iter_frames()][frame_num - 1]

        # Video attributes
        width = video.w
        height = video.h
        bytesPerLine = 3 * width
        # Converting the image provided by the library into a valid Image
        pix = QImage(frame, width, height, bytesPerLine, QImage.Format_RGB888)
        if scaled_height and scaled_width:
            pix = pix.scaled(int(scaled_width), int(scaled_height))
        video.close()
        return getImageStream(pix)

    @api_logger
    def on_get(self, req, resp):
        params = req.params
        bla = self._handleQuery(params)
        if not bla or isinstance(bla, dict):
            bla = getImageStream(not_authorized)
        resp.content_type = 'image/jpeg'
        resp.stream, resp.stream_len = bla

    @api_logger
    def on_post(self, req, resp):
        params = req.media
        bla = self._handleQuery(params)
        if not bla or isinstance(bla, dict):
            resp.media = bla
            return
        elif not bla:
            bla = getImageStream(not_authorized)
        resp.content_type = 'image/jpeg'
        resp.stream, resp.stream_len = bla


class ReturnSurveyDropDownItems:
    _required_params = ['date_from', 'date_to', 'areas', 'city', 'layers', 'priority', 'surveyor_name', 'employee', 'token']

    _dot_string = '-----'

    @check_token_valid
    def _handleQuery(self, provided_params):
        print(provided_params)
        main_database.refreshDbConenction()
        _required_params = self._required_params
        # Checking whether we are getting all the required parameters. Incomplete parameters will result in an error
        all_params_provided = all([False if param not in provided_params else True for param in _required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        if not all_params_provided:
            return {'Error': 'Missing Parameter. Make Sure all parameters are present. Valid parameters are '
                             '{0}'.format(', '.join(_required_params))}

        blank_response = {
            "areas": [self._dot_string],
            "city": [self._dot_string],
            "layers": [self._dot_string],
            "priority": [self._dot_string],
            "surveyor_name": [self._dot_string]
        }
        date_from = provided_params['date_from'] if provided_params['date_from'] else None
        date_to = provided_params['date_to'] if provided_params['date_to'] else None
        areas = provided_params['areas'] if provided_params['areas'] else self._dot_string
        city = provided_params['city'] if provided_params['city'] else self._dot_string
        layers = provided_params['layers'] if provided_params['layers'] else self._dot_string
        priority = provided_params['priority'] if provided_params['priority'] else self._dot_string
        surveyor_name = provided_params['surveyor_name'] if provided_params['surveyor_name'] else self._dot_string
        employee = provided_params['employee'] if provided_params['employee'] else None


        try:
            if not employee:
                raise Exception('Invalid')
            employee = employee.lower()
            if employee not in ('digitizer', 'surveyor'):
                raise Exception('Inavlid')

            if employee == 'surveyor':
                resp = main_database.DbResultsQuery(
                    """select fn_summary_grids_drop_down(%s, %s, %s, %s, %s, %s, %s, 'City');
                    """, (date_from, date_to, city, areas, surveyor_name, layers, priority)
                )
            else:
                resp = main_database.DbResultsQuery(
                    """select fn_summary_grids_drop_down_digitizer(%s, %s, %s, %s, %s, %s, %s);
                    """, (date_from, date_to, city, areas, surveyor_name, layers, priority)
                )
            final_resp = resp[0][0]

            # Split areas into list, sorting it and adding a dashed entry
            final_areas = []
            if employee == 'digitizer':
                final_resp['areas'] = final_resp['area']
                final_resp.pop('area')
            if final_resp['areas']:
                final_resp['areas'] = [area.split(',') for area in final_resp['areas']]
            else:
                final_resp['areas'] = []
            for areas in final_resp['areas']:
                final_areas.extend(areas)
            final_areas = list(set(tuple(final_areas)))
            final_resp['areas'] = final_areas
            final_resp['areas'].sort()
            final_resp['areas'] = [self._dot_string] + final_resp['areas']

            # Doing the same with layers
            if employee == 'digitizer':
                final_resp['layers'] = final_resp['team']
                final_resp.pop('team')
            if employee == 'surveyor':
                final_resp['layers'] = final_resp['layers'].split(',')
            if not final_resp['layers']:
                final_resp['layers'] = []
            final_resp['layers'].sort()
            final_resp['layers'] = [self._dot_string] + final_resp['layers']
            # Cities
            if not final_resp['city']:
                final_resp['city'] = []
            final_resp['city'].sort()
            final_resp['city'] = [self._dot_string] + final_resp['city']
            # Surveyor Name
            if employee == 'digitizer':
                final_resp['surveyor_name'] = final_resp['digitizer']
                final_resp.pop('digitizer')
            if not final_resp['surveyor_name']:
                final_resp['surveyor_name'] = []
            final_resp['surveyor_name'] = list(set(tuple(final_resp['surveyor_name'])))
            final_resp['surveyor_name'].sort()
            final_resp['surveyor_name'] = [self._dot_string] + final_resp['surveyor_name']
            # priority
            if not final_resp['priority']:
                final_resp['priority'] = []
            final_resp['priority'].sort()
            final_resp['priority'] = [self._dot_string] + final_resp['priority']
            return final_resp
        except Exception as e:
            return blank_response

    @api_logger
    def on_get(self, req, resp):
        params = req.params
        output = self._handleQuery(params)
        if output == conf.unauthorized_error:
            resp.status = falcon.HTTP_401
        resp.media = output

    @api_logger
    def on_post(self, req, resp):
        params = req.media
        output = self._handleQuery(params)
        if output == conf.unauthorized_error:
            resp.status = falcon.HTTP_401
        resp.media = output


class ReturnGridFeatures:
    # _required_params = ['date_from', 'date_to', 'areas', 'city', 'layers', 'priority', 'surveyor_name']
    _required_params = ['date_from', 'date_to', 'surveyor', 'survey_type', 'grid', 'employee','token', 'snap']
    # Survey Type possible values :
    # Pois
    # House
    # SV
    _dot_string = '-----'

    @check_token_valid
    def _handleQuery(self, provided_params):
        main_database.refreshDbConenction()
        _required_params = self._required_params
        # Checking whether we are getting all the required parameters. Incomplete parameters will result in an error
        all_params_provided = all([False if param not in provided_params else True for param in _required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        if not all_params_provided:
            return {'Error': 'Missing Parameter. Make Sure all parameters are present. Valid parameters are '
                             '{0}'.format(', '.join(_required_params))}

        blank_response = {
        }

        date_from = provided_params['date_from'] if provided_params['date_from'] else None
        date_to = provided_params['date_to'] if provided_params['date_to'] else None
        surveyor = provided_params['surveyor'] if provided_params['surveyor'] else self._dot_string
        survey_type = provided_params['survey_type'] if provided_params['survey_type'] else self._dot_string
        grid = provided_params['grid'] if provided_params['grid'] else None
        employee = provided_params['employee'] if provided_params['employee'] else None
        snap = provided_params['snap'] if provided_params['snap'] else None

        try:
            if not employee:
                raise Exception('Invalid')
            employee = employee.lower()
            if employee not in ('digitizer', 'surveyor'):
                raise Exception('Inavlid')

            if employee == 'surveyor':
                resp = main_database.DbResultsQuery(
                    """select fn_portal_show_data_snap(%s, %s, %s, %s, %s, %s)
                    """, (date_from, date_to, surveyor, survey_type, grid, snap)
                )
            else:
                surveyor = surveyor if surveyor else self._dot_string
                grid = grid if grid else self._dot_string
                survey_type = survey_type if survey_type else self._dot_string
                resp = main_database.DbResultsQuery(
                    """select fn_show_details_digitizer_latest(%s, %s, null, null, %s, null,  null, %s, %s)
                    """, (date_from, date_to, surveyor, grid, survey_type)
                )

            records = resp[0][0]
            if not records:
                raise Exception('Empty Response')
        except:
            return blank_response

        final_resp = []
        for record in records:
            geojson_feature = {
                "type": "Feature",
                "properties": {},
                "geometry": {}
                }
            geojson_feature['properties'] = {key: attribute for key, attribute in record.items() if key != 'geom'}
            geojson_feature['geometry'] = json.loads(record['geom'])
            final_resp.append(geojson_feature)
        print(final_resp)
        return final_resp

    @api_logger
    def on_get(self, req, resp):
        params = req.params
        to_send = self._handleQuery(params)
        if to_send == conf.unauthorized_error:
            resp.status = falcon.HTTP_401
            resp.media = to_send
            return
        resp.media = to_send

    @api_logger
    def on_post(self, req, resp):
        params = req.media
        to_send = self._handleQuery(params)
        if to_send == conf.unauthorized_error:
            resp.status = falcon.HTTP_401
            resp.media = to_send
            return
        resp.media = to_send


class ReturnSurveyDropItemsToggleDisabled:
    _required_params = ['city', 'employee','token']
    _dot_string = '-----'
    blank_response = {
        "areas": [_dot_string],
        "city": [_dot_string],
        "layers": [_dot_string],
        "priority": [_dot_string],
        "surveyor_name": [_dot_string]
    }

    @check_token_valid
    def _handleQuery(self, provided_params):
        print(provided_params)
        main_database.refreshDbConenction()
        _required_params = self._required_params
        # Checking whether we are getting all the required parameters. Incomplete parameters will result in an error
        all_params_provided = all([False if param not in provided_params else True for param in _required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        if not all_params_provided:
            return {'Error': 'Missing Parameter. Make Sure all parameters are present. Valid parameters are '
                             '{0}'.format(', '.join(_required_params))}

        city = provided_params['city'] if provided_params['city'] else None
        employee = provided_params['employee'] if provided_params['employee'] else None

        try:
            if not employee:
                raise Exception('Invalid')
            employee = employee.lower()
            if employee not in ('digitizer', 'surveyor'):
                raise Exception('Inavlid')

            if employee == 'surveyor':
                resp = main_database.DbResultsQuery(
                    """select fn_drop_down_without_toggle_v1(%s)
                    """, (city,)
                )
            else:
                resp = main_database.DbResultsQuery(
                    """select fn_summary_grids_drop_down_digitizer_without_toggle_v1(%s)
                    """, (city,)
                )
            final_resp = resp[0][0]
            if not final_resp:
                raise Exception('Empty Response')
        except:
            return self.blank_response

        # Split areas into list, sorting it and adding a dashed entry
        if city != self._dot_string:
            final_areas = []
            final_resp['areas'] = [area.split(',') for area in final_resp['areas'] if isinstance(area,str) ]
            for areas in final_resp['areas']:
                final_areas.extend(areas)
            final_areas = list(set(tuple(final_areas)))
            final_resp['areas'] = final_areas
            final_resp['areas'].sort()
            final_resp['areas'] = [self._dot_string] + final_resp['areas']
        else:
            final_resp['areas'] = [self._dot_string]
        # Doing the same with layers
        final_resp['layers'].sort()
        final_resp['layers'] = [self._dot_string] + final_resp['layers']

        # Cities
        # final_resp['city'].sort()
        final_resp['city'] = [self._dot_string] + final_resp['city'] if final_resp['city'] else 'null'

        # Surveyor Name
        final_resp['surveyor_name'] = list(set(tuple(final_resp['surveyor_name'])))
        final_resp['surveyor_name'].sort()

        final_resp['surveyor_name'] = [self._dot_string] + final_resp['surveyor_name']
        # priority
        final_resp['priority'].sort()
        final_resp['priority'] = [self._dot_string] + final_resp['priority']
        return final_resp

    @api_logger
    def on_get(self, req, resp):
        params = req.params
        to_send = self._handleQuery(params)
        if to_send == conf.unauthorized_error:
            resp.status = falcon.HTTP_401
            resp.media = to_send
            return
        resp.media = to_send

    @api_logger
    def on_post(self, req, resp):
        params = req.media
        to_send = self._handleQuery(params)
        if to_send == conf.unauthorized_error:
            resp.status = falcon.HTTP_401
            resp.media = to_send
            return
        resp.media = to_send


class SurveyShowDetails:
    _required_params = ['date_from', 'date_to', 'areas', 'city', 'layers', 'priority', 'surveyor_name', 'id',
                        'employee', 'token', 'condition_grid', 'condition_date', 'condition_emp', 'condition_city',
                         'condition_area','condition_priority', 'source']
    _dot_string = '-----'
    header_names_surveyors = ['Grid ID', 'Date', 'PlaceIT POI', 'PlaceIT Housing', 'Roads', 'SV Survey', 'GPS POI',
                              'GPS House', 'Surveyor']
    header_names_digitizers = ['Grid ID', 'Date', 'POIs', 'Roads', 'House', 'Scale', 'Carto', 'Team', 'City',
                               'Area', 'Digitizer']

    @check_token_valid
    def _handleQuery(self, provided_params):
        print(provided_params)
        main_database.refreshDbConenction()
        _required_params = self._required_params
        # Checking whether we are getting all the requiredreturnsurveydropitemsall parameters. Incomplete parameters will result in an error
        all_params_provided = all([False if param not in provided_params.keys() else True for param in _required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        print([param if param not in provided_params.keys() else True for param in _required_params])
        if not all_params_provided:
            return {'Error': 'Missing Parameter. Make Sure all parameters are present. Valid parameters are '
                             '{0}'.format(', '.join(_required_params))}
        date_from = provided_params['date_from'] if provided_params['date_from'] not in [None, '', 'null'] else None
        date_to = provided_params['date_to'] if provided_params['date_to']  not in [None, '', 'null'] else None
        areas = provided_params['areas'] if provided_params['areas'] else self._dot_string
        city = provided_params['city'] if provided_params['city'] else self._dot_string
        layers = provided_params['layers'] if provided_params['layers'] else self._dot_string
        priority = provided_params['priority'] if provided_params['priority'] else self._dot_string
        surveyor_name = provided_params['surveyor_name'] if provided_params['surveyor_name'] else self._dot_string
        employee = provided_params['employee'] if provided_params['employee'] else None
        id = provided_params['id'] if provided_params['id'] not in [None, '', 'null'] else None
        condition_grid = provided_params['condition_grid'] if provided_params['condition_grid'] else 'default'
        condition_date = provided_params['condition_date'] if provided_params['condition_date'] else 'default'
        condition_emp = provided_params['condition_emp'] if provided_params['condition_emp'] else 'default'
        condition_city = provided_params['condition_city'] if provided_params['condition_city'] else 'default'
        condition_area = provided_params['condition_area'] if provided_params['condition_area'] else 'default'
        condition_priority = provided_params['condition_priority'] if provided_params['condition_priority'] else 'default'


        blank_response = {
            "total": 0,
            "totalNotFiltered": 0,
            "rows": []
        }

        try:
            if not employee:
                raise Exception('Invalid')
            employee = employee.lower()
            if employee not in ('digitizer', 'surveyor'):
                raise Exception('Invalid')
            if date_from and isinstance(date_from, str):
                date_from = datetime.strptime(date_from, '%m/%d/%Y').date()
            if date_to and isinstance(date_to, str):
                date_to = datetime.strptime(date_to, '%m/%d/%Y').date()
            if employee == 'surveyor':
                resp = main_database.DbResultsQuery(
                    """select fn_show_details(%s, %s, %s, %s, %s, %s, %s, %s)
                    """, (date_from, date_to, city, areas, surveyor_name, layers, priority, id)
                )
            else:

                resp = main_database.DbResultsQuery(
                    """select fn_see_details_digitizer(%s, %s, %s, %s, %s,  %s, %s, %s)
                    """, (date_from, date_to, city, areas, surveyor_name, layers, priority, id)
                )
            final_resp = resp[0][0]
            if not final_resp:
                raise Exception('Empty Response')
        except:
            return blank_response

        final_response = blank_response
        final_response['rows'] = final_resp
        # final_response['results'] = final_resp
        final_resp = None
        if condition_grid in 'default':
            pass
        elif condition_grid in 'condition_grid':
           final_response['rows'] = grouper_id(final_response['rows'], employee)

        if condition_date in 'default':
            pass
        elif condition_date in 'condition_date':
            final_response['rows'] = grouper_date(final_response['rows'], employee)

        if condition_emp in 'default':
            pass
        elif condition_emp in 'condition_emp':
            final_response['rows'] = grouper_employee(final_response['rows'], employee)

        if condition_city in 'default':
            pass
        elif condition_city in 'condition_city':
            final_response['rows'] = grouper_city(final_response['rows'], employee)

        if condition_area in 'default':
            pass
        elif condition_area in 'condition_area':
            final_response['rows'] = grouper_area(final_response['rows'], employee)

        if condition_priority in 'default':
            pass
        elif condition_priority in 'condition_priority':
            final_response['rows'] = grouper_priority(final_response['rows'], employee)    
              
        gc.collect()
        return final_response

    @api_logger
    def on_get(self, req, resp):
        params = req.params
        output = self._handleQuery(params)
        if output == conf.unauthorized_error:
            resp.status = falcon.HTTP_401
        resp.media = output

    @api_logger
    def on_post(self, req, resp):
        params = req.media
        output = self._handleQuery(params)
        if output == conf.unauthorized_error:
            resp.status = falcon.HTTP_401
        resp.media = output

class MapFitBounds:
    _required_params = ['list', 'token', 'source']
    _dot_string = '-----'
    dir = os.path.dirname(__file__)
    
    @check_token_valid
    def _handleQuery(self, provided_params):
        print(provided_params)
        main_database.refreshDbConenction()
        _required_params = self._required_params
        # Checking whether we are getting all the required parameters. Incomplete parameters will result in an error
        all_params_provided = all([False if param not in provided_params else True for param in _required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        if not all_params_provided:
            return {'Error': 'Missing Parameter. Make Sure all parameters are present. Valid parameters are '
                             '{0}'.format(', '.join(_required_params))}
        grid_list = provided_params['list'] if provided_params['list'] else None
        if grid_list:
            fitbound = main_database.DbResultsQuery("select fn_get_grid_extent(array{0})".format(grid_list))
            polygon = [list(map(lambda x: float(x), element.split(" ")[::-1])) for element in fitbound[0][0].replace("BOX(", "")[:-1].split(",")]

            return {'Polygon': polygon}

    @api_logger
    def on_get(self, req, resp):
        params = req.params
        resp.media = self._handleQuery(params)

    @api_logger
    def on_post(self, req, resp):
        params = req.media
        resp.media = self._handleQuery(params)

class ShowProgressEmployees:
    _required_params = ['user', 'token']
    _optional_params = ['name', 'start_date', 'end_date', 'comments', 'designation', 'team']
    _dot_string = '-----'
    _page_list_items_to_database_entries_map_comments = {
        _dot_string: None,
        'Added': 'Not Null',
        'Not Added': 'Null'
    }

    def setDefaultValues(self, prov_params):
        _optional_params_default_values = {
            'name': None,
            'start_date': (datetime.now() - dt.timedelta(days=1)).date(),
            'end_date': (datetime.now() - dt.timedelta(days=1)).date(),
            'comments': None,
            'designation': None,
            'team': None
        }

        for option in self._optional_params:
            if option in prov_params.keys():
                _optional_params_default_values.pop(option)
        return _optional_params_default_values

    @check_token_valid
    def _handleQuery(self, provided_params):
        main_database.refreshDbConenction()
        try:
            provided_params['token'] = provided_params.pop('amp;token')
        except Exception as e:
            print(e)
        provided_params = {**provided_params, **self.setDefaultValues(provided_params)}
        _required_params = self._required_params
        # Checking whether we are getting all the required parameters. Incomplete parameters will result in an error
        all_params_provided = all([False if param not in provided_params else True for param in _required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        blank_response = {
            "total": 0,
            "totalNotFiltered": 0,
            "rows": []
        }

        if not all_params_provided:
            return {'Error': 'Missing Parameter. Make Sure all parameters are present. Valid parameters are '
                             '{0}'.format(', '.join(_required_params))}

        start_date = provided_params['start_date'] if provided_params['start_date'] not in [None, 'null'] else None
        end_date = provided_params['end_date'] if provided_params['end_date'] not in [None, 'null'] else None
        name = provided_params['name'].rstrip().lstrip() if provided_params['name'] not in [None, 'null',
                                                                                            self._dot_string] else None
        comments = provided_params['comments'].rstrip().lstrip() if provided_params['comments'] not in [None,
                                                                                                        'null',
                                                                                                        self._dot_string] else None
        designation = provided_params['designation'].rstrip().lstrip() if provided_params['designation'] not in [None,
                                                                                                                 'null',
                                                                                                                   self._dot_string] else None
        user = provided_params['user']
        team = provided_params['team'].rstrip().lstrip() if provided_params['team'] not in [None,
                                                                                                                 'null',
                                                                                                                 self._dot_string] else None
        try:
            token = provided_params['token']
        except:
            token = provided_params['amp;token']


        if start_date and isinstance(start_date, str):
            start_date = datetime.strptime(start_date, '%m/%d/%Y').date()
        if end_date and isinstance(start_date, str):
            end_date = datetime.strptime(end_date, '%m/%d/%Y').date()
        if comments:
            comments = self._page_list_items_to_database_entries_map_comments[comments]

        try:
            try:
                user_id = main_database.DbResultsQuery("select fn_check_api(%s)", (token, ))[0][0]['user_id']
            except:
                user_id = None
            if not user_id:
                raise Exception('Error in function fn_check_api')
            resp = main_database.DbResultsQuery(

                """SELECT fn_webportal_show_employee_progress1(%s, %s, %s, %s, %s, %s, %s)""",
                (name, start_date, end_date, comments, designation, user_id, team))
            # print("""SELECT fn_webportal_show_employee_progress(%s, %s, %s, %s, %s, %s)""" %
            #       (name, start_date, end_date, comments, designation, user_id))
            final_resp = resp[0][0]
            if not final_resp:
                raise Exception('Empty Response')
            for num in range(0, len(final_resp)):
                final_resp[num]['No.'] = num + 1
                final_resp[num]['comment_status'] = 'Added' if bool(final_resp[num]['comments']) else 'Not Added'
        except Exception as e:
            print(e)
            main_database.refreshDbConenction()
            return blank_response
        for item in range(len(final_resp)):
            final_resp[item]['date'] = tm.strftime("%d %b %y", tm.strptime(final_resp[item]['date'], '%Y-%m-%d'))
        final_response = blank_response
        final_response['rows'] = final_resp
        final_response['total'] = len(final_resp)
        final_response['totalNotFiltered'] = len(final_resp)
        print(final_response)
        final_resp = None
        return final_response

    @api_logger
    def on_get(self, req, resp):
        params = req.params
        output = self._handleQuery(params)
        if output == conf.unauthorized_error:
            resp.status = falcon.HTTP_401
        resp.media = output

    @api_logger
    def on_post(self, req, resp):
        params = req.media
        output = self._handleQuery(params)
        if output == conf.unauthorized_error:
            resp.status = falcon.HTTP_401
        resp.media = output


class ReturnEmProgDropItem:
    _required_params = []
    _optional_params = ['name', 'start_date', 'end_date', 'comments', 'designation', 'team']
    _dot_string = '-----'
    _url = "http://172.16.44.80:8010/geocms/employeeprogress"
    #_url = "http://172.16.135.27:5223/geocms/employeeprogress"

    _page_list_items_to_database_entries_map_comments = {
        _dot_string: None,
        'Added': 'Not Null',
        'Not Added': 'Null'
    }

    def setDefaultValues(self):
        _optional_params_default_values = {
            'name': None,
            'start_date': None,
            'end_date': None,
            'comments': None,
            'designation': None,
            'team': None

        }
        return _optional_params_default_values

    @check_token_valid
    def _handleQuery(self, provided_params):
        print(provided_params)
        main_database.refreshDbConenction()
        provided_params = {**self.setDefaultValues(), **provided_params}
        _required_params = self._required_params
        # Checking whether we are getting all the required parameters. Incomplete parameters will result in an error
        all_params_provided = all([False if param not in provided_params else True for param in _required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        blank_response = {
            "url": self._url,
            "user": [self._dot_string],
            "comments": [self._dot_string],
            "level": [self._dot_string],
            "team": [self._dot_string]
        }
        if not all_params_provided:
            return {'Error': 'Missing Parameter. Make Sure all parameters are present. Valid parameters are '
                             '{0}'.format(', '.join(_required_params))}

        start_date = provided_params['start_date'] if provided_params['start_date'] not in [None, 'null'] else None
        end_date = provided_params['end_date'] if provided_params['end_date'] not in [None, 'null'] else None
        name = provided_params['name'].rstrip().lstrip() if provided_params['name'] not in [None, 'null',
                                                                                            self._dot_string] else None
        comments = provided_params['comments'].rstrip().lstrip() if provided_params['comments'] not in [None,
                                                                                                        'null',
                                                                                                        self._dot_string] else None
        designation = provided_params['designation'].rstrip().lstrip() if provided_params['designation'] not in [None,
                                                                                                                 'null',
                                                                                                                 self._dot_string] else None

        team = provided_params['team'].rstrip().lstrip() if provided_params['team'] not in [None,
                                                                                                                 'null',
                                                                                                                 self._dot_string] else None

        print(team)
        if start_date and isinstance(start_date, str):
            start_date = datetime.strptime(start_date, '%m/%d/%Y').date()
        if end_date and isinstance(start_date, str):
            end_date = datetime.strptime(end_date, '%m/%d/%Y').date()
        if comments:
            try:
                comments = self._page_list_items_to_database_entries_map_comments[comments]
            except:
                return blank_response
        print(provided_params)
        try:
            resp = main_database.DbResultsQuery(
                """SELECT fn_web_portal_search_populate_stats1(%s, %s, %s, %s, %s, %s)""",
                (start_date, end_date, designation, name, comments, team))
            final_resp = resp[0][0]
            if not final_resp:
                raise Exception('Empty Response')
            if not final_resp['comments']:
                final_resp['comments'] = [final_resp['comments']]
            comments_lst = [self._dot_string]
            for comment in final_resp['comments']:
                comments = [x for x in self._page_list_items_to_database_entries_map_comments.keys()
                            if self._page_list_items_to_database_entries_map_comments[x] == comment][0]
                comments_lst.append(comments)

            final_resp['comments'] = comments_lst
            final_resp['url'] = self._url

            for key in blank_response.keys():
                if key not in ['comments', 'url']:
                    final_resp[key] = [self._dot_string] + final_resp[key]
        except:
            main_database.refreshDbConenction()
            return blank_response
        return final_resp

    @api_logger
    def on_get(self, req, resp):
        params = req.params
        output = self._handleQuery(params)
        if output == conf.unauthorized_error:
            resp.status = falcon.HTTP_401
        resp.media = output

    @api_logger
    def on_post(self, req, resp):
        params = req.media
        output = self._handleQuery(params)
        if output == conf.unauthorized_error:
            resp.status = falcon.HTTP_401
        resp.media = output


class AddCommentEmployeeProgress:
    _required_params = ['ids', 'comment', 'user']
    _optional_params = []

    @check_token_valid
    def _handleQuery(self, provided_params):
        main_database.refreshDbConenction()

        _required_params = self._required_params
        # print(provided_params['token'])
        # print(provided_params['source'])
        # Checking whether we are getting all the required parameters. Incomplete parameters will result in an error
        all_params_provided = all([False if param not in provided_params else True for param in _required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        error_response = {
            "Error": None
        }
        if not all_params_provided:
            return {'Error': 'Missing Parameter. Make Sure all parameters are present. Valid parameters are '
                             '{0}'.format(', '.join(_required_params))}

        ids = provided_params['ids'] if provided_params['ids'] not in [None, 'null'] else None
        comment = provided_params['comment'] if provided_params['comment'] not in [None, 'null'] else None
        user = provided_params['user']

        if not ids:
            print({'Error': 'Provide valid inputs. Null ids are not allowed'})
            return {'Error': 'Provide valid inputs. Null ids are not allowed'}

        if not comment:
            comment = None

        if isinstance(ids, int):
            ids = [ids]
        else:
            ids = ids.split(',')

        for id in ids:
            try:
                try:
                    prev_comment = main_database.DbResultsQuery(
                        "SELECT comments FROM web_portal.general_monitoring where id = %s",
                        (id,))[0][0]
                except Exception as e:
                    prev_comment = None

                operation = 'INSERT' if not prev_comment else 'UPDATE'
                prev_comment = {'comments': prev_comment}
                new_comment = {'comments': comment}
                resp = main_database.DbResultsQueryForFunction(
                    """SELECT * FROM fn_web_portal_update_comments(%s, %s)""",
                    (id, comment))
                print('resp', resp)
                if resp[0][0] != 'done':
                    raise Exception(resp[0][0])

                prev_comment = dumps(prev_comment) if prev_comment is not None else prev_comment
                new_comment = dumps(new_comment) if new_comment is not None else new_comment

                main_database.DbModifyQuery("""INSERT INTO users_log_2019
                (tbname, username, operation, operation_time, feature_id, new_record, old_record, application, log_date)
                VALUES ('general_monitoring', %s, %s, now(), %s, %s, %s, 'Geo-CMS', now()::date)""",
                                            (user, operation, id, new_comment, prev_comment))
            except Exception as e:
                print(e)
                error_response['Error'] = str(e)
                main_database.refreshDbConenction()
                return error_response
        return {'Success': 'Ok'}

    @api_logger
    def on_get(self, req, resp):
        params = req.params
        resp.media = self._handleQuery(params)
    @api_logger
    def on_post(self, req, resp):
        params = req.media
        resp.media = self._handleQuery(params)


class SummaryStatsDateWise:
    _required_params = ['start_date', 'end_date', 'token']
    _optional_params = []
    _dot_string = '-----'

    def setDefaultValues(self):
        now = datetime.now().date() - dt.timedelta(days=7)
        start = now - dt.timedelta(days=now.weekday())
        end = start + dt.timedelta(days=6)

        _optional_params_default_values = {
            'start_date': start,
            'end_date': end
        }
        return _optional_params_default_values

    @check_token_valid
    def _handleQuery(self, provided_params):
        main_database.refreshDbConenction()
        if 'start_date' in provided_params.keys() and not provided_params['start_date']:
            provided_params.pop('start_date')
        if 'end_date' in provided_params.keys() and not provided_params['end_date']:
            provided_params.pop('end_date')
        print('start', provided_params)
        provided_params = {**self.setDefaultValues(), **provided_params}
        _required_params = self._required_params
        # Checking whether we are getting all the required parameters. Incomplete parameters will result in an error
        all_params_provided = all([False if param not in provided_params else True for param in _required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        blank_response = {
            "date": {
                "from": None,
                "to": None
            },
            "all_stats": {
                "All Images Added": 0,
                "All POIS digitized": 0,
                "VS Completed Data": 0,
                "VS all data": 0,
                "VS remaining data": 0
            },
            "carto": {
                "Carto Digitized": 0,
                "Carto Target": 0
            },
            "house": {
                "House Digitized": 0,
                "House Target": 0
            },
            "pois": {
                "Pois Digitized": 0,
                "Pois Target": 0
            },
            "roads": {
                "Roads Digitized": 0,
                "Roads Target": 0
            },
            "scale": {
                "Scale Digitized": 0,
                "Scale Target": 0
            },
            "video_survey": {
                "Completed VS": 0,
                "Total VS": 0
            }
        }
        if not all_params_provided:
            return {'Error': 'Missing Parameter. Make Sure all parameters are present. Valid parameters are '
                             '{0}'.format(', '.join(_required_params))}

        start_date = provided_params['start_date'] if provided_params['start_date'] not in [None, 'null', ''] else None
        end_date = provided_params['end_date'] if provided_params['end_date'] not in [None, 'null', ''] else None
        if start_date and isinstance(start_date, str):
            start_date = datetime.strptime(start_date, '%m/%d/%Y').date()
        if end_date and isinstance(end_date, str):
            end_date = datetime.strptime(end_date, '%m/%d/%Y').date()
        # print('asdasdasd',start_date, type(start_date))
        # print('asdasdasd',end_date, type(end_date))
        start_date_back = '{0}/{1}/{2}'.format(start_date.month, start_date.day, start_date.year)
        end_date_back = '{0}/{1}/{2}'.format(end_date.month, end_date.day, end_date.year)
        try:
            print("""SELECT fn_web_portal_stats_summary_charts(%s, %s)""" %
                  (start_date, end_date))
            resp = main_database.DbResultsQuery(
                """SELECT * from fn_web_portal_stats_summary_charts(%s, %s)""",
                (start_date, end_date))
            final_resp = resp[0][0][0]
            if not final_resp:
                raise Exception('Empty Response')
            final_resp['all_stats']["All Images Added"] = round(final_resp['all_stats']["All Images Added"], 2)
            final_resp['all_stats']["All POIS digitized"] = round(final_resp['all_stats']["All POIS digitized"], 2)
            final_resp['all_stats']["VS Completed Data"] = round(final_resp['all_stats']["VS Completed Data"], 2)
            final_resp['all_stats']["VS all data"] = round(final_resp['all_stats']["VS all data"], 2)
            final_resp['all_stats']["VS remaining data"] = round(final_resp['all_stats']["VS remaining data"], 2)
            final_resp['date'] = {'from': start_date_back, 'to': end_date_back}

        except:
            main_database.refreshDbConenction()
            return blank_response
        return final_resp

    @api_logger
    def on_get(self, req, resp):
        params = req.params
        output = self._handleQuery(params)
        if output == conf.unauthorized_error:
            resp.status = falcon.HTTP_401
        resp.media = output

    @api_logger
    def on_post(self, req, resp):
        params = req.media
        output = self._handleQuery(params)
        if output == conf.unauthorized_error:
            resp.status = falcon.HTTP_401
        resp.media = output


class CheckUserPremissionPage:
    _required_params = ['page', 'user']
    print("1", _required_params)
    _optional_params = []
    _dot_string = False

    def setDefaultValues(self):
        _optional_params_default_values = {
            'permission': False
        }
        return _optional_params_default_values

    @check_token_valid
    def _handleQuery(self, provided_params):
        main_database.refreshDbConenction()
        provided_params = {**self.setDefaultValues(), **provided_params}
        _required_params = self._required_params
        # Checking whether we are getting all the required parameters. Incomplete parameters will result in an error
        all_params_provided = all([False if param not in provided_params else True for param in _required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        blank_response = {
            "permission": False
        }
        if not all_params_provided:
            return {'Error': 'Missing Parameter. Make Sure all parameters are present. Valid parameters are '
                             '{0}'.format(', '.join(_required_params))}

        page = provided_params['page'] if provided_params['page'] not in [None, 'null'] else None
        print("p",page)
        user = provided_params['user'] if provided_params['user'] not in [None, 'null'] else None
        print("1", user)
        if not page and not user:
            raise Exception('Wrong Credentials')
        try:
            resp = main_database.DbResultsQuery(
                """select * from fn_web_portal_get_user_access(%s, %s)""",
                (page, user))
            print("qwe", resp)
            final_resp = resp[0][0]
            if not final_resp:
                raise Exception('Empty Response')
            final_resp['permission'] = final_resp['permission'] if final_resp['permission'] is not None else False
        except Exception as e:
            print(e)
            main_database.refreshDbConenction()
            return blank_response
        return final_resp

    @api_logger
    def on_get(self, req, resp):
        params = req.params
        output = self._handleQuery(params)
        if output == conf.unauthorized_error:
            resp.status = falcon.HTTP_401
        resp.media = output

    @api_logger
    def on_post(self, req, resp):
        params = req.media
        output = self._handleQuery(params)
        if output == conf.unauthorized_error:
            resp.status = falcon.HTTP_401
        resp.media = output


class CheckUserPages:
    _required_params = ['user']
    print(_required_params)
    _optional_params = []
    _dot_string = False

    def setDefaultValues(self):
        _optional_params_default_values = {
            'pages_name_': False
        }
        return _optional_params_default_values

    @check_token_valid
    def _handleQuery(self, provided_params):
        main_database.refreshDbConenction()
        provided_params = {**self.setDefaultValues(), **provided_params}
        _required_params = self._required_params
        # Checking whether we are getting all the required parameters. Incomplete parameters will result in an error
        all_params_provided = all([False if param not in provided_params else True for param in _required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        blank_response = {
            "pages_name_": []
        }
        if not all_params_provided:
            return {'Error': 'Missing Parameter. Make Sure all parameters are present. Valid parameters are '
                             '{0}'.format(', '.join(_required_params))}

        user = provided_params['user'] if provided_params['user'] not in [None, 'null'] else None
        print(user)
        if not user:
            raise Exception('Wrong Credentials')
        try:
            resp = main_database.DbResultsQuery(
                """select fn_web_portal_get_users_pages(%s)""",
                (user,))
            print(resp)
            final_resp = resp[0][0]
            if not final_resp['pages_name_']:
                raise Exception('Empty Response')
            if not final_resp:
                raise Exception('Empty Response')
        except Exception as e:
            print(e)
            main_database.refreshDbConenction()
            return blank_response
        return final_resp

    @api_logger
    def on_get(self, req, resp):
        params = req.params
        output = self._handleQuery(params)
        if output == conf.unauthorized_error:
            resp.status = falcon.HTTP_401
        resp.media = output

    @api_logger
    def on_post(self, req, resp):
        params = req.media
        output = self._handleQuery(params)
        if output == conf.unauthorized_error:
            resp.status = falcon.HTTP_401
        resp.media = output


class CheckTokenValidity:
    _required_params = ['user']
    _optional_params = []
    _dot_string = False

    def setDefaultValues(self):
        _optional_params_default_values = {
            'pages_name_': False
        }
        return _optional_params_default_values

    def _handleQuery(self, provided_params):
        main_database.refreshDbConenction()
        provided_params = {**self.setDefaultValues(), **provided_params}
        _required_params = self._required_params
        # Checking whether we are getting all the required parameters. Incomplete parameters will result in an error
        all_params_provided = all([False if param not in provided_params else True for param in _required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        blank_response = {
            "pages_name_": []
        }
        if not all_params_provided:
            return {'Error': 'Missing Parameter. Make Sure all parameters are present. Valid parameters are '
                             '{0}'.format(', '.join(_required_params))}

        user = provided_params['user'] if provided_params['user'] not in [None, 'null'] else None
        if not user:
            raise Exception('Wrong Credentials')
        try:
            resp = main_database.DbResultsQuery(
                """select fn_web_portal_get_users_pages(%s)""",
                (user,))
            final_resp = resp[0][0]
            if not final_resp['pages_name_']:
                raise Exception('Empty Response')
            if not final_resp:
                raise Exception('Empty Response')
        except Exception as e:
            print(e)
            main_database.refreshDbConenction()
            return blank_response
        return final_resp

    @api_logger
    def on_get(self, req, resp):
        params = req.params
        output = self._handleQuery(params)
        if output == conf.unauthorized_error:
            resp.status = falcon.HTTP_401
        resp.media = output

    @api_logger
    def on_post(self, req, resp):
        params = req.media
        output = self._handleQuery(params)
        if output == conf.unauthorized_error:
            resp.status = falcon.HTTP_401
        resp.media = output


class SurveyPlanningRecords:
    _required_params = ['start_date', 'end_date', 'city', 'area','token']
    _optional_params = []
    _dot_string = '-----'

    @check_token_valid
    def _handleQuery(self, provided_params):
        main_database.refreshDbConenction()
        _required_params = self._required_params
        # Checking whether we are getting all the required parameters. Incomplete parameters will result in an error
        all_params_provided = all([False if param not in provided_params else True for param in _required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        blank_response = {
        }
        if not all_params_provided:
            return {'Error': 'Missing Parameter. Make Sure all parameters are present. Valid parameters are '
                             '{0}'.format(', '.join(_required_params))}

        start_date = provided_params['start_date'] if provided_params['start_date'] else None
        end_date = provided_params['end_date'] if provided_params['end_date'] else None
        city = provided_params['city'] if provided_params['city'] else None
        area = provided_params['area'] if provided_params['area'] else None

        if not start_date or not end_date or not city:
            return {'Error': 'Null values are not allowed for dates and city'}
        if not area:
            area = self._dot_string
        try:
            resp = main_database.DbResultsQuery(
                """select fn_survey_planning(%s, %s, %s, %s)""",
                (start_date, end_date, city, area))
            final_resp = resp[0][0]
            print(resp)
            if not final_resp:
                raise Exception('Empty Response')
        except Exception as e:
            print(e)
            main_database.refreshDbConenction()
            return blank_response
        return final_resp

    @api_logger
    def on_get(self, req, resp):
        params = req.params
        output = self._handleQuery(params)
        if output == conf.unauthorized_error:
            resp.status = falcon.HTTP_401
        resp.media = output

    @api_logger
    def on_post(self, req, resp):
        params = req.media
        output = self._handleQuery(params)
        if output == conf.unauthorized_error:
            resp.status = falcon.HTTP_401
        resp.media = output

class LatLng:
    _required_params = ['points']
    _dot_string = '-----'
    dir = os.path.dirname(__file__)

    def _handleQuery(self, provided_params):
        _required_params = self._required_params
        # Checking whether we are getting all the required parameters. Incomplete parameters will result in an error
        all_params_provided = all([False if param not in provided_params else True for param in _required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        if not all_params_provided:
            return {'Error': 'Missing Parameter. Make Sure all parameters are present. Valid parameters are '
                             '{0}'.format(', '.join(_required_params))}

        points = provided_params['points']
        print(type(points))
        print(points)
        x = points.split(",")[0]
        print("x",type(x))
        lis = x.split(".")[0]
        print("lis", lis)
        lis1 = lis.isdigit()

        if (lis1==True):
            print("if")
            point1 = float(points.split(",")[0])
            point2 = float(points.split(",")[1])
            points = (point1, point2)

            print(points)
            points = Point(points)
            sample_dict = {"compound_address_parents": "Coordinates Location",
                           "lng": 73.2242557136262,
                           "fkey": 1001683319,
                           "name": "Coordinates Location",
                           "id": 5607569,
                           "lat": 34.16841091124579}
            sample_dict["lat"] = point1
            sample_dict["lng"] = point2
            # mypoint = Feature(geometry=points,lat=point1, lng=point2)
            # print(type(mypoint))
            # response = json.dumps([sample_dict])
            print(sample_dict)
            return [sample_dict]
        else:
            print("else")
            geo = requests.get('https://api1.tplmaps.com:8888/search?name='+points+'&location=33.72084085068317;73.0589069333577&apikey=%242a%2410%24bWCSBfSJFAHSsa8yD3g3Sej2QfUC2vGJp1VoJHsZFlw9gwl7XBST2').json()

            return(geo)

    def on_get(self, req, resp):
        params = req.params
        resp.media = self._handleQuery(params)

    def on_post(self, req, resp):
        params = req.media
        resp.media = self._handleQuery(params)






class SavePriority:
    _required_params = ['id', 'pro', 'token', 'source']
    _dot_string = '-----'
    dir = os.path.dirname(__file__)

    @check_token_valid
    def _handleQuery(self, provided_params):
        print(provided_params)
        main_database.refreshDbConenction()
        _required_params = self._required_params
        # Checking whether we are getting all the required parameters. Incomplete parameters will result in an error
        all_params_provided = all([False if param not in provided_params else True for param in _required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        if not all_params_provided:
            return {'Error': 'Missing Parameter. Make Sure all parameters are present. Valid parameters are '
                             '{0}'.format(', '.join(_required_params))}
        id = provided_params['id'] if provided_params['id'] else None
        priority = provided_params['pro'] if provided_params['pro'] else None
        
        print("""update web_portal.webprogress_gis_grids set priority ='{0}' where id = {1}  """.format(priority, id))
        resp = main_database.DbModifyQuery("""update web_portal.webprogress_gis_grids set priority ='{0}' where id = {1}  """.format(priority, id))
        

    @api_logger
    def on_get(self, req, resp):
        params = req.params
        resp.media = self._handleQuery(params)

    @api_logger
    def on_post(self, req, resp):
        params = req.media
        resp.media = self._handleQuery(params) 




class polygoon:
    _required_params = ['id', 'pro', 'token', 'source']
    _dot_string = '-----'
    dir = os.path.dirname(__file__)

    @check_token_valid
    def _handleQuery(self, provided_params):
        print(provided_params)
        main_database.refreshDbConenction()
        _required_params = self._required_params
        # Checking whether we are getting all the required parameters. Incomplete parameters will result in an error
        all_params_provided = all([False if param not in provided_params else True for param in _required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        if not all_params_provided:
            return {'Error': 'Missing Parameter. Make Sure all parameters are present. Valid parameters are '
                             '{0}'.format(', '.join(_required_params))}
        id = provided_params['id'] if provided_params['id'] else None
        priority = provided_params['pro'] if provided_params['pro'] else None
        print(id)
        print(priority)
        resp = main_database.DbModifyQuery("""select * from fn_grid_priority_update('{0}','{1}')""".format(id, priority))
        print( """select * from fn_grid_priority_update('{0}','{1}')""".format(id, priority))
    
    @api_logger
    def on_get(self, req, resp):
        params = req.params
        resp.media = self._handleQuery(params)
    
    @api_logger
    def on_post(self, req, resp):
        params = req.media
        resp.media = self._handleQuery(params)

class userip:
    _required_params = ['username']
    _dot_string = '-----'
    dir = os.path.dirname(__file__)

    def _handleQuery(self, provided_params):
        print(provided_params)
        main_database.refreshDbConenction()
        _required_params = self._required_params
        # Checking whether we are getting all the required parameters. Incomplete parameters will result in an error
        all_params_provided = all([False if param not in provided_params else True for param in _required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        if not all_params_provided:
            return {'Error': 'Missing Parameter. Make Sure all parameters are present. Valid parameters are '
                             '{0}'.format(', '.join(_required_params))}
        name = provided_params['username'] if provided_params['username'] else None
        
        print("name is here", name)
        url = 'http://172.16.130.52:3000/db_user?select=db_username,table_access,server_access&db_username=fts."'+name+'"'
        print(url)
        req = requests.get(url).json()
        # response = requests.get(url).json()
        
        print(req)
        return req

    def on_get(self, req, resp):
        params = req.params
        resp.media = self._handleQuery(params)

    def on_post(self, req, resp):
        params = req.media
        resp.media = self._handleQuery(params)   


class userdata:
    _required_params = ['username', 'ip']
    _dot_string = '-----'
    dir = os.path.dirname(__file__)

    def _handleQuery(self, provided_params):
        print(provided_params)
        main_database.refreshDbConenction()
        _required_params = self._required_params
        # Checking whether we are getting all the required parameters. Incomplete parameters will result in an error
        all_params_provided = all([False if param not in provided_params else True for param in _required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        if not all_params_provided:
            return {'Error': 'Missing Parameter. Make Sure all parameters are present. Valid parameters are '
                             '{0}'.format(', '.join(_required_params))}
        username = provided_params['username'] if provided_params['username'] else None
        ip = provided_params['ip'] if provided_params['ip'] else None
        
        print("name ", username)
        print("ip" , ip)
        if ip == '172.16.130.23':
            ip = '172.16.130.52'

        # url = f'http://'+ip+':3000/rpc/fn_track_points2'
        # print(url)
        # jbody = {"username": username}
        # req = requests.post(url,  json=jbody).json()
        # # # response = requests.get(url).json()
        
        # # print(req)
        # # print(req[0]['fn_track_points'])
        # # req = req[0]['fn_track_points']
        # print("points", req)
        # return req
        resp = main_database.DbResultsQuery("""select * from fn_track_points2('{0}')""".format(username))
        print ("""select * from fn_track_points2('{0}')""".format(username))
        print("resp here",resp)
        final_resp = resp[0][0]
        return final_resp

    def on_get(self, req, resp):
        params = req.params
        resp.media = self._handleQuery(params)

    def on_post(self, req, resp):
        params = req.media
        resp.media = self._handleQuery(params)  


class returngrid:
    _required_params = ['latlng']
    _dot_string = '-----'
    dir = os.path.dirname(__file__)

    def _handleQuery(self, provided_params):
        print(provided_params)
        main_database.refreshDbConenction()
        _required_params = self._required_params
        # Checking whether we are getting all the required parameters. Incomplete parameters will result in an error
        all_params_provided = all([False if param not in provided_params else True for param in _required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        if not all_params_provided:
            return {'Error': 'Missing Parameter. Make Sure all parameters are present. Valid parameters are '
                             '{0}'.format(', '.join(_required_params))}
        latlng = provided_params['latlng'] if provided_params['latlng'] else None
        
        
        print("latlng here ", latlng)
        
        
       
        # url = f'http://172.16.130.52:3000/rpc/fn_return_grids2'
        # print(url)
        # jbody = {"raw_latlng": latlng}
        # req = requests.post(url,  json=jbody).json()
        # # # response = requests.get(url).json()
        
        # print(req)
        # # print(req[0]['fn_track_points'])
        # # req = req[0]['fn_track_points']
        # return req
        resp = main_database.DbResultsQuery("""select * from fn_return_grids2('{0}')""".format(latlng))
        print ("""select * from fn_return_grids2('{0}')""".format(latlng))
        # print("resp here",resp)
        
        final_resp = resp[0][0]
        return final_resp

    def on_get(self, req, resp):
        params = req.params
        resp.media = self._handleQuery(params)

    def on_post(self, req, resp):
        params = req.media
        resp.media = self._handleQuery(params)  


class returndata:
    _required_params = ['username', 'gridid', 'snap']
    _dot_string = '-----'
    dir = os.path.dirname(__file__)

    def _handleQuery(self, provided_params):
        print(provided_params)
        main_database.refreshDbConenction()
        _required_params = self._required_params
        # Checking whether we are getting all the required parameters. Incomplete parameters will result in an error
        all_params_provided = all([False if param not in provided_params else True for param in _required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        if not all_params_provided:
            return {'Error': 'Missing Parameter. Make Sure all parameters are present. Valid parameters are '
                             '{0}'.format(', '.join(_required_params))}
        username = provided_params['username'] if provided_params['username'] else None
        gridid = provided_params['gridid'] if provided_params['gridid'] else None
        snap = provided_params['snap'] if provided_params['snap'] else None
        
        
        print("username ", username)
        print("gridid ", gridid)
        print("snap ", snap)
        
        
        
       
        url = f'http://172.16.130.52:3000/rpc/fn_get_user_points'
        print(url)
        jbody = {"username": username,
                 "grid_id": gridid,
                  "snap_": snap
                  }
        req = requests.post(url,  json=jbody).json()
        # # # response = requests.get(url).json()
        
        # # print(req[0]['fn_track_points'])
        # # req = req[0]['fn_track_points']
        return req

    def on_get(self, req, resp):
        params = req.params
        resp.media = self._handleQuery(params)

    def on_post(self, req, resp):
        params = req.media
        resp.media = self._handleQuery(params)




class ReturnImage:
    # List of all the required parameters in each request
    _required_params = ['id']
    _optional_params = ['width', 'height', 'frame']

    blank_response = {
        "Images": [
        ]
    }

    def checkParamsMissing(self, params):
        all_params_provided = all([False if param not in params else True for param in self._required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        if not all_params_provided:
            return {'Error': 'Missing Parameter. Make Sure all parameters are present. Valid parameters are '
                             '{0}'.format(', '.join(self._required_params))}
        return False

    def _parseVideo(self, videoPath):
        video = VideoFileClip(videoPath)
        date_time = os.path.basename(videoPath).split('.')[0].replace('VID_', '')
        try:
            date_time = dt.datetime.strptime(date_time, "%Y%m%d_%H%M%S")
        except:
            date_time = dt.datetime.strptime('_'.join(date_time.split('_')[1:]), "%Y%m%d_%H%M%S")
        return video, date_time.timestamp()

    def epochSecondToFrameNum(self, frame_sec, vid_st_time):
        seconds = frame_sec - vid_st_time
        if seconds > -1:
            return int(seconds)
        return None

    def _getVideo_Time(self, fid):
        try:
            main_database.refreshDbConenction()
            response = main_database.DbResultsQuery("SELECT file_dir_name, datetime "
                                                    "FROM video_track_points "
                                                    "WHERE id = %s", (fid,))[0]
            fileName = response[0]
            date_time = response[1].timestamp()
            response = None
            return fileName, date_time
        except:
            return None, None

    
    def _handleQuery(self, provided_params):
        scaled_width = scaled_height = None
        params_missing = self.checkParamsMissing(provided_params)
        if params_missing:
            return params_missing
        pt_id = provided_params['id']
        if self._optional_params[0] in provided_params.keys() and self._optional_params[1] in provided_params.keys():
            scaled_width = provided_params[self._optional_params[0]]
            scaled_height = provided_params[self._optional_params[1]]
        frame_num = 1 if 'frame' not in provided_params.keys() else int(provided_params['frame'])
        fileName, date_time = self._getVideo_Time(pt_id)
        print(fileName, date_time, 'dile_date')
        if not fileName:
            print('here')
            # return {'Error': 'Provided Id has no associated Video File'}
            return getImageStream(not_found)
        if not date_time:
            # return {'Error': 'Provided Id has no associated Time'}
            return getImageStream(not_found)
        # Fetching Video Object along with the Video Start Ttime
        video, video_start_time = self._parseVideo(fileName)
        if frame_num > video.fps:
            return getImageStream(not_found)
        # Getting frame to fetch
        frame_time = self.epochSecondToFrameNum(frame_sec=date_time, vid_st_time=video_start_time)
        if not frame_time:
            # return {'Error': 'Provided Id has no associated Frame'}
            return getImageStream(not_found)
        if frame_time == 1:
            frame = video.get_frame(frame_time)
        else:
            frame = [x for x in video.subclip(frame_time, frame_time + 1).iter_frames()][frame_num - 1]

        # Video attributes
        width = video.w
        height = video.h
        bytesPerLine = 3 * width
        # Converting the image provided by the library into a valid Image
        pix = QImage(frame, width, height, bytesPerLine, QImage.Format_RGB888)
        if scaled_height and scaled_width:
            pix = pix.scaled(int(scaled_width), int(scaled_height))
        video.close()
        return getImageStream(pix)

    
    def on_get(self, req, resp):
        params = req.params
        bla = self._handleQuery(params)
        if not bla or isinstance(bla, dict):
            bla = getImageStream(not_authorized)
        resp.content_type = 'image/jpeg'
        resp.stream, resp.stream_len = bla

   
    def on_post(self, req, resp):
        params = req.media
        bla = self._handleQuery(params)
        if not bla or isinstance(bla, dict):
            resp.media = bla
            return
        elif not bla:
            bla = getImageStream(not_authorized)
        resp.content_type = 'image/jpeg'
        resp.stream, resp.stream_len = bla


class addressdata:
    _required_params = ['textid']
    _dot_string = '-----'
    dir = os.path.dirname(__file__)

    def _handleQuery(self, provided_params):
        print(provided_params)
        main_database.refreshDbConenction()
        _required_params = self._required_params
        # Checking whether we are getting all the required parameters. Incomplete parameters will result in an error
        all_params_provided = all([False if param not in provided_params else True for param in _required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        if not all_params_provided:
            return {'Error': 'Missing Parameter. Make Sure all parameters are present. Valid parameters are '
                             '{0}'.format(', '.join(_required_params))}
        textid = provided_params['textid'] if provided_params['textid'] else None
       
        
        
        print("textid ", textid)

        resp = main_database.DbResultsQuery("""SELECT tpl_subcat, priority, email, url, telephone, fax, tags, descriptio FROM pois_v6_test WHERE id={0}""".format(textid))
        print (("""SELECT tpl_subcat, priority, email, url, telephone, fax, tags, descriptio FROM pois_v6_test WHERE id={0}""".format(textid)))
        # print("resp here",resp)
        
        # final_resp = resp[0][0]
        return resp[0]

    def on_get(self, req, resp):
        params = req.params
        resp.media = self._handleQuery(params)

    def on_post(self, req, resp):
        params = req.media
        resp.media = self._handleQuery(params)    


class addressupdate:
    _required_params = ['name','cat','priority','email','url','telephone','fax','tags','descriptio','textid','username']
    _dot_string = '-----'
    dir = os.path.dirname(__file__)

    def _handleQuery(self, provided_params):
        print(provided_params)
        main_database.refreshDbConenction()
        _required_params = self._required_params
        # Checking whether we are getting all the required parameters. Incomplete parameters will result in an error
        all_params_provided = all([False if param not in provided_params else True for param in _required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        if not all_params_provided:
            return {'Error': 'Missing Parameter. Make Sure all parameters are present. Valid parameters are '
                             '{0}'.format(', '.join(_required_params))}
        name = provided_params['name'] if provided_params['name'] else None
        cat = provided_params['cat'] if provided_params['cat'] else None
        priority = provided_params['priority'] if provided_params['priority'] else None
        email = provided_params['email'] if provided_params['email'] else ''
        url = provided_params['url'] if provided_params['url'] else ''
        telephone = provided_params['telephone'] if provided_params['telephone'] else ''
        fax = provided_params['fax'] if provided_params['fax'] else ''
        tags = provided_params['tags'] if provided_params['tags'] else ''
        descriptio = provided_params['descriptio'] if provided_params['descriptio'] else ''
        textid = provided_params['textid'] if provided_params['textid'] else None
        username = provided_params['username'] if provided_params['username'] else None
       
        
        
        print("textid ", textid)

        resp = main_database.DbModifyQuery("""update pois_v6_test set name_displ = '{0}', tpl_subcat = '{1}', priority = {2}, email = '{3}', url = '{4}', telephone = '{5}', fax='{6}', tags= '{7}', descriptio = '{8}', updated_by = '{9}' where id = {10}""".format(name, cat, priority,email,url,telephone,fax,tags,descriptio,username,textid))

        print ("""update pois_v6_test set name_displ = '{0}', tpl_subcat = '{1}', priority = {2}, email = '{3}', url = '{4}', telephone = '{5}', fax='{6}', tags= '{7}', descriptio = '{8}' , updated_by = '{9}' where id = {10}""".format(name, cat, priority,email,url,telephone,fax,tags,descriptio,username,textid))
        # print("resp here",resp)
        
        # final_resp = resp[0][0]
        return True        
        
        

    def on_get(self, req, resp):
        params = req.params
        resp.media = self._handleQuery(params)

    def on_post(self, req, resp):
        params = req.media
        resp.media = self._handleQuery(params)


class addressinsert:
    _required_params = ['name','name_displ','tpl_subcat','priority','email','telephone','url','fax','geom', 'lng','primary_source','secondary_source','data_status','address','tags','descriptio', 'location', 'username']
    _dot_string = '-----'
    dir = os.path.dirname(__file__)

    def _handleQuery(self, provided_params):
        print(provided_params)
        main_database.refreshDbConenction()
        print("1")
        _required_params = self._required_params
        print("2")
        # Checking whether we are getting all the required parameters. Incomplete parameters will result in an error
        all_params_provided = all([False if param not in provided_params else True for param in _required_params])
        print("3", all_params_provided)
        # If we are not getting all the parameters, we gracefully exit with an error statement
        # if not all_params_provided:
        #     return {'Error': 'Missing Parameter. Make Sure all parameters are present. Valid parameters are '
        #                      '{0}'.format(', '.join(_required_params))}
        print("4")                     
        name = provided_params['name'] if provided_params['name'] else None
        print(name)
        name_displ = provided_params['name_displ'] if provided_params['name_displ'] else None
        print(name_displ)
        tpl_subcat = provided_params['tpl_subcat'] if provided_params['tpl_subcat'] else None
        print(tpl_subcat)
        priority = provided_params['priority'] if provided_params['priority'] else None
        print(priority)
        email = provided_params['email'] if provided_params['email'] else ''
        print(email)
        url = provided_params['url'] if provided_params['url'] else ''
        print(url)
        telephone = provided_params['telephone'] if provided_params['telephone'] else ''
        print(telephone)
        fax = provided_params['fax'] if provided_params['fax'] else ''
        print(fax)
        geom = provided_params['geom'] if provided_params['geom'] else None
        print(geom)
        lng =  provided_params['lng'] if provided_params['lng'] else None
        print(lng)
        primary_source = provided_params['primary_source'] if provided_params['primary_source'] else ''
        print(primary_source)
        secondary_source = provided_params['secondary_source'] if provided_params['secondary_source'] else ''
        print(secondary_source)
        data_status = provided_params['data_status'] if provided_params['data_status'] else ''
        print(data_status)
        address = provided_params['address'] if provided_params['address'] else ''
        print(address)
        tags = provided_params['tags'] if provided_params['tags'] else ''
        print(tags)
        descriptio = provided_params['descriptio'] if provided_params['descriptio'] else ''
        print(descriptio)
        location = provided_params['location'] if provided_params['location'] else None
        print(location)
        username = provided_params['username'] if provided_params['username'] else None
        print(username)
       
        
        
        
        
        resp = main_database.DbModifyQuery("""INSERT INTO pois_v6_test (name,name_displ,tpl_subcat,priority,email,telephone,url,fax,geom,primary_source,secondary_source,data_status,address,tags,descriptio, location, added_by) values ('{0}','{1}','{2}',{3},'{4}','{5}','{6}','{7}',St_transform(ST_SetSRID(ST_MakePoint({9},{8}), 4326),3857),'{10}','{11}','{12}','{13}','{14}','{15}','{16}','{17}')""".format(name.upper(),name_displ,tpl_subcat,priority,email,telephone,url,fax,geom,lng,primary_source,secondary_source,data_status,address,tags,descriptio, location, username))
        print(resp)
        print ("""INSERT INTO pois_v6_test (name,name_displ,tpl_subcat,priority,email,telephone,url,fax,geom,primary_source,secondary_source,data_status,address,tags,descriptio, location, added_by) values ('{0}','{1}','{2}',{3},'{4}','{5}','{6}','{7}',St_transform(ST_SetSRID(ST_MakePoint({9},{8}), 4326),3857),'{10}','{11}','{12}','{13}','{14}','{15}','{16}', '{17}')""".format(name.upper(),name_displ,tpl_subcat,priority,email,telephone,url,fax,geom,lng,primary_source,secondary_source,data_status,address,tags,descriptio, location ,username))
        # print("resp here",resp)
        
        # final_resp = resp[0][0]
        return True        
        
        

    def on_get(self, req, resp):
        params = req.params
        resp.media = self._handleQuery(params)

    def on_post(self, req, resp):
        params = req.media
        resp.media = self._handleQuery(params)



class userreturn:
    _required_params = []
    _dot_string = '-----'
    dir = os.path.dirname(__file__)

    def _handleQuery(self, provided_params):
        print(provided_params)
        main_database.refreshDbConenction()
        _required_params = self._required_params
        # Checking whether we are getting all the required parameters. Incomplete parameters will result in an error
        all_params_provided = all([False if param not in provided_params else True for param in _required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        if not all_params_provided:
            return {'Error': 'Missing Parameter. Make Sure all parameters are present. Valid parameters are '
                             '{0}'.format(', '.join(_required_params))}
        
        
        
        
        output = []
        resp = main_database.DbResultsQuery("""select db_username from db_user""")
        print ("""select db_username from db_user""")
        for i in range(len(resp)): #Traversing through the main list
            for j in range (len(resp[i])): #Traversing through each sublist
                output.append(resp[i][j]) 
        
        return output       
       
        
    def on_get(self, req, resp):
        params = req.params
        resp.media = self._handleQuery(params)

    def on_post(self, req, resp):
        params = req.media
        resp.media = self._handleQuery(params)

class pluginupdate:
    _required_params = ['name', 'pluginname' , 'usname', 'date', 'timer']
    _dot_string = '-----'
    dir = os.path.dirname(__file__)


    def _handleQuery(self, provided_params):
        main_database.refreshDbConenction()
        _required_params = self._required_params
        # Checking whether we are getting all the required parameters. Incomplete parameters will result in an error
        all_params_provided = all([False if param not in provided_params else True for param in _required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        if not all_params_provided:
            return {'Error': 'Missing Parameter. Make Sure all parameters are present. Valid parameters are '
                             '{0}'.format(', '.join(_required_params))}
        name = provided_params['name'] if provided_params['name'] else None
        print(name)
        pluginname = provided_params['pluginname'] if provided_params['pluginname'] else None
        usname = provided_params['usname'] if provided_params['usname'] else None
        date1 = datetime.today().strftime('%Y-%m-%d')
        print(date1)
        now = datetime.now()
        print(now)
        year = now + relativedelta(months=2)
        years = year.strftime('%Y-%m-%d')
        hr = ''
        date = provided_params['date'] if provided_params['date'] else years
        
        two_hours_from_now = datetime.now() + timedelta(hours=2)
        tim = two_hours_from_now.strftime("%H:%M")


        timer = provided_params['timer'] if provided_params['timer'] else tim
        dic = {"rooha.waseem" : "U018JQA2666", "hassam.raza" : "UA8R1AA4V", "iftikhar.fahad": "U01DLUB3HQE","arsalan.mukhtar" : "U01GS0Z0J3C" ,
            "humaira.akram"  : "UQKCLCYTB" , "nazish.karimi" : "U4ZUDKL0H", "zulqarnain.hafeez" : "UFADHQ7RA",
           "asad.arsalan" : "UA8EPAG1M" , "haris.khan"  : "UN5RAS7U1", "atif.mehmood" :"UG4180X9U",
             "mehreen.tahir": "UG3L42F4P", "muhammad.waqas" : "UQHTQEM97", "rauman.khan" : "UKW026YHX", "sarmad.ali" :"UN9UDTKPV",
              "wajahat.usman" : "UTY73Q800", "asghar.ibraheem" : "U5191R70V",
              "laraib.kafeel" : "UFADH31KN", "huma.irshad" : "U50L4JTJ9", "haris.shafique" : "UA7CU4FAN",  "nazia.kiran"  : "U50G8DKB5",
              "rida.batool":"U9Y0F43TL", "junaid.abdul": "U50G51PSN", "muhammad.shams":"U9KTB4W13", "zain.abideen":"UKQTLGL66", "shahzad.bacha":"U4ZQM9Z96",
               "ayesha.yaqoob": "U4ZENFPB2", "muhammad.shaheer" : "UHJL2NU22", "talha.alvi" :"U9N6MH2PL","shehar.bano":"UL2ADU3CG", 
                 "sidra.ahmed":"U4ZUKRTA5", "sfaizan.ahmed": "U50JB1QSG",
                 "noman.shah":"UA6RJ8BMF", "sehar.rafiq":"UHH5SQ0RJ", "shahid.abbas": "U51912SS3", "muhammad.nouman":"U011WJXSQAG"}
       
        tok = dic[name]
        print(tok)
        
        resp = main_database.DbResultsQuery("""select permission_status from plugin_permit_status where username = '{0}' and plugin = '{1}' limit 1""".format(name, pluginname))
        print ("""select permission_status from plugin_permit_status where username = '{0}' and plugin = '{1}'""".format(name, pluginname))
        print("here", resp)
        
        if len(resp)==0:
                
                resp = main_database.DbModifyQuery("""INSERT INTO plugin_permit_status (username,plugin,permission_status,granted_by,granted_till,granted_at,permitted_time) values ('{0}','{1}', 'True','{2}','{3}'::timestamp,'{4}'::timestamp,'{5}'::time)""".format(name, pluginname, usname, date, now, timer)) 
                print ("""INSERT INTO plugin_permit_status (username,plugin,permission_status,granted_by,granted_till,granted_at,permitted_time) values ('{0}','{1}', 'True','{2}','{3}'::timestamp,'{4}'::timestamp,'{5}'::time)""".format(name, pluginname, usname, date, now, timer))            
                
                slack_token = 'xoxp-170652456870-670938564210-901381953591-29cf0d56fc0f0685856affff7ae3cd0a'
                sc = SlackClient(slack_token)

                sc.api_call(
                            "chat.postMessage",
                            channel="{0}".format(tok),
                            text="""Petitioner : {0}    Plugin Name Permission : {1}
                             Premission granted by : {2}""".format(name, pluginname, usname)
                        )
                return "Premisson Grant successfully"
         
        elif resp[0][0]=="True":
                return "Premisson Already Assigned"
                  
        
        

    def on_get(self, req, resp):
        params = req.params
        resp.media = self._handleQuery(params)

    def on_post(self, req, resp):
        params = req.media
        resp.media = self._handleQuery(params) 


class tabledata:
    _required_params = []
    _dot_string = '-----'
    dir = os.path.dirname(__file__)

    def _handleQuery(self, provided_params):
        print("1234",provided_params)
        main_database.refreshDbConenction()
        _required_params = self._required_params
        # Checking whether we are getting all the required parameters. Incomplete parameters will result in an error
        all_params_provided = all([False if param not in provided_params else True for param in _required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        if not all_params_provided:
            return {'Error': 'Missing Parameter. Make Sure all parameters are present. Valid parameters are '
                             '{0}'.format(', '.join(_required_params))}
      
       
       
        
        
        # resp = main_database.DbResultsQuery("""select id, username, plugin, permission_status, granted_at::varchar from plugin_permit_status""")
        # print ("""select id, username, plugin, permission_status, granted_at::varchar from plugin_permit_status""")
        resp = main_database.DbResultsQuery("""WITH foobar AS ( 
    SELECT id, username, plugin, granted_at, granted_till, granted_by , permitted_time
    FROM plugin_permit_status
    )
SELECT 
     json_build_object('data',array_agg(json_build_object('id', id, 'username', username,
                                                          'plugin', plugin, 'granted_at', granted_at, 'granted_till', granted_till, 'granted_by', granted_by, 'permitted_time', permitted_time)))
FROM 
    foobar""")
        print ("""WITH foobar AS ( 
    SELECT id, username, plugin, granted_at, granted_till, granted_by
    FROM plugin_permit_status
    )
SELECT 
     json_build_object('data',array_agg(json_build_object('id', id, 'username', username,
                                                          'plugin', plugin, 'granted_at', granted_at, 'granted_till', granted_till, 'granted_by', granted_by)))
FROM 
    foobar""")
        print("here", resp )
        return resp


    def on_get(self, req, resp):
        params = req.params
        resp.media = self._handleQuery(params)

    def on_post(self, req, resp):
        params = req.media
        resp.media = self._handleQuery(params) 


class deleteuser:
    _required_params = ['name', 'pluginname']
    _dot_string = '-----'
    dir = os.path.dirname(__file__)

    def _handleQuery(self, provided_params):
        print("1234",provided_params)
        main_database.refreshDbConenction()
        _required_params = self._required_params
        # Checking whether we are getting all the required parameters. Incomplete parameters will result in an error
        all_params_provided = all([False if param not in provided_params else True for param in _required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        if not all_params_provided:
            return {'Error': 'Missing Parameter. Make Sure all parameters are present. Valid parameters are '
                             '{0}'.format(', '.join(_required_params))}
        name = provided_params['name'] if provided_params['name'] else None
        pluginname = provided_params['pluginname'] if provided_params['pluginname'] else None
        dic = {"rooha.waseem" : "U018JQA2666", "hassam.raza" : "UA8R1AA4V", "iftikhar.fahad": "U01DLUB3HQE","arsalan.mukhtar" : "U01GS0Z0J3C" ,
            "humaira.akram"  : "UQKCLCYTB" , "nazish.karimi" : "U4ZUDKL0H", "zulqarnain.hafeez" : "UFADHQ7RA",
           "asad.arsalan" : "UA8EPAG1M" , "haris.khan"  : "UN5RAS7U1", "atif.mehmood" :"UG4180X9U",
             "mehreen.tahir": "UG3L42F4P", "muhammad.waqas" : "UQHTQEM97", "rauman.khan" : "UKW026YHX", "sarmad.ali" :"UN9UDTKPV",
              "wajahat.usman" : "UTY73Q800", "asghar.ibraheem" : "U5191R70V",
              "laraib.kafeel" : "UFADH31KN", "huma.irshad" : "U50L4JTJ9", "haris.shafique" : "UA7CU4FAN",  "nazia.kiran"  : "U50G8DKB5",
              "rida.batool":"U9Y0F43TL", "junaid.abdul": "U50G51PSN", "muhammad.shams":"U9KTB4W13", "zain.abideen":"UKQTLGL66", "shahzad.bacha":"U4ZQM9Z96",
               "ayesha.yaqoob": "U4ZENFPB2", "muhammad.shaheer" : "UHJL2NU22", "talha.alvi" :"U9N6MH2PL","shehar.bano":"UL2ADU3CG", 
                 "sidra.ahmed":"U4ZUKRTA5", "sfaizan.ahmed": "U50JB1QSG",
                 "noman.shah":"UA6RJ8BMF", "sehar.rafiq":"UHH5SQ0RJ", "shahid.abbas": "U51912SS3", "muhammad.nouman":"U011WJXSQAG"}
       
        tok = dic[name]
        print(tok)   
        resp = main_database.DbModifyQuery("""delete from plugin_permit_status where username = '{0}' and plugin = '{1}'""".format(name, pluginname))
        print ("""delete from plugin_permit_status where username = '{0}' and plugin = '{1}'""".format(name, pluginname))
        print("here", resp)
        slack_token = 'xoxp-170652456870-670938564210-901381953591-29cf0d56fc0f0685856affff7ae3cd0a'
        sc = SlackClient(slack_token)

        sc.api_call(
                    "chat.postMessage",
                    channel="{0}".format(tok),
                    text="""Petitioner : {0}    Revoke Plugin name : {1}
                    """.format(name, pluginname)
                )
       
        return "Successfully Revoke"
        
                  
        
        

    def on_get(self, req, resp):
        params = req.params
        resp.media = self._handleQuery(params)

    def on_post(self, req, resp):
        params = req.media
        resp.media = self._handleQuery(params) 


class slacknoti:
    _required_params = ['name', 'pluginname']
    _dot_string = '-----'
    dir = os.path.dirname(__file__)

    def _handleQuery(self, provided_params):
        print("1234",provided_params)
        main_database.refreshDbConenction()
        _required_params = self._required_params
        # Checking whether we are getting all the required parameters. Incomplete parameters will result in an error
        all_params_provided = all([False if param not in provided_params else True for param in _required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        if not all_params_provided:
            return {'Error': 'Missing Parameter. Make Sure all parameters are present. Valid parameters are '
                             '{0}'.format(', '.join(_required_params))}
        name = provided_params['name'] if provided_params['name'] else None
        pluginname = provided_params['pluginname'] if provided_params['pluginname'] else None
        print(name, pluginname)
        
       
       
        
        
        slack_token = 'xoxp-170652456870-670938564210-901381953591-29cf0d56fc0f0685856affff7ae3cd0a'
        sc = SlackClient(slack_token)

        sc.api_call(
            "chat.postMessage",
            channel="#plugin-permission-request",
            text="""Petitioner : {0}    Plugin Name Permission : {1}
             For Grant Permission Click here --> http://172.16.44.80:8000/webprogress/pluginper#""".format(name, pluginname)
        )
        
        return "message send"
        
                  
        
        

    def on_get(self, req, resp):
        params = req.params
        resp.media = self._handleQuery(params)

    def on_post(self, req, resp):
        params = req.media
        resp.media = self._handleQuery(params) 


class pluginreturn:
    _required_params = []
    _dot_string = '-----'
    dir = os.path.dirname(__file__)

    def _handleQuery(self, provided_params):
        print(provided_params)
        main_database.refreshDbConenction()
        _required_params = self._required_params
        # Checking whether we are getting all the required parameters. Incomplete parameters will result in an error
        all_params_provided = all([False if param not in provided_params else True for param in _required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        if not all_params_provided:
            return {'Error': 'Missing Parameter. Make Sure all parameters are present. Valid parameters are '
                             '{0}'.format(', '.join(_required_params))}
        
        
        
        
        output = []
        resp = main_database.DbResultsQuery("""select plugin from plugin_directory""")
        print ("""select plugin from plugin_directory""")
        for i in range(len(resp)): #Traversing through the main list
            for j in range (len(resp[i])): #Traversing through each sublist
                output.append(resp[i][j]) 
        
        return output       
       
        
    def on_get(self, req, resp):
        params = req.params
        resp.media = self._handleQuery(params)

    def on_post(self, req, resp):
        params = req.media
        resp.media = self._handleQuery(params)                              


class total:
    _required_params = []
    _dot_string = '-----'
    dir = os.path.dirname(__file__)

    def _handleQuery(self, provided_params):
        print(provided_params)
        main_database.refreshDbConenction()
        _required_params = self._required_params
        # Checking whether we are getting all the required parameters. Incomplete parameters will result in an error
        all_params_provided = all([False if param not in provided_params else True for param in _required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        if not all_params_provided:
            return {'Error': 'Missing Parameter. Make Sure all parameters are present. Valid parameters are '
                             '{0}'.format(', '.join(_required_params))}
        
        
        
        
        output = []
        resp = main_database.DbResultsQuery("""select count(plugin) from plugin_directory""")
        print ("""select plugin from plugin_directory""")
        for i in range(len(resp)): #Traversing through the main list
            for j in range (len(resp[i])): #Traversing through each sublist
                output.append(resp[i][j])
        
        return output[0]       
       
        
    def on_get(self, req, resp):
        params = req.params
        resp.media = self._handleQuery(params)

    def on_post(self, req, resp):
        params = req.media
        resp.media = self._handleQuery(params) 


class pluginupdate1:
    _required_params = ['name', 'pluginname' , 'usname', 'date','time']
    _dot_string = '-----'
    dir = os.path.dirname(__file__)


    def _handleQuery(self, provided_params):
        main_database.refreshDbConenction()
        _required_params = self._required_params
        # Checking whether we are getting all the required parameters. Incomplete parameters will result in an error
        all_params_provided = all([False if param not in provided_params else True for param in _required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        if not all_params_provided:
            return {'Error': 'Missing Parameter. Make Sure all parameters are present. Valid parameters are '
                             '{0}'.format(', '.join(_required_params))}
        name = provided_params['name'] if provided_params['name'] else None
        pluginname = provided_params['pluginname'] if provided_params['pluginname'] else None
        usname = provided_params['usname'] if provided_params['usname'] else None
        date1 = datetime.today().strftime('%Y-%m-%d')
        print(date1)
        now = datetime.now()
        print(now)
        year = now + relativedelta(months=2)
        years = year.strftime('%Y-%m-%d')
        two_hours_from_now = datetime.now() + timedelta(hours=2)
        tim = two_hours_from_now.strftime("%H:%M")
        
        date = provided_params['date'] if provided_params['date'] else years
        time = provided_params['time'] if provided_params['time'] else tim
        dic = {"rooha.waseem" : "U018JQA2666", "hassam.raza" : "UA8R1AA4V", "iftikhar.fahad": "U01DLUB3HQE","arsalan.mukhtar" : "U01GS0Z0J3C" ,
            "humaira.akram"  : "UQKCLCYTB" , "nazish.karimi" : "U4ZUDKL0H", "zulqarnain.hafeez" : "UFADHQ7RA",
           "asad.arsalan" : "UA8EPAG1M" , "haris.khan"  : "UN5RAS7U1", "atif.mehmood" :"UG4180X9U",
             "mehreen.tahir": "UG3L42F4P", "muhammad.waqas" : "UQHTQEM97", "rauman.khan" : "UKW026YHX", "sarmad.ali" :"UN9UDTKPV",
              "wajahat.usman" : "UTY73Q800", "asghar.ibraheem" : "U5191R70V",
              "laraib.kafeel" : "UFADH31KN", "huma.irshad" : "U50L4JTJ9", "haris.shafique" : "UA7CU4FAN",  "nazia.kiran"  : "U50G8DKB5",
              "rida.batool":"U9Y0F43TL", "junaid.abdul": "U50G51PSN", "muhammad.shams":"U9KTB4W13", "zain.abideen":"UKQTLGL66", "shahzad.bacha":"U4ZQM9Z96",
               "ayesha.yaqoob": "U4ZENFPB2", "muhammad.shaheer" : "UHJL2NU22", "talha.alvi" :"U9N6MH2PL","shehar.bano":"UL2ADU3CG", 
                 "sidra.ahmed":"U4ZUKRTA5", "sfaizan.ahmed": "U50JB1QSG",
                 "noman.shah":"UA6RJ8BMF", "sehar.rafiq":"UHH5SQ0RJ", "shahid.abbas": "U51912SS3", "muhammad.nouman":"U011WJXSQAG"}
       
        tok = dic[name]
        print(tok)   
       
        
        
        
                
        resp = main_database.DbModifyQuery("""update plugin_permit_status set permission_status = 'True', granted_by = '{2}', granted_till = '{3}'::timestamp, granted_at = '{4}'::timestamp, permitted_time = '{5}'::time where username = '{0}' And  plugin = '{1}' """.format(name, pluginname, usname, date, now, time)) 
        print ("""update plugin_permit_status set permission_status = 'True', granted_by = '{2}', granted_till = '{3}'::timestamp, granted_at = '{4}'::timestamp, permitted_time = '{5}'::time where username = '{0}' And  plugin = '{1}' """.format(name, pluginname, usname, date, now, time))            
        slack_token = 'xoxp-170652456870-670938564210-901381953591-29cf0d56fc0f0685856affff7ae3cd0a'
        sc = SlackClient(slack_token)

        sc.api_call(
                    "chat.postMessage",
                    channel="{0}".format(tok),
                    text="""Petitioner : {0}    Plugin Name Permission : {1}
                     Premission granted by : {2}""".format(name, pluginname, usname)
                )        

        return "Update Successfully"
         
        
                  
        
        

    def on_get(self, req, resp):
        params = req.params
        resp.media = self._handleQuery(params)

    def on_post(self, req, resp):
        params = req.media
        resp.media = self._handleQuery(params)


class chartdata:
    _required_params = []
    _dot_string = '-----'
    dir = os.path.dirname(__file__)

    def _handleQuery(self, provided_params):
        print("1234",provided_params)
        main_database.refreshDbConenction()
        _required_params = self._required_params
        # Checking whether we are getting all the required parameters. Incomplete parameters will result in an error
        all_params_provided = all([False if param not in provided_params else True for param in _required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        if not all_params_provided:
            return {'Error': 'Missing Parameter. Make Sure all parameters are present. Valid parameters are '
                             '{0}'.format(', '.join(_required_params))}
      
       
       
        
        
        # resp = main_database.DbResultsQuery("""select id, username, plugin, permission_status, granted_at::varchar from plugin_permit_status""")
        # print ("""select id, username, plugin, permission_status, granted_at::varchar from plugin_permit_status""")
        resp = main_database.DbResultsQuery("""WITH foobar AS ( 
                            select user_plugin, (EXTRACT( HOUR FROM foo.usage::time)*60*60) + (EXTRACT( MINUTES FROM foo.usage::time) * 60) +
                            (EXTRACT( SECONDS FROM foo.usage::time)) as usage from
                            (SELECT concat(username,', ',plugin) as user_plugin, age(loggedout_at, loggedin_at) as usage
                            FROM plugin_logging where loggedin_at::date = CURRENT_DATE)  foo
                                )
                            SELECT 
                            json_agg(json_build_object(user_plugin, usage))
                            FROM 
                            foobar""")
        print ("""WITH foobar AS ( 
                            select user_plugin, (EXTRACT( HOUR FROM foo.usage::time)*60*60) + (EXTRACT( MINUTES FROM foo.usage::time) * 60) +
                            (EXTRACT( SECONDS FROM foo.usage::time)) as usage from
                            (SELECT concat(username,', ',plugin) as user_plugin, age(loggedout_at, loggedin_at) as usage
                            FROM plugin_logging where loggedin_at::date = CURRENT_DATE)  foo
                                )
                            SELECT 
                            json_agg(json_build_object(user_plugin, usage))
                            FROM 
                            foobar""")
        
        print(resp[0][0])
        dictp = defaultdict(int)
        dictp["category"] = ''
        for i in resp[0][0]:
            for key, value in i.items():
                if value == None:
                    print(key, value)
                    pass
                else:
                    dictp[key] += round(float(value/60))
        
        return dictp


    def on_get(self, req, resp):
        params = req.params
        resp.media = self._handleQuery(params)

    def on_post(self, req, resp):
        params = req.media
        resp.media = self._handleQuery(params)          


        
class chartdataall:
    _required_params = []
    _dot_string = '-----'
    dir = os.path.dirname(__file__)

    def _handleQuery(self, provided_params):
        print("1234",provided_params)
        main_database.refreshDbConenction()
        _required_params = self._required_params
        # Checking whether we are getting all the required parameters. Incomplete parameters will result in an error
        all_params_provided = all([False if param not in provided_params else True for param in _required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        if not all_params_provided:
            return {'Error': 'Missing Parameter. Make Sure all parameters are present. Valid parameters are '
                             '{0}'.format(', '.join(_required_params))}
      
       
       
        
        
        # resp = main_database.DbResultsQuery("""select id, username, plugin, permission_status, granted_at::varchar from plugin_permit_status""")
        # print ("""select id, username, plugin, permission_status, granted_at::varchar from plugin_permit_status""")
        resp = main_database.DbResultsQuery("""WITH foobar AS ( 
                            select user_plugin, (EXTRACT( HOUR FROM foo.usage::time)*60*60) + (EXTRACT( MINUTES FROM foo.usage::time) * 60) +
                            (EXTRACT( SECONDS FROM foo.usage::time)) as usage from
                            (SELECT concat(username,', ',plugin) as user_plugin, age(loggedout_at, loggedin_at) as usage
                            FROM plugin_logging) foo
                                )
                            SELECT 
                            json_agg(json_build_object(user_plugin, usage))
                            FROM 
                            foobar""")
        print ("""WITH foobar AS ( 
                            select user_plugin, (EXTRACT( HOUR FROM foo.usage::time)*60*60) + (EXTRACT( MINUTES FROM foo.usage::time) * 60) +
                            (EXTRACT( SECONDS FROM foo.usage::time)) as usage from
                            (SELECT concat(username,', ',plugin) as user_plugin, age(loggedout_at, loggedin_at) as usage
                            FROM plugin_logging) foo
                                )
                            SELECT 
                            json_agg(json_build_object(user_plugin, usage))
                            FROM 
                            foobar""")
        
        print(resp[0][0])
        dictp = defaultdict(int)
        dictp["category"] = ''
        for i in resp[0][0]:
            for key, value in i.items():
                if value == None:
                    print(key, value)
                    pass
                else:
                    dictp[key] += round(float(value/60))
        
        return dictp


    def on_get(self, req, resp):
        params = req.params
        resp.media = self._handleQuery(params)

    def on_post(self, req, resp):
        params = req.media
        resp.media = self._handleQuery(params)  


class completevideo:
    _required_params = []
    _dot_string = '-----'
    dir = os.path.dirname(__file__)

    def _handleQuery(self, provided_params):
        
        main_database.refreshDbConenction()
        _required_params = self._required_params
        # Checking whether we are getting all the required parameters. Incomplete parameters will result in an error
        all_params_provided = all([False if param not in provided_params else True for param in _required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        if not all_params_provided:
            return {'Error': 'Missing Parameter. Make Sure all parameters are present. Valid parameters are '
                             '{0}'.format(', '.join(_required_params))}
      
       
       
        
        
        # resp = main_database.DbResultsQuery("""select id, username, plugin, permission_status, granted_at::varchar from plugin_permit_status""")
        # print ("""select id, username, plugin, permission_status, granted_at::varchar from plugin_permit_status""")
        resp = main_database.DbResultsQuery("""select foo.file_dir_name from
                                                        (select distinct(file_dir_name)
                                                        from video_track_points
                                                        where file_dir_name ilike '%172.16.66.88%' and
                                                        datetime ::date >= '2020-01-01' and datetime ::date <= '2020-02-28'
                                                        and completion_status = 'true' group by file_dir_name,datetime::date ) as foo
                                                        left outer join
                                                        (select distinct(file_dir_name)
                                                        from video_track_points
                                                        where file_dir_name ilike '%172.16.66.88%' and
                                                        datetime ::date >= '2020-01-01' and datetime ::date <= '2020-02-28'
                                                        and completion_status = 'false' group by file_dir_name ) as foo1
                                                        on foo.file_dir_name = foo1.file_dir_name """)
        print ("""SELECT distinct(substring(file_dir_name from (length(file_dir_name)-position('/' in reverse(file_dir_name))+2) for length(file_dir_name))) from video_track_points 
                                                                where file_dir_name ilike '%88:%'  """)
        

       
        
        output = []
        for i in range(len(resp)): #Traversing through the main list
            for j in range (len(resp[i])): #Traversing through each sublist
                output.append(resp[i][j])
        return output


    def on_get(self, req, resp):
        params = req.params
        resp.media = self._handleQuery(params)

    def on_post(self, req, resp):
        params = req.media
        resp.media = self._handleQuery(params)

class filenamereturn:
    _required_params = ['name']
    _dot_string = '-----'
    dir = os.path.dirname(__file__)

    def _handleQuery(self, provided_params):
        print(provided_params)
        main_database.refreshDbConenction()
        _required_params = self._required_params
        # Checking whether we are getting all the required parameters. Incomplete parameters will result in an error
        all_params_provided = all([False if param not in provided_params else True for param in _required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        if not all_params_provided:
            return {'Error': 'Missing Parameter. Make Sure all parameters are present. Valid parameters are '
                             '{0}'.format(', '.join(_required_params))}
        
        name = provided_params['name'] if provided_params['name'] else None
        
        
        output = []
        resp = main_database.DbResultsQuery("""select distinct(file_dir_name) from video_track_points where file_dir_name ilike '%{0}%'""".format(name))
        print ("""select distinct(file_dir_name) from video_track_points where file_dir_name ilike '%{0}%'""".format(name))
        output = []
        for i in range(len(resp)): #Traversing through the main list
            for j in range (len(resp[i])): #Traversing through each sublist
                output.append(resp[i][j])
        return output[0]
        
             
       
        
    def on_get(self, req, resp):
        params = req.params
        resp.media = self._handleQuery(params)

    def on_post(self, req, resp):
        params = req.media
        resp.media = self._handleQuery(params)         

class monthlydata:
    _required_params = []
    _dot_string = '-----'
    dir = os.path.dirname(__file__)

    def _handleQuery(self, provided_params):
        print(provided_params)
        main_database.refreshDbConenction()
        _required_params = self._required_params
        # Checking whether we are getting all the required parameters. Incomplete parameters will result in an error
        all_params_provided = all([False if param not in provided_params else True for param in _required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        if not all_params_provided:
            return {'Error': 'Missing Parameter. Make Sure all parameters are present. Valid parameters are '
                             '{0}'.format(', '.join(_required_params))}
        
        
        
        
        
        resp = main_data.DbResultsQuery("""select * from public.fn_json_stats()""")
        
        
        return resp[0][0]
        
             
       
        
    def on_get(self, req, resp):
        params = req.params
        resp.media = self._handleQuery(params)

    def on_post(self, req, resp):
        params = req.media
        resp.media = self._handleQuery(params) 





api = falcon.API(middleware=[cors.middleware])
api.add_route('/daysdatasource', DaysDataSource())
api.add_route('/apidocumentation', ApiDocumentation())
api.add_route('/logsbydate', PoiOperationsByUser())
api.add_route('/returnsurveyrecords', ReturnSurveyRecords())
api.add_route('/pluginversion', Versioner())
api.add_route('/returngridrecords', ReturnGridStats())
api.add_route('/videoFrame', ReturnVideoSurveyImage())
api.add_route('/returnsurveydropitems', ReturnSurveyDropDownItems())
api.add_route('/returngridfeatures', ReturnGridFeatures())
api.add_route('/returnsurveydropitemsall', ReturnSurveyDropItemsToggleDisabled())
api.add_route('/returnsurveydetails', SurveyShowDetails())
api.add_route('/mapfitbounds', MapFitBounds())
api.add_route('/geocms/employeeprogress', ShowProgressEmployees())
api.add_route('/geocms/summarystatdatewise', SummaryStatsDateWise())
api.add_route('/geocms/checkuserpermissionpage', CheckUserPremissionPage())
api.add_route('/geocms/userpages', CheckUserPages())
api.add_route('/geocms/checktokenvalidity', CheckTokenValidity())
api.add_route('/geocms/surveyplanningrecords', SurveyPlanningRecords())
api.add_route('/geocms/returnemprogdropitem', ReturnEmProgDropItem())
api.add_route('/geocms/addcommentempeprogress', AddCommentEmployeeProgress())
api.add_route('/latlng', LatLng())

api.add_route('/SavePro', SavePriority())
api.add_route('/polygoon', polygoon())
api.add_route('/userip', userip())
api.add_route('/userdata', userdata())
api.add_route('/returngrid', returngrid())
api.add_route('/returndata', returndata())
api.add_route('/ReturnImage', ReturnImage())
api.add_route('/addressdata', addressdata())
api.add_route('/addressupdate', addressupdate())
api.add_route('/addressinsert', addressinsert())
api.add_route('/userreturn', userreturn())
api.add_route('/pluginupdate', pluginupdate())
api.add_route('/tabledata', tabledata())
api.add_route('/deleteuser', deleteuser())
api.add_route('/slacknoti', slacknoti())
api.add_route('/pluginreturn', pluginreturn())
api.add_route('/total', total())
api.add_route('/pluginupdate1', pluginupdate1())
api.add_route('/chartdata', chartdata())
api.add_route('/chartdataall', chartdataall())
api.add_route('/completevideo', completevideo())
api.add_route('/filenamereturn', filenamereturn())
api.add_route('/monthlydata', monthlydata())

# serve(api, host='172.16.130.69', port=8006)
# serve(api, host='172.16.130.57', port=8010)
serve(api, host='172.16.130.52', port=8012)
