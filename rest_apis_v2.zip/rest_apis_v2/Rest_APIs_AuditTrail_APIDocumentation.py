from waitress import serve
import falcon
from db_connector import DbConnect
from psycopg2.errorcodes import INTERNAL_ERROR
from dbConfiguration import DbConfig
from time import localtime
from falcon_cors import CORS
import datetime as dt
import requests, json
import xmltodict
from PyQt5.QtCore import *
from PyQt5.QtGui import QImage
from moviepy.video.io.VideoFileClip import VideoFileClip
import os
from io import BytesIO
from datetime import datetime
import time as tm
import uuid
from base64 import b64encode
from json import dumps
import configuration as conf
from psycopg2.errorcodes import INTERNAL_ERROR
import jwt
from jwt.exceptions import DecodeError

cors = CORS(allow_all_origins=True, allow_all_headers=True, allow_credentials_all_origins=True, allow_all_methods=True)

main_database = DbConfig('172.16.130.23', 'TPLMaps', '5432', 'qgis.plugin', 'assigncity')
if not main_database.ConnectDb():
    raise Exception('Cannot Connect To 23 Server')

# logs_database = DbConfig('172.16.14.61', 'TPLMaps-logs', '5432', 'qgis.plugin', 'assigncity')
logs_database = DbConfig('172.16.130.23', 'TPLMaps', '5432', 'qgis.plugin', 'assigncity')
if not logs_database.ConnectDb():
    raise Exception('Cannot Connect To 61  Server')


def generateToken():
    output = b64encode(bytes(uuid.uuid4().hex.encode('utf-8'))).decode()
    return output.rstrip('=')


not_authorized = QImage('notauthorized.png')
not_found = QImage('notfound.png')


def getImageStream(pixmap):
    # Converting the Pixmap into a Bytes Like Object for sending
    buffer = QBuffer()
    buffer.open(QBuffer.ReadWrite)
    # Quality Decreased to decrease image size drastically without much compromise of image quality
    pixmap.save(buffer, 'JPG', 80)
    # Read QByteArray containing PNG into a StringIO.
    bytes_io = BytesIO(buffer.data())
    stream_len = bytes_io.getbuffer().nbytes
    buffer.close()
    return bytes_io, stream_len


def check_token_valid(func):
    def inner(*args, **kwargs):
        params = args[1]
        if 'token' in params.keys():
            success = False
            try:
                if params['token'] == '191294D1D1CC44C684A3959EB9388':
                    success = True
                else:
                    resp = requests.post('http://172.16.44.80:8008/authentication/checktoken',
                                         json={'token': params['token']}).json()
                    success = resp['Success']
                    if not success:
                        return {"Error": "Invalid Token"}
            except:
                pass
            if success:
                return func(*args, **kwargs)
            return conf.unauthorized_error
        else:
            return func(*args, **kwargs)
    return inner


def api_logger(func):
    def log_requests(*args, **kwargs):

        req = args[1]
        resp = args[2]
        req_params = args[0]._required_params

        token = conf.no_token_req if "token" not in req_params else conf.token_req

        value = None
        url = req._cached_uri
        if req.env['REQUEST_METHOD'] == 'GET':
            value = req.params
        elif req.env['REQUEST_METHOD'] == 'POST':
            value = req.media
        try:
            source = conf.source_default if 'source' not in value.keys() else jwt.decode(value['source'], 'secret',
                                                                                         algorithms=['HS256'])['source']
        except DecodeError:
            source = conf.source_default

        try:
            value['token'] = value.pop('amp;token')
        except Exception as e:
            print(e)

        if 'token' not in value.keys() and token != conf.no_token_req:
            resp.media = {'Error': token}
            return value

        try:
            if token != conf.no_token_req or 'token' in value.keys():
                token = req.params['token']
            ip, typeof, url, body = (req.remote_addr, req.env['REQUEST_METHOD'], req.url, req.params)
        except:
            if token != conf.no_token_req or 'token' in value.keys():
                token = req.media['token']
            ip, typeof, url, body = (req.remote_addr, req.env['REQUEST_METHOD'], req.url, req.media)
        main_database = DbConnect(conf.host_23, conf.database_23, conf.port_23, conf.username_23, conf.password_23)
        main_database.ConnectDb()
        try:
            main_database.DbModifyQuery(
                """insert into api_logging(ip,request_type,arguments,token,url,source)values(%s,%s,%s,%s,%s,%s)""",
                (ip, typeof, json.dumps(body), token, url, source))
        except INTERNAL_ERROR:
            main_database.refreshDbConenction()
            main_database.DbModifyQuery(
                """insert into api_logging(ip,request_type,arguments,token,url,source)values(%s,%s,%s,%s,%s,%s)""",
                (ip, typeof, json.dumps(body), token, url, source))

        return func(*args, **kwargs)
    return log_requests


class DaysDataSource:
    logs_started = 2017
    main_database.refreshDbConenction()
    logs_database.refreshDbConenction()

    @staticmethod
    def _currentYear():
        return localtime().tm_year

    @staticmethod
    def _addedByYear(fid):
        resp = main_database.DbResultsQuery("""SELECT extract(year from added_time)::int as year FROM pois_level_one_logs 
        WHERE feature_id = %s AND extract(year from added_time) is not null""", (fid,))
        return resp[0][0] if resp else False

    def _handleQuery(self, id):
        count_dict = {
            'null': 0,
            'QA': 0,
            'Production': 0,
            'Deprecated': 0
        }
        try:
            start_year = self._addedByYear(id)
            if not start_year:
                start_year = self.logs_started
            end_year = self._currentYear()

            count_dict = {
                'null': 0,
                'QA': 0,
                'Production': 0,
                'Deprecated': 0
            }
            queries_years_except_end_year = []

            for year in range(start_year, end_year + 1):  # Added one to take the end_year into account
                # 2017 doesn't have an year attached to the table name
                logs_table_name = 'users_log' if year < 2018 else 'users_log_{0}'.format(year)

                final_response = {}
                if year != end_year:
                    query = """(SELECT replace(REGEXP_REPLACE(REGEXP_REPLACE(cast(new_record -> 'data_status' AS text), 
                    'QA_.*', 'QA'),'qa_.*', 'QA'), '"','') AS data_status,extract(epoch FROM operation_time) 
                    as operation_time 
                    FROM "{0}"
                    WHERE tbname LIKE '%{1}%' AND feature_id = {2}
                    ORDER BY operation_time)""".format(logs_table_name, 'poi', id)
                    queries_years_except_end_year.append(query)

                else:
                    # Executing the queries for previous years
                    if queries_years_except_end_year:
                        queries_years_except_end_year = ' UNION '.join(
                            queries_years_except_end_year) + ' ORDER BY operation_time'
                        response = logs_database.DbResultsQuery(queries_years_except_end_year)
                        for record in response:
                            data_status = record[0] if record[0] else 'null'
                            date_time = record[1]
                            final_response[date_time] = data_status

                    # Now executing this years query
                    query = "SELECT * FROM fn_logs_by_datasource_duration('{0}', {1})  ORDER BY operation_time".format(
                        'poi', id)
                    response = main_database.DbResultsQuery(query)
                    final_data_status = None
                    for record in response:
                        data_status = record[0]
                        date_time = record[1]
                        final_response[date_time] = data_status
                        final_data_status = data_status

                    if final_data_status:
                        now = tm.time() + 18000
                        final_response[now] = final_data_status

                    last_active_date = None
                    last_active_status = None
                    times = list(final_response.keys())
                    times.sort()

                    for time in times:
                        data_status = final_response[time]
                        if last_active_date:
                            days_passed = self.findDays(last_active_date, time)
                            if last_active_status == data_status:
                                count_dict[data_status] = count_dict[data_status] + days_passed
                            else:
                                count_dict[last_active_status] = count_dict[last_active_status] + days_passed

                        last_active_date = time
                        last_active_status = data_status

            count_dict = {key: abs(int(val)) for (key, val) in count_dict.items() if val}
            return count_dict
        except:
            return count_dict

    @staticmethod
    def findDays(min_date, max_date):
        return (max_date - min_date) / 86400.00

    @api_logger
    def on_get(self, req, resp):
        """Handles GET requests"""
        if 'id' not in req.params.keys():
            resp.media = {'Error': 'Provide Correct Arguments'}
            return
        id = req.params['id']
        resp.media = self._handleQuery(id)

    @api_logger
    def on_post(self, req, resp):
        """Handles POST requests"""
        if 'id' not in req.media.keys():
            resp.media = {'Error': 'Provide Correct Arguments'}
            return
        id = req.media['id']
        resp.media = self._handleQuery(id)


class ApiDocumentation:
    # List of all the required parameters in each request
    _required_params = ['name', 'request_type', 'category', 'endpoint', 'description', 'example', 'input_params',
                        'added_by', 'added_on', 'token']

    @api_logger
    def on_get(self, req, resp):
        """Handles Get Request"""
        main_database.refreshDbConenction()
        result = main_database.DbResultsQuery("select fn_get_api()")[0][0]
        if not result:
            result = {}
            for param in self._required_params:
                result[param] = ''
            result = [result]
        resp.media = result

    @api_logger
    def on_put(self, req, resp):
        """Handles Put Request"""
        main_database.refreshDbConenction()
        _required_params = self._required_params
        # Parameters provided to each request
        provided_params = req.media
        # Checking whether we are getting all the required parameters. Incomplete parameters will result in an error
        all_params_provided = all([False if param not in _required_params else True for param in _required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        if not all_params_provided:
            resp.media = {'Error': 'Missing Parameter. Make Sure all paramater are present. Valid Parameters are '
                                   '{0}'.format(', '.join(_required_params))}
            return
        # Inserting data into the database
        name = provided_params['name']
        request_type = provided_params['request_type']
        category = provided_params['category']
        endpoint = provided_params['endpoint']
        description = provided_params['description']
        example = provided_params['example']
        input_params = provided_params['input_params']
        added_by = provided_params['added_by']
        added_on = provided_params['added_on']

        main_database.DbModifyQuery(
            """INSERT INTO web_portal.web_api_details (name ,request_type ,category ,endpoint , description, 
            example, input_params, added_by, added_on)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)""",
            (name, request_type, category, endpoint, description, example, input_params, added_by, added_on)
        )


class PoiOperationsByUser:
    main_database.refreshDbConenction()
    logs_database.refreshDbConenction()
    logs_started = 2017

    def _currentYear(self):
        return localtime().tm_year

    def _addedByYear(self, fid):
        # return False
        resp = main_database.DbResultsQuery("""SELECT extract(year from added_time)::int as year FROM pois_level_one_logs 
            WHERE feature_id = %s AND extract(year from added_time) is not null""", (fid,))
        return resp[0][0] if resp else False

    def _handleQuery(self, fid):
        start_year = self._addedByYear(fid)
        if not start_year:
            start_year = self.logs_started
        end_year = self._currentYear()

        logs_by_date = {}
        for year in range(start_year, end_year + 1):  # Added one to take the end_year into account
            # 2017 doesn't have an year attached to the table name
            logs_table_name = 'users_log' if year < 2018 else 'users_log_{0}'.format(year)
            # We access the main database in case we are fetching from logs for the current year
            db_to_access = main_database if year == self._currentYear() else logs_database
            if year != end_year:
                query = """
                SELECT extract(epoch FROM operation_time::date)::bigint AS time_stamp, username, string_agg(operation,',') AS operations
                FROM
                (
                SELECT operation_time, username,
                CASE 
                WHEN (cast(new_record -> 'data_status' as text)= '"Deprecated"' AND cast(old_record -> 'data_status' as text) != '"Deprecated"') THEN 'Deprecated'
                WHEN (cast(new_record -> 'data_status' as text)= '"Production"' AND cast(old_record -> 'data_status' as text) != '"Production"') THEN 'Production'
                ELSE operation END AS operation
                FROM "{0}" 
                WHERE tbname LIKE '%{1}%' AND feature_id = {2} AND (new_record::text != old_record::text OR operation != 'UPDATE')
                ORDER BY operation_time, username
                ) tab1
                GROUP BY extract(epoch FROM operation_time::date), username
                Order by time_stamp;
                """.format(logs_table_name, 'poi', fid)
            else:
                query = """
                SELECT * FROM fn_logs_by_user_currentyear('{0}', {1})      
                """.format('poi', fid)
            logs = db_to_access.DbResultsQuery(query)
            if logs:
                for log in logs:
                    if not log:
                        continue
                    op_date = int(log[0])
                    username = log[1]
                    operation = log[2].split(',')
                    logs_by_date[op_date] = {username: operation}
        return logs_by_date

    @api_logger
    def on_get(self, req, resp):
        """Handles GET requests"""
        if 'id' not in req.params.keys():
            resp.media = {'Error': 'Provide Correct Arguments'}
            return
        fid = req.params['id']
        resp.media = self._handleQuery(fid)

    @api_logger
    def on_post(self, req, resp):
        """Handles POST requests"""
        if 'id' not in req.media.keys():
            resp.media = {'Error': 'Provide Correct Arguments'}
            return
        fid = req.media['id']
        resp.media = self._handleQuery(fid)


class ReturnSurveyRecords:
    # List of all the required parameters in each request
    _required_params = ['start_date', 'end_date', 'city', 'areas', 'surveyor', 'survey_type', 'priority', 'employee','token']

    @check_token_valid
    def _handleQuery(self, provided_params):
        print(provided_params)
        _required_params = self._required_params
        # Checking whether we are getting all the required parameters. Incomplete parameters will result in an error
        all_params_provided = all([False if param not in provided_params else True for param in _required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        if not all_params_provided:
            return {'Error': 'Missing Parameter. Make Sure all parameters are present. Valid parameters are '
                             '{0}'.format(', '.join(_required_params))}

        blank_response_surveyor = {
            "grid_ids": [
            ],
            "summary": [
                {
                    "placeit_housing": 0,
                    "placeit_pois": 0,
                    "road": 0,
                    "video_tracker": 0
                }
            ]
        }

        blank_response_digitizer = {
            "grid_ids": [
            ],
            "summary": [
                {
                    "scale_count": 0,
                    "poi_count": 0,
                    "carto_count": 0,
                    "house_count": 0,
                    "road_count": 0,
                }
            ]
        }

        start_date = provided_params['start_date'] if provided_params['start_date'] else None
        end_date = provided_params['end_date'] if provided_params['end_date'] else None
        city = provided_params['city'] if provided_params['city'] else None
        areas = provided_params['areas'] if provided_params['areas'] else None
        surveyor = provided_params['surveyor'] if provided_params['surveyor'] else None
        survey_type = provided_params['survey_type'] if provided_params['survey_type'] else None
        priority = provided_params['priority'] if provided_params['priority'] else None
        employee = provided_params['employee'] if provided_params['employee'] else None

        try:
            if not employee:
                raise Exception('Invalid')
            employee = employee.lower()
            if employee not in ('digitizer', 'surveyor'):
                raise Exception('Inavlid')

            if employee == 'surveyor':
                resp = main_database.DbResultsQuery("""
                                select fn_show_summary_stats(%s, %s, %s, %s, %s, %s, %s);
                            """, (start_date, end_date, city, areas, surveyor, survey_type, priority)
                                                    )
            else:
                resp = main_database.DbResultsQuery("""
                                select fn_show_summary_stats_digitizer(%s, %s, %s, %s, %s, %s, %s);
                            """, (start_date, end_date, city, areas, surveyor, survey_type, priority)
                                                    )
            final_resp = resp[0][0]
            if employee == 'digitizer':
                final_resp['grid_id'] = final_resp['array_agg']
                final_resp.pop('array_agg')
                final_resp['summary'] = {}
                for item in ('poi_count', 'scale_count', 'carto_count', 'house_count', 'road_count'):
                    final_resp['summary'][item] = final_resp[item]
                    final_resp.pop(item)

            grid_id = None
            grid_ids = final_resp['grid_id']
            if grid_ids:
                grid_id = []
                for id in grid_ids:
                    grid_id.append({'grid_id': id})
                final_resp['grid_id'] = grid_id
            final_resp['summary'] = [final_resp['summary']]
            print(final_resp)

            return final_resp
        except Exception as e:
            print(e)
            if employee == 'surveyor':
                return blank_response_surveyor
            else:
                return blank_response_digitizer

    @api_logger
    def on_get(self, req, resp):
        params = req.params
        output = self._handleQuery(params)
        if output == conf.unauthorized_error:
            resp.status = falcon.HTTP_401
        resp.media = output

    @api_logger
    def on_post(self, req, resp):
        params = req.media
        output = self._handleQuery(params)
        if output == conf.unauthorized_error:
            resp.status = falcon.HTTP_401
        resp.media = output


class ReturnGridStats:
    # List of all the required parameters in each request
    _required_params = ['start_date', 'end_date', 'city', 'areas', 'surveyor', 'survey_type', 'priority', 'id',
                        'employee','token']

    @check_token_valid
    def _handleQuery(self, provided_params):
        print(provided_params)
        _required_params = self._required_params
        # Checking whether we are getting all the required parameters. Incomplete parameters will result in an error
        all_params_provided = all([False if param not in provided_params else True for param in _required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        if not all_params_provided:
            return {'Error': 'Missing Parameter. Make Sure all parameters are present. Valid parameters are '
                             '{0}'.format(', '.join(_required_params))}

        blank_response = {
            "summary": [
                {
                    "gps_housing": 0,
                    "gps_poi": 0,
                    "placeit_housing": 0,
                    "placeit_pois": 0,
                    "road": 0,
                    "video_tracker": 0
                }
            ]
        }

        start_date = provided_params['start_date'] if provided_params['start_date'] else None
        end_date = provided_params['end_date'] if provided_params['end_date'] else None
        city = provided_params['city'] if provided_params['city'] else None
        areas = provided_params['areas'] if provided_params['areas'] else None
        surveyor = provided_params['surveyor'] if provided_params['surveyor'] else None
        survey_type = provided_params['survey_type'] if provided_params['survey_type'] else None
        priority = provided_params['priority'] if provided_params['priority'] else None
        id = provided_params['id'] if provided_params['id'] else None
        employee = provided_params['employee'] if provided_params['employee'] else None

        try:
            if not employee:
                raise Exception('Invalid')
            employee = employee.lower()
            if employee not in ('digitizer', 'surveyor'):
                raise Exception('Inavlid')

            if employee == 'surveyor':
                resp = main_database.DbResultsQuery("""
                                select fn_show_grid_stats(%s, %s, %s, %s, %s, %s, %s, %s);
                            """, (start_date, end_date, city, areas, surveyor, survey_type, priority, id))
            else:
                resp = main_database.DbResultsQuery("""
                                select fn_show_summary_stats_digitizer_grid(%s, %s, %s, %s, %s, %s, %s, %s);
                            """, (start_date, end_date, city, areas, surveyor, survey_type, priority, id)

                                                )
            final_resp = resp[0][0]
            print(final_resp)
            if employee == 'digitizer':
                final_resp.pop('array_agg')
                final_resp = {'summary': final_resp}

            final_resp['summary'] = [final_resp['summary']]
            print(final_resp)
            return final_resp
        except Exception as e:
            print(e)
            return blank_response

    @api_logger
    def on_get(self, req, resp):
        params = req.params
        output = self._handleQuery(params)
        if output == conf.unauthorized_error:
            resp.status = falcon.HTTP_401
        resp.media = output

    @api_logger
    def on_post(self, req, resp):
        params = req.media
        output = self._handleQuery(params)
        if output == conf.unauthorized_error:
            resp.status = falcon.HTTP_401
        resp.media = output


class Versioner:
    _required_params = ['name']

    def _handleQuery(self, params):
        # Do something here
        all_params_provided = all([False if param not in params else True for param in self._required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        if not all_params_provided:
            return {'Error': 'Missing Parameter. Make Sure all parameters are present. Valid parameters are '
                             '{0}'.format(', '.join(self._required_params))}
        try:
            response = requests.get("http://172.16.44.80:8081/tpl_plugin_repository.xml").text
        except:
            return {"version": 0.01}
        name = params['name']
        repository = json.loads(json.dumps(xmltodict.parse(response)))
        for plugin in repository['plugins']['pyqgis_plugin']:
            if plugin['@name'] == name:
                return {"version": plugin['@version']}
        return {'Error': 'Incorrect Plugin Name'}

    @api_logger
    def on_get(self, req, resp):
        params = req.params
        output = self._handleQuery(params)
        if output == conf.unauthorized_error:
            resp.status = falcon.HTTP_401
        resp.media = output

    @api_logger
    def on_post(self, req, resp):
        params = req.media
        output = self._handleQuery(params)
        if output == conf.unauthorized_error:
            resp.status = falcon.HTTP_401
        resp.media = output


class ReturnVideoSurveyImage:
    # List of all the required parameters in each request
    _required_params = ['id', 'token']
    _optional_params = ['width', 'height', 'frame']

    blank_response = {
        "Images": [
        ]
    }

    def checkParamsMissing(self, params):
        all_params_provided = all([False if param not in params else True for param in self._required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        if not all_params_provided:
            return {'Error': 'Missing Parameter. Make Sure all parameters are present. Valid parameters are '
                             '{0}'.format(', '.join(self._required_params))}
        return False

    def _parseVideo(self, videoPath):
        video = VideoFileClip(videoPath)
        date_time = os.path.basename(videoPath).split('.')[0].replace('VID_', '')
        try:
            date_time = dt.datetime.strptime(date_time, "%Y%m%d_%H%M%S")
        except:
            date_time = dt.datetime.strptime('_'.join(date_time.split('_')[1:]), "%Y%m%d_%H%M%S")
        return video, date_time.timestamp()

    def epochSecondToFrameNum(self, frame_sec, vid_st_time):
        seconds = frame_sec - vid_st_time
        if seconds > -1:
            return int(seconds)
        return None

    def _getVideo_Time(self, fid):
        try:
            main_database.refreshDbConenction()
            response = main_database.DbResultsQuery("SELECT file_dir_name, datetime "
                                                    "FROM video_track_points "
                                                    "WHERE id = %s", (fid,))[0]
            fileName = response[0]
            date_time = response[1].timestamp()
            response = None
            return fileName, date_time
        except:
            return None, None

    @check_token_valid
    def _handleQuery(self, provided_params):
        scaled_width = scaled_height = None
        params_missing = self.checkParamsMissing(provided_params)
        if params_missing:
            return params_missing
        pt_id = provided_params['id']
        if self._optional_params[0] in provided_params.keys() and self._optional_params[1] in provided_params.keys():
            scaled_width = provided_params[self._optional_params[0]]
            scaled_height = provided_params[self._optional_params[1]]
        frame_num = 1 if 'frame' not in provided_params.keys() else int(provided_params['frame'])
        fileName, date_time = self._getVideo_Time(pt_id)
        print(fileName, date_time, 'dile_date')
        if not fileName:
            print('here')
            # return {'Error': 'Provided Id has no associated Video File'}
            return getImageStream(not_found)
        if not date_time:
            # return {'Error': 'Provided Id has no associated Time'}
            return getImageStream(not_found)
        # Fetching Video Object along with the Video Start Ttime
        video, video_start_time = self._parseVideo(fileName)
        if frame_num > video.fps:
            return getImageStream(not_found)
        # Getting frame to fetch
        frame_time = self.epochSecondToFrameNum(frame_sec=date_time, vid_st_time=video_start_time)
        if not frame_time:
            # return {'Error': 'Provided Id has no associated Frame'}
            return getImageStream(not_found)
        if frame_time == 1:
            frame = video.get_frame(frame_time)
        else:
            frame = [x for x in video.subclip(frame_time, frame_time + 1).iter_frames()][frame_num - 1]

        # Video attributes
        width = video.w
        height = video.h
        bytesPerLine = 3 * width
        # Converting the image provided by the library into a valid Image
        pix = QImage(frame, width, height, bytesPerLine, QImage.Format_RGB888)
        if scaled_height and scaled_width:
            pix = pix.scaled(int(scaled_width), int(scaled_height))
        video.close()
        return getImageStream(pix)

    @api_logger
    def on_get(self, req, resp):
        params = req.params
        bla = self._handleQuery(params)
        if not bla or isinstance(bla, dict):
            bla = getImageStream(not_authorized)
        resp.content_type = 'image/jpeg'
        resp.stream, resp.stream_len = bla

    @api_logger
    def on_post(self, req, resp):
        params = req.media
        bla = self._handleQuery(params)
        if not bla or isinstance(bla, dict):
            resp.media = bla
            return
        elif not bla:
            bla = getImageStream(not_authorized)
        resp.content_type = 'image/jpeg'
        resp.stream, resp.stream_len = bla


class ReturnSurveyDropDownItems:
    _required_params = ['date_from', 'date_to', 'areas', 'city', 'layers', 'priority', 'surveyor_name', 'employee','token']

    _dot_string = '-----'

    @check_token_valid
    def _handleQuery(self, provided_params):
        print(provided_params)
        main_database.refreshDbConenction()
        _required_params = self._required_params
        # Checking whether we are getting all the required parameters. Incomplete parameters will result in an error
        all_params_provided = all([False if param not in provided_params else True for param in _required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        if not all_params_provided:
            return {'Error': 'Missing Parameter. Make Sure all parameters are present. Valid parameters are '
                             '{0}'.format(', '.join(_required_params))}

        blank_response = {
            "areas": [self._dot_string],
            "city": [self._dot_string],
            "layers": [self._dot_string],
            "priority": [self._dot_string],
            "surveyor_name": [self._dot_string]
        }
        date_from = provided_params['date_from'] if provided_params['date_from'] else None
        date_to = provided_params['date_to'] if provided_params['date_to'] else None
        areas = provided_params['areas'] if provided_params['areas'] else self._dot_string
        city = provided_params['city'] if provided_params['city'] else self._dot_string
        layers = provided_params['layers'] if provided_params['layers'] else self._dot_string
        priority = provided_params['priority'] if provided_params['priority'] else self._dot_string
        surveyor_name = provided_params['surveyor_name'] if provided_params['surveyor_name'] else self._dot_string
        employee = provided_params['employee'] if provided_params['employee'] else None


        try:
            if not employee:
                raise Exception('Invalid')
            employee = employee.lower()
            if employee not in ('digitizer', 'surveyor'):
                raise Exception('Inavlid')

            if employee == 'surveyor':
                resp = main_database.DbResultsQuery(
                    """select fn_summary_grids_drop_down(%s, %s, %s, %s, %s, %s, %s, 'City');
                    """, (date_from, date_to, city, areas, surveyor_name, layers, priority)
                )
            else:
                resp = main_database.DbResultsQuery(
                    """select fn_summary_grids_drop_down_digitizer(%s, %s, %s, %s, %s, %s, %s);
                    """, (date_from, date_to, city, areas, surveyor_name, layers, priority)
                )
            final_resp = resp[0][0]

            # Split areas into list, sorting it and adding a dashed entry
            final_areas = []
            if employee == 'digitizer':
                final_resp['areas'] = final_resp['area']
                final_resp.pop('area')
            if final_resp['areas']:
                final_resp['areas'] = [area.split(',') for area in final_resp['areas']]
            else:
                final_resp['areas'] = []
            for areas in final_resp['areas']:
                final_areas.extend(areas)
            final_areas = list(set(tuple(final_areas)))
            final_resp['areas'] = final_areas
            final_resp['areas'].sort()
            final_resp['areas'] = [self._dot_string] + final_resp['areas']

            # Doing the same with layers
            if employee == 'digitizer':
                final_resp['layers'] = final_resp['team']
                final_resp.pop('team')
            if employee == 'surveyor':
                final_resp['layers'] = final_resp['layers'].split(',')
            if not final_resp['layers']:
                final_resp['layers'] = []
            final_resp['layers'].sort()
            final_resp['layers'] = [self._dot_string] + final_resp['layers']
            # Cities
            if not final_resp['city']:
                final_resp['city'] = []
            final_resp['city'].sort()
            final_resp['city'] = [self._dot_string] + final_resp['city']
            # Surveyor Name
            if employee == 'digitizer':
                final_resp['surveyor_name'] = final_resp['digitizer']
                final_resp.pop('digitizer')
            if not final_resp['surveyor_name']:
                final_resp['surveyor_name'] = []
            final_resp['surveyor_name'] = list(set(tuple(final_resp['surveyor_name'])))
            final_resp['surveyor_name'].sort()
            final_resp['surveyor_name'] = [self._dot_string] + final_resp['surveyor_name']
            # priority
            if not final_resp['priority']:
                final_resp['priority'] = []
            final_resp['priority'].sort()
            final_resp['priority'] = [self._dot_string] + final_resp['priority']
            return final_resp
        except Exception as e:
            return blank_response

    @api_logger
    def on_get(self, req, resp):
        params = req.params
        output = self._handleQuery(params)
        if output == conf.unauthorized_error:
            resp.status = falcon.HTTP_401
        resp.media = output

    @api_logger
    def on_post(self, req, resp):
        params = req.media
        output = self._handleQuery(params)
        if output == conf.unauthorized_error:
            resp.status = falcon.HTTP_401
        resp.media = output


class ReturnGridFeatures:
    # _required_params = ['date_from', 'date_to', 'areas', 'city', 'layers', 'priority', 'surveyor_name']
    _required_params = ['date_from', 'date_to', 'surveyor', 'survey_type', 'grid', 'employee','token']
    # Survey Type possible values :
    # Pois
    # House
    # SV
    _dot_string = '-----'

    @check_token_valid
    def _handleQuery(self, provided_params):
        main_database.refreshDbConenction()
        _required_params = self._required_params
        # Checking whether we are getting all the required parameters. Incomplete parameters will result in an error
        all_params_provided = all([False if param not in provided_params else True for param in _required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        if not all_params_provided:
            return {'Error': 'Missing Parameter. Make Sure all parameters are present. Valid parameters are '
                             '{0}'.format(', '.join(_required_params))}

        blank_response = {
        }

        date_from = provided_params['date_from'] if provided_params['date_from'] else None
        date_to = provided_params['date_to'] if provided_params['date_to'] else None
        surveyor = provided_params['surveyor'] if provided_params['surveyor'] else self._dot_string
        survey_type = provided_params['survey_type'] if provided_params['survey_type'] else self._dot_string
        grid = provided_params['grid'] if provided_params['grid'] else None
        employee = provided_params['employee'] if provided_params['employee'] else None

        try:
            if not employee:
                raise Exception('Invalid')
            employee = employee.lower()
            if employee not in ('digitizer', 'surveyor'):
                raise Exception('Inavlid')

            if employee == 'surveyor':
                resp = main_database.DbResultsQuery(
                    """select fn_portal_show_data(%s, %s, %s, %s, %s)
                    """, (date_from, date_to, surveyor, survey_type, grid)
                )
            else:
                surveyor = surveyor if surveyor else self._dot_string
                grid = grid if grid else self._dot_string
                survey_type = survey_type if survey_type else self._dot_string
                resp = main_database.DbResultsQuery(
                    """select fn_show_details_digitizer_latest(%s, %s, null, null, %s, null,  null, %s, %s)
                    """, (date_from, date_to, surveyor, grid, survey_type)
                )

            records = resp[0][0]
            if not records:
                raise Exception('Empty Response')
        except:
            return blank_response

        final_resp = []
        for record in records:
            geojson_feature = {
                "type": "Feature",
                "properties": {},
                "geometry": {}
            }
            geojson_feature['properties'] = {key: attribute for key, attribute in record.items() if key != 'geom'}
            geojson_feature['geometry'] = json.loads(record['geom'])
            final_resp.append(geojson_feature)
        print(final_resp)
        return final_resp

    @api_logger
    def on_get(self, req, resp):
        params = req.params
        to_send = self._handleQuery(params)
        if to_send == conf.unauthorized_error:
            resp.status = falcon.HTTP_401
            resp.media = to_send
            return
        resp.media = to_send

    @api_logger
    def on_post(self, req, resp):
        params = req.media
        to_send = self._handleQuery(params)
        if to_send == conf.unauthorized_error:
            resp.status = falcon.HTTP_401
            resp.media = to_send
            return
        resp.media = to_send


class ReturnSurveyDropItemsToggleDisabled:
    _required_params = ['city', 'employee','token']
    _dot_string = '-----'
    blank_response = {
        "areas": [_dot_string],
        "city": [_dot_string],
        "layers": [_dot_string],
        "priority": [_dot_string],
        "surveyor_name": [_dot_string]
    }

    @check_token_valid
    def _handleQuery(self, provided_params):
        print(provided_params)
        main_database.refreshDbConenction()
        _required_params = self._required_params
        # Checking whether we are getting all the required parameters. Incomplete parameters will result in an error
        all_params_provided = all([False if param not in provided_params else True for param in _required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        if not all_params_provided:
            return {'Error': 'Missing Parameter. Make Sure all parameters are present. Valid parameters are '
                             '{0}'.format(', '.join(_required_params))}

        city = provided_params['city'] if provided_params['city'] else None
        employee = provided_params['employee'] if provided_params['employee'] else None

        try:
            if not employee:
                raise Exception('Invalid')
            employee = employee.lower()
            if employee not in ('digitizer', 'surveyor'):
                raise Exception('Inavlid')

            if employee == 'surveyor':
                resp = main_database.DbResultsQuery(
                    """select fn_drop_down_without_toggle(%s)
                    """, (city,)
                )
            else:
                resp = main_database.DbResultsQuery(
                    """select fn_summary_grids_drop_down_digitizer_without_toggle(%s)    
                    """, (city,)
                )
            final_resp = resp[0][0]
            if not final_resp:
                raise Exception('Empty Response')
        except:
            return self.blank_response

        # Split areas into list, sorting it and adding a dashed entry
        if city != self._dot_string:
            final_areas = []
            final_resp['areas'] = [area.split(',') for area in final_resp['areas']]
            for areas in final_resp['areas']:
                final_areas.extend(areas)
            final_areas = list(set(tuple(final_areas)))
            final_resp['areas'] = final_areas
            final_resp['areas'].sort()
            final_resp['areas'] = [self._dot_string] + final_resp['areas']
        else:
            final_resp['areas'] = [self._dot_string]
        # Doing the same with layers
        final_resp['layers'].sort()
        final_resp['layers'] = [self._dot_string] + final_resp['layers']

        # Cities
        # final_resp['city'].sort()
        final_resp['city'] = [self._dot_string] + final_resp['city']

        # Surveyor Name
        final_resp['surveyor_name'] = list(set(tuple(final_resp['surveyor_name'])))
        final_resp['surveyor_name'].sort()

        final_resp['surveyor_name'] = [self._dot_string] + final_resp['surveyor_name']
        # priority
        final_resp['priority'].sort()
        final_resp['priority'] = [self._dot_string] + final_resp['priority']
        return final_resp

    @api_logger
    def on_get(self, req, resp):
        params = req.params
        to_send = self._handleQuery(params)
        if to_send == conf.unauthorized_error:
            resp.status = falcon.HTTP_401
            resp.media = to_send
            return
        resp.media = to_send

    @api_logger
    def on_post(self, req, resp):
        params = req.media
        to_send = self._handleQuery(params)
        if to_send == conf.unauthorized_error:
            resp.status = falcon.HTTP_401
            resp.media = to_send
            return
        resp.media = to_send


class SurveyShowDetails:
    _required_params = ['date_from', 'date_to', 'areas', 'city', 'layers', 'priority', 'surveyor_name', 'id',
                        'employee','token']
    _dot_string = '-----'
    header_names_surveyors = ['Grid ID', 'Date', 'PlaceIT POI', 'PlaceIT Housing', 'Roads', 'SV Survey', 'GPS POI',
                              'GPS House', 'Surveyor']
    header_names_digitizers = ['Grid ID', 'Date', 'POIs', 'Roads', 'House', 'Scale', 'Carto', 'Team', 'City',
                               'Area', 'Digitizer']

    @check_token_valid
    def _handleQuery(self, provided_params):
        print(provided_params)
        main_database.refreshDbConenction()
        _required_params = self._required_params
        # Checking whether we are getting all the requiredreturnsurveydropitemsall parameters. Incomplete parameters will result in an error
        all_params_provided = all([False if param not in provided_params.keys() else True for param in _required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        print([param if param not in provided_params.keys() else True for param in _required_params])
        if not all_params_provided:
            return {'Error': 'Missing Parameter. Make Sure all parameters are present. Valid parameters are '
                             '{0}'.format(', '.join(_required_params))}
        date_from = provided_params['date_from'] if provided_params['date_from'] not in [None, '', 'null'] else None
        date_to = provided_params['date_to'] if provided_params['date_to']  not in [None, '', 'null'] else None
        areas = provided_params['areas'] if provided_params['areas'] else self._dot_string
        city = provided_params['city'] if provided_params['city'] else self._dot_string
        layers = provided_params['layers'] if provided_params['layers'] else self._dot_string
        priority = provided_params['priority'] if provided_params['priority'] else self._dot_string
        surveyor_name = provided_params['surveyor_name'] if provided_params['surveyor_name'] else self._dot_string
        employee = provided_params['employee'] if provided_params['employee'] else None
        id = provided_params['id'] if provided_params['id'] not in [None, '', 'null'] else None

        blank_response = {
            "total": 0,
            "totalNotFiltered": 0,
            "rows": []
        }

        try:
            if not employee:
                raise Exception('Invalid')
            employee = employee.lower()
            if employee not in ('digitizer', 'surveyor'):
                raise Exception('Invalid')
            if date_from and isinstance(date_from, str):
                date_from = datetime.strptime(date_from, '%m/%d/%Y').date()
            if date_to and isinstance(date_to, str):
                date_to = datetime.strptime(date_to, '%m/%d/%Y').date()
            if employee == 'surveyor':
                resp = main_database.DbResultsQuery(
                    """select fn_show_details(%s, %s, %s, %s, %s, %s, %s, %s)
                    """, (date_from, date_to, city, areas, surveyor_name, layers, priority, id)
                )
            else:

                resp = main_database.DbResultsQuery(
                    """select fn_see_details_digitizer(%s, %s, %s, %s, %s,  %s, %s, %s)
                    """, (date_from, date_to, city, areas, surveyor_name, layers, priority, id)
                )
            final_resp = resp[0][0]
            if not final_resp:
                raise Exception('Empty Response')
        except:
            return blank_response

        final_response = blank_response
        final_response['rows'] = final_resp
        # final_response['results'] = final_resp
        final_resp = None
        return final_response

    @api_logger
    def on_get(self, req, resp):
        params = req.params
        output = self._handleQuery(params)
        if output == conf.unauthorized_error:
            resp.status = falcon.HTTP_401
        resp.media = output

    @api_logger
    def on_post(self, req, resp):
        params = req.media
        output = self._handleQuery(params)
        if output == conf.unauthorized_error:
            resp.status = falcon.HTTP_401
        resp.media = output


class ShowProgressEmployees:
    _required_params = ['user', 'token']
    _optional_params = ['name', 'start_date', 'end_date', 'comments', 'designation']
    _dot_string = '-----'
    _page_list_items_to_database_entries_map_comments = {
        _dot_string: None,
        'Added': 'Not Null',
        'Not Added': 'Null'
    }

    def setDefaultValues(self, prov_params):
        _optional_params_default_values = {
            'name': None,
            'start_date': (datetime.now() - dt.timedelta(days=1)).date(),
            'end_date': (datetime.now() - dt.timedelta(days=1)).date(),
            'comments': None,
            'designation': None
        }

        for option in self._optional_params:
            if option in prov_params.keys():
                _optional_params_default_values.pop(option)
        return _optional_params_default_values

    def _handleQuery(self, provided_params):
        main_database.refreshDbConenction()
        try:
            provided_params['token'] = provided_params.pop('amp;token')
        except Exception as e:
            print(e)
        provided_params = {**provided_params, **self.setDefaultValues(provided_params)}
        _required_params = self._required_params
        # Checking whether we are getting all the required parameters. Incomplete parameters will result in an error
        all_params_provided = all([False if param not in provided_params else True for param in _required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        blank_response = {
            "total": 0,
            "totalNotFiltered": 0,
            "rows": []
        }

        if not all_params_provided:
            return {'Error': 'Missing Parameter. Make Sure all parameters are present. Valid parameters are '
                             '{0}'.format(', '.join(_required_params))}

        start_date = provided_params['start_date'] if provided_params['start_date'] not in [None, 'null'] else None
        end_date = provided_params['end_date'] if provided_params['end_date'] not in [None, 'null'] else None
        name = provided_params['name'].rstrip().lstrip() if provided_params['name'] not in [None, 'null',
                                                                                            self._dot_string] else None
        comments = provided_params['comments'].rstrip().lstrip() if provided_params['comments'] not in [None,
                                                                                                        'null',
                                                                                                        self._dot_string] else None
        designation = provided_params['designation'].rstrip().lstrip() if provided_params['designation'] not in [None,
                                                                                                                 'null',
                                                                                                                   self._dot_string] else None
        user = provided_params['user']
        try:
            token = provided_params['token']
        except:
            token = provided_params['amp;token']

        if start_date and isinstance(start_date, str):
            start_date = datetime.strptime(start_date, '%m/%d/%Y').date()
        if end_date and isinstance(start_date, str):
            end_date = datetime.strptime(end_date, '%m/%d/%Y').date()
        if comments:
            comments = self._page_list_items_to_database_entries_map_comments[comments]

        try:
            try:
                user_id = main_database.DbResultsQuery("select fn_check_api(%s)", (token, ))[0][0]['user_id']
            except:
                user_id = None
            if not user_id:
                raise Exception('Error in function fn_check_api')
            resp = main_database.DbResultsQuery(

                """SELECT fn_webportal_show_employee_progress(%s, %s, %s, %s, %s, %s)""",
                (name, start_date, end_date, comments, designation, user_id))
            # print("""SELECT fn_webportal_show_employee_progress(%s, %s, %s, %s, %s, %s)""" %
            #       (name, start_date, end_date, comments, designation, user_id))
            final_resp = resp[0][0]
            if not final_resp:
                raise Exception('Empty Response')
            for num in range(0, len(final_resp)):
                final_resp[num]['No.'] = num + 1
                final_resp[num]['comment_status'] = 'Added' if bool(final_resp[num]['comments']) else 'Not Added'
        except Exception as e:
            print(e)
            main_database.refreshDbConenction()
            return blank_response
        for item in range(len(final_resp)):
            final_resp[item]['date'] = tm.strftime("%d %b %y", tm.strptime(final_resp[item]['date'], '%Y-%m-%d'))
        final_response = blank_response
        final_response['rows'] = final_resp
        final_response['total'] = len(final_resp)
        final_response['totalNotFiltered'] = len(final_resp)
        print(final_response)
        final_resp = None
        return final_response

    @api_logger
    def on_get(self, req, resp):
        params = req.params
        output = self._handleQuery(params)
        if output == conf.unauthorized_error:
            resp.status = falcon.HTTP_401
        resp.media = output

    @api_logger
    def on_post(self, req, resp):
        params = req.media
        output = self._handleQuery(params)
        if output == conf.unauthorized_error:
            resp.status = falcon.HTTP_401
        resp.media = output


class ReturnEmProgDropItem:
    _required_params = []
    _optional_params = ['name', 'start_date', 'end_date', 'comments', 'designation']
    _dot_string = '-----'
    # _url = "http://172.16.44.80:8010/geocms/employeeprogress"
    _url = "http://172.16.44.80:8010/geocms/employeeprogress"

    _page_list_items_to_database_entries_map_comments = {
        _dot_string: None,
        'Added': 'Not Null',
        'Not Added': 'Null'
    }

    def setDefaultValues(self):
        _optional_params_default_values = {
            'name': None,
            'start_date': None,
            'end_date': None,
            'comments': None,
            'designation': None
        }
        return _optional_params_default_values

    @check_token_valid
    def _handleQuery(self, provided_params):
        main_database.refreshDbConenction()
        provided_params = {**self.setDefaultValues(), **provided_params}
        _required_params = self._required_params
        # Checking whether we are getting all the required parameters. Incomplete parameters will result in an error
        all_params_provided = all([False if param not in provided_params else True for param in _required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        blank_response = {
            "url": self._url,
            "user": [self._dot_string],
            "comments": [self._dot_string],
            "level": [self._dot_string]
        }
        if not all_params_provided:
            return {'Error': 'Missing Parameter. Make Sure all parameters are present. Valid parameters are '
                             '{0}'.format(', '.join(_required_params))}

        start_date = provided_params['start_date'] if provided_params['start_date'] not in [None, 'null'] else None
        end_date = provided_params['end_date'] if provided_params['end_date'] not in [None, 'null'] else None
        name = provided_params['name'].rstrip().lstrip() if provided_params['name'] not in [None, 'null',
                                                                                            self._dot_string] else None
        comments = provided_params['comments'].rstrip().lstrip() if provided_params['comments'] not in [None,
                                                                                                        'null',
                                                                                                        self._dot_string] else None
        designation = provided_params['designation'].rstrip().lstrip() if provided_params['designation'] not in [None,
                                                                                                                 'null',
                                                                                                                 self._dot_string] else None
        if start_date and isinstance(start_date, str):
            start_date = datetime.strptime(start_date, '%m/%d/%Y').date()
        if end_date and isinstance(start_date, str):
            end_date = datetime.strptime(end_date, '%m/%d/%Y').date()
        if comments:
            try:
                comments = self._page_list_items_to_database_entries_map_comments[comments]
            except:
                return blank_response
        print(provided_params)
        try:
            resp = main_database.DbResultsQuery(
                """SELECT fn_web_portal_search_populate_stats(%s, %s, %s, %s, %s)""",
                (start_date, end_date, designation, name, comments))
            final_resp = resp[0][0]
            if not final_resp:
                raise Exception('Empty Response')
            if not final_resp['comments']:
                final_resp['comments'] = [final_resp['comments']]
            comments_lst = [self._dot_string]
            for comment in final_resp['comments']:
                comments = [x for x in self._page_list_items_to_database_entries_map_comments.keys()
                            if self._page_list_items_to_database_entries_map_comments[x] == comment][0]
                comments_lst.append(comments)

            final_resp['comments'] = comments_lst
            final_resp['url'] = self._url

            for key in blank_response.keys():
                if key not in ['comments', 'url']:
                    final_resp[key] = [self._dot_string] + final_resp[key]
        except:
            main_database.refreshDbConenction()
            return blank_response
        return final_resp

    @api_logger
    def on_get(self, req, resp):
        params = req.params
        output = self._handleQuery(params)
        if output == conf.unauthorized_error:
            resp.status = falcon.HTTP_401
        resp.media = output

    @api_logger
    def on_post(self, req, resp):
        params = req.media
        output = self._handleQuery(params)
        if output == conf.unauthorized_error:
            resp.status = falcon.HTTP_401
        resp.media = output


class AddCommentEmployeeProgress:
    _required_params = ['ids', 'comment', 'user']
    _optional_params = []

    @check_token_valid
    def _handleQuery(self, provided_params):
        main_database.refreshDbConenction()
        _required_params = self._required_params
        # Checking whether we are getting all the required parameters. Incomplete parameters will result in an error
        all_params_provided = all([False if param not in provided_params else True for param in _required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        error_response = {
            "Error": None
        }
        if not all_params_provided:
            return {'Error': 'Missing Parameter. Make Sure all parameters are present. Valid parameters are '
                             '{0}'.format(', '.join(_required_params))}

        ids = provided_params['ids'] if provided_params['ids'] not in [None, 'null'] else None
        comment = provided_params['comment'] if provided_params['comment'] not in [None, 'null'] else None
        user = provided_params['user']

        if not ids:
            print({'Error': 'Provide valid inputs. Null ids are not allowed'})
            return {'Error': 'Provide valid inputs. Null ids are not allowed'}

        if not comment:
            comment = None

        if isinstance(ids, int):
            ids = [ids]
        else:
            ids = ids.split(',')

        for id in ids:
            try:
                try:
                    prev_comment = main_database.DbResultsQuery(
                        "SELECT comments FROM web_portal.general_monitoring where id = %s",
                        (id,))[0][0]
                except Exception as e:
                    prev_comment = None

                operation = 'INSERT' if not prev_comment else 'UPDATE'
                prev_comment = {'comments': prev_comment}
                new_comment = {'comments': comment}
                resp = main_database.DbResultsQueryForFunction(
                    """SELECT * FROM fn_web_portal_update_comments(%s, %s)""",
                    (id, comment))
                print('resp', resp)
                if resp[0][0] != 'done':
                    raise Exception(resp[0][0])

                prev_comment = dumps(prev_comment) if prev_comment is not None else prev_comment
                new_comment = dumps(new_comment) if new_comment is not None else new_comment

                main_database.DbModifyQuery("""INSERT INTO users_log_2019
                (tbname, username, operation, operation_time, feature_id, new_record, old_record, application, log_date)
                VALUES ('general_monitoring', %s, %s, now(), %s, %s, %s, 'Geo-CMS', now()::date)""",
                                            (user, operation, id, new_comment, prev_comment))
            except Exception as e:
                print(e)
                error_response['Error'] = str(e)
                main_database.refreshDbConenction()
                return error_response
        return {'Success': 'Ok'}

    @api_logger
    def on_get(self, req, resp):
        params = req.params
        output = self._handleQuery(params)
        if output == conf.unauthorized_error:
            resp.status = falcon.HTTP_401
        resp.media = output

    @api_logger
    def on_post(self, req, resp):
        params = req.media
        output = self._handleQuery(params)
        if output == conf.unauthorized_error:
            resp.status = falcon.HTTP_401
        resp.media = output


class SummaryStatsDateWise:
    _required_params = ['start_date', 'end_date','token']
    _optional_params = []
    _dot_string = '-----'


    def setDefaultValues(self):
        now = datetime.now().date() - dt.timedelta(days=7)
        start = now - dt.timedelta(days=now.weekday())
        end = start + dt.timedelta(days=6)

        _optional_params_default_values = {
            'start_date': start,
            'end_date': end
        }
        return _optional_params_default_values

    @check_token_valid
    def _handleQuery(self, provided_params):
        main_database.refreshDbConenction()
        if 'start_date' in provided_params.keys() and not provided_params['start_date']:
            provided_params.pop('start_date')
        if 'end_date' in provided_params.keys() and not provided_params['end_date']:
            provided_params.pop('end_date')
        print('start', provided_params)
        provided_params = {**self.setDefaultValues(), **provided_params}
        _required_params = self._required_params
        # Checking whether we are getting all the required parameters. Incomplete parameters will result in an error
        all_params_provided = all([False if param not in provided_params else True for param in _required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        blank_response = {
            "date": {
                "from": None,
                "to": None
            },
            "all_stats": {
                "All Images Added": 0,
                "All POIS digitized": 0,
                "VS Completed Data": 0,
                "VS all data": 0,
                "VS remaining data": 0
            },
            "carto": {
                "Carto Digitized": 0,
                "Carto Target": 0
            },
            "house": {
                "House Digitized": 0,
                "House Target": 0
            },
            "pois": {
                "Pois Digitized": 0,
                "Pois Target": 0
            },
            "roads": {
                "Roads Digitized": 0,
                "Roads Target": 0
            },
            "scale": {
                "Scale Digitized": 0,
                "Scale Target": 0
            },
            "video_survey": {
                "Completed VS": 0,
                "Total VS": 0
            }
        }
        if not all_params_provided:
            return {'Error': 'Missing Parameter. Make Sure all parameters are present. Valid parameters are '
                             '{0}'.format(', '.join(_required_params))}

        start_date = provided_params['start_date'] if provided_params['start_date'] not in [None, 'null', ''] else None
        end_date = provided_params['end_date'] if provided_params['end_date'] not in [None, 'null', ''] else None
        if start_date and isinstance(start_date, str):
            start_date = datetime.strptime(start_date, '%m/%d/%Y').date()
        if end_date and isinstance(end_date, str):
            end_date = datetime.strptime(end_date, '%m/%d/%Y').date()
        print('asdasdasd',start_date, type(start_date))
        print('asdasdasd',end_date, type(end_date))
        start_date_back = '{0}/{1}/{2}'.format(start_date.month, start_date.day, start_date.year)
        end_date_back = '{0}/{1}/{2}'.format(end_date.month, end_date.day, end_date.year)
        try:
            print("""SELECT fn_web_portal_stats_summary_charts(%s, %s)""" %
                  (start_date, end_date))
            resp = main_database.DbResultsQuery(
                """SELECT * from fn_web_portal_stats_summary_charts(%s, %s)""",
                (start_date, end_date))
            final_resp = resp[0][0][0]
            if not final_resp:
                raise Exception('Empty Response')
            final_resp['all_stats']["All Images Added"] = round(final_resp['all_stats']["All Images Added"], 2)
            final_resp['all_stats']["All POIS digitized"] = round(final_resp['all_stats']["All POIS digitized"], 2)
            final_resp['all_stats']["VS Completed Data"] = round(final_resp['all_stats']["VS Completed Data"], 2)
            final_resp['all_stats']["VS all data"] = round(final_resp['all_stats']["VS all data"], 2)
            final_resp['all_stats']["VS remaining data"] = round(final_resp['all_stats']["VS remaining data"], 2)
            final_resp['date'] = {'from': start_date_back, 'to': end_date_back}

        except:
            main_database.refreshDbConenction()
            return blank_response
        return final_resp

    @api_logger
    def on_get(self, req, resp):
        params = req.params
        output = self._handleQuery(params)
        if output == conf.unauthorized_error:
            resp.status = falcon.HTTP_401
        resp.media = output

    @api_logger
    def on_post(self, req, resp):
        params = req.media
        output = self._handleQuery(params)
        if output == conf.unauthorized_error:
            resp.status = falcon.HTTP_401
        resp.media = output


class CheckUserPremissionPage:
    _required_params = ['page', 'user','token']
    _optional_params = []
    _dot_string = False

    def setDefaultValues(self):
        _optional_params_default_values = {
            'permission': False
        }
        return _optional_params_default_values

    @check_token_valid
    def _handleQuery(self, provided_params):
        main_database.refreshDbConenction()
        provided_params = {**self.setDefaultValues(), **provided_params}
        _required_params = self._required_params
        # Checking whether we are getting all the required parameters. Incomplete parameters will result in an error
        all_params_provided = all([False if param not in provided_params else True for param in _required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        blank_response = {
            "permission": False
        }
        if not all_params_provided:
            return {'Error': 'Missing Parameter. Make Sure all parameters are present. Valid parameters are '
                             '{0}'.format(', '.join(_required_params))}

        page = provided_params['page'] if provided_params['page'] not in [None, 'null'] else None
        user = provided_params['user'] if provided_params['user'] not in [None, 'null'] else None
        if not page and not user:
            raise Exception('Wrong Credentials')
        try:
            resp = main_database.DbResultsQuery(
                """select * from fn_web_portal_get_user_access(%s, %s)""",
                (page, user))
            print(resp)
            final_resp = resp[0][0]
            if not final_resp:
                raise Exception('Empty Response')
            final_resp['permission'] = final_resp['permission'] if final_resp['permission'] is not None else False
        except Exception as e:
            print(e)
            main_database.refreshDbConenction()
            return blank_response
        return final_resp

    @api_logger
    def on_get(self, req, resp):
        params = req.params
        output = self._handleQuery(params)
        if output == conf.unauthorized_error:
            resp.status = falcon.HTTP_401
        resp.media = output

    @api_logger
    def on_post(self, req, resp):
        params = req.media
        output = self._handleQuery(params)
        if output == conf.unauthorized_error:
            resp.status = falcon.HTTP_401
        resp.media = output


class CheckUserPages:
    _required_params = ['user','token']
    _optional_params = []
    _dot_string = False

    def setDefaultValues(self):
        _optional_params_default_values = {
            'pages_name_': False
        }
        return _optional_params_default_values

    @check_token_valid
    def _handleQuery(self, provided_params):
        main_database.refreshDbConenction()
        provided_params = {**self.setDefaultValues(), **provided_params}
        _required_params = self._required_params
        # Checking whether we are getting all the required parameters. Incomplete parameters will result in an error
        all_params_provided = all([False if param not in provided_params else True for param in _required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        blank_response = {
            "pages_name_": []
        }
        if not all_params_provided:
            return {'Error': 'Missing Parameter. Make Sure all parameters are present. Valid parameters are '
                             '{0}'.format(', '.join(_required_params))}

        user = provided_params['user'] if provided_params['user'] not in [None, 'null'] else None
        if not user:
            raise Exception('Wrong Credentials')
        try:
            resp = main_database.DbResultsQuery(
                """select fn_web_portal_get_users_pages(%s)""",
                (user,))
            final_resp = resp[0][0]
            if not final_resp['pages_name_']:
                raise Exception('Empty Response')
            if not final_resp:
                raise Exception('Empty Response')
        except Exception as e:
            print(e)
            main_database.refreshDbConenction()
            return blank_response
        return final_resp

    @api_logger
    def on_get(self, req, resp):
        params = req.params
        output = self._handleQuery(params)
        if output == conf.unauthorized_error:
            resp.status = falcon.HTTP_401
        resp.media = output

    @api_logger
    def on_post(self, req, resp):
        params = req.media
        output = self._handleQuery(params)
        if output == conf.unauthorized_error:
            resp.status = falcon.HTTP_401
        resp.media = output


class CheckTokenValidity:
    _required_params = ['user']
    _optional_params = []
    _dot_string = False

    def setDefaultValues(self):
        _optional_params_default_values = {
            'pages_name_': False
        }
        return _optional_params_default_values

    @check_token_valid
    def _handleQuery(self, provided_params):
        main_database.refreshDbConenction()
        provided_params = {**self.setDefaultValues(), **provided_params}
        _required_params = self._required_params
        # Checking whether we are getting all the required parameters. Incomplete parameters will result in an error
        all_params_provided = all([False if param not in provided_params else True for param in _required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        blank_response = {
            "pages_name_": []
        }
        if not all_params_provided:
            return {'Error': 'Missing Parameter. Make Sure all parameters are present. Valid parameters are '
                             '{0}'.format(', '.join(_required_params))}

        user = provided_params['user'] if provided_params['user'] not in [None, 'null'] else None
        if not user:
            raise Exception('Wrong Credentials')
        try:
            resp = main_database.DbResultsQuery(
                """select fn_web_portal_get_users_pages(%s)""",
                (user,))
            final_resp = resp[0][0]
            if not final_resp['pages_name_']:
                raise Exception('Empty Response')
            if not final_resp:
                raise Exception('Empty Response')
        except Exception as e:
            print(e)
            main_database.refreshDbConenction()
            return blank_response
        return final_resp

    @api_logger
    def on_get(self, req, resp):
        params = req.params
        output = self._handleQuery(params)
        if output == conf.unauthorized_error:
            resp.status = falcon.HTTP_401
        resp.media = output

    @api_logger
    def on_post(self, req, resp):
        params = req.media
        output = self._handleQuery(params)
        if output == conf.unauthorized_error:
            resp.status = falcon.HTTP_401
        resp.media = output


class SurveyPlanningRecords:
    _required_params = ['start_date', 'end_date', 'city', 'area','token']
    _optional_params = []
    _dot_string = '-----'

    @check_token_valid
    def _handleQuery(self, provided_params):
        main_database.refreshDbConenction()
        _required_params = self._required_params
        # Checking whether we are getting all the required parameters. Incomplete parameters will result in an error
        all_params_provided = all([False if param not in provided_params else True for param in _required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        blank_response = {
        }
        if not all_params_provided:
            return {'Error': 'Missing Parameter. Make Sure all parameters are present. Valid parameters are '
                             '{0}'.format(', '.join(_required_params))}

        start_date = provided_params['start_date'] if provided_params['start_date'] else None
        end_date = provided_params['end_date'] if provided_params['end_date'] else None
        city = provided_params['city'] if provided_params['city'] else None
        area = provided_params['area'] if provided_params['area'] else None

        if not start_date or not end_date or not city:
            return {'Error': 'Null values are not allowed for dates and city'}
        if not area:
            area = self._dot_string
        try:
            resp = main_database.DbResultsQuery(
                """select fn_survey_planning(%s, %s, %s, %s)""",
                (start_date, end_date, city, area))
            final_resp = resp[0][0]
            print(resp)
            if not final_resp:
                raise Exception('Empty Response')
        except Exception as e:
            print(e)
            main_database.refreshDbConenction()
            return blank_response
        return final_resp

    @api_logger
    def on_get(self, req, resp):
        params = req.params
        output = self._handleQuery(params)
        if output == conf.unauthorized_error:
            resp.status = falcon.HTTP_401
        resp.media = output

    @api_logger
    def on_post(self, req, resp):
        params = req.media
        output = self._handleQuery(params)
        if output == conf.unauthorized_error:
            resp.status = falcon.HTTP_401
        resp.media = output


api = falcon.API(middleware=[cors.middleware])
api.add_route('/daysdatasource', DaysDataSource())
api.add_route('/apidocumentation', ApiDocumentation())
api.add_route('/logsbydate', PoiOperationsByUser())
api.add_route('/returnsurveyrecords', ReturnSurveyRecords())
api.add_route('/pluginversion', Versioner())
api.add_route('/returngridrecords', ReturnGridStats())
api.add_route('/videoFrame', ReturnVideoSurveyImage())
api.add_route('/returnsurveydropitems', ReturnSurveyDropDownItems())
api.add_route('/returngridfeatures', ReturnGridFeatures())
api.add_route('/returnsurveydropitemsall', ReturnSurveyDropItemsToggleDisabled())
api.add_route('/returnsurveydetails', SurveyShowDetails())
api.add_route('/geocms/employeeprogress', ShowProgressEmployees())
api.add_route('/geocms/summarystatdatewise', SummaryStatsDateWise())
api.add_route('/geocms/checkuserpermissionpage', CheckUserPremissionPage())
api.add_route('/geocms/userpages', CheckUserPages())
api.add_route('/geocms/checktokenvalidity', CheckTokenValidity())
api.add_route('/geocms/surveyplanningrecords', SurveyPlanningRecords())


# serve(api, host='172.16.130.69', port=8006)
serve(api, host='172.16.130.57', port=8010)
