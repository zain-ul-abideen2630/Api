import flask
from flask import request, jsonify
import dbConfiguration as conf
import json
import datetime
from flask_cors import CORS
from threading import Timer
from time import time
from importlib import reload

import web_apis_timer_functions
records_last_updated = time() 


db_con = conf.DbConfig('172.16.130.23', 'TPLMaps', '5432', 'qgis.plugin', 'assigncity')
db_con.ConnectDb()

db_con1=conf.DbConfig('172.16.44.80','TPLMaps','5432','postgres','TplMapS123$')
db_con1.ConnectDb()

db_con_61 = conf.DbConfig('172.16.130.61','TPLMaps','5432','postgres','TplMapS123$')
db_con_61.ConnectDb()


def refreshConnection():
    global db_con
    print('Refreshing Database')
    db_con.releaseDbConnection()
    db_con.ConnectDb()

# Duration is in seconds


dbRefreshTimer = Timer(1 * 10, refreshConnection)
dbRefreshTimer.start()

app = flask.Flask(__name__)
app.config["DEBUG"] = True
CORS(app)


@app.route('/web_portal/layers_stats', methods=['GET'])
def layers_stats():
    try:
        result_={}
        if str(request.args['duration'])=='all':
            result_ = db_con.DbResultsQuery("select * from mvw_web_stats_all")[0][0]
        elif str(request.args['duration'])=='monthly':
            result_ = db_con.DbResultsQuery("select * from mvw_web_stats_monthly")[0][0]
            keys = list(result_.keys())
            for key in keys:
                result_[key] = result_[key] if result_[key] else 0

        return jsonify(result_)
    except Exception as e:
        print (e)
    db_con.refreshDbConenction()
    result_={
    "carto_count": 0,
    "video_survey_count":0,
    "poi_count": 0,
    "scale_count": 0,
    "crowdsource_count": 0,
    "road_count": 0
    }
    return jsonify(result_)


@app.route('/web_portal/search/active', methods=['GET'])
def home():
    global records_last_updated
    try:
        if (time() - records_last_updated) > (5 * 60):
            reload(web_apis_timer_functions)
            records_last_updated = time() 

        if 'employee' not in request.args:
            return 'Please add designation'
        employee = request.args['employee']
        return jsonify(web_apis_timer_functions.active_employees[employee])
    except:
        return 'No result'


@app.route('/web_portal/digitized_count', methods=['GET'])
def digitized_count():
    global records_last_updated
    try:
        if (time() - records_last_updated) > (5 * 60):
            print('Reloading')
            reload(web_apis_timer_functions)
            records_last_updated = time() 
        if 'layer' not in request.args:
            return 'Please add Layer Name '
        layer = request.args['layer']
        return jsonify(web_apis_timer_functions.digitized_count[layer])
    except:
        return 'No result'


@app.route('/web_portal/search/progress', methods=['GET'])
def employee_count():
    refreshConnection()
    try:
        if 'employee' in request.args and 'duration' in request.args:
            result = db_con.DbResultsQuery(
                "select fn_progress('" + str(request.args['employee']).replace("'", "").replace('"', '') + "','" + str(
                    request.args['duration']).replace("'", "").replace('"', '') + "')")
            if not result:
                return 'Add Designation correctly'
            else:
                result_ = result[0][0]
                final_result = {}
                for r in result_:
                    final_result[r.replace('_', ' ').title()] = result_[r]
                return (jsonify(final_result))
        else:
            db_con.DbModifyQuery("""commit;""")
            return ('Please add parameters')
    except:
        db_con.DbModifyQuery("""commit;""")


@app.route('/video_tracker/search/', methods=['GET'])
def live_id():
    if 'id' in request.args:
        try:
            result = db_con.DbResultsQuery(
            "select fn_get_live_id('" + str(request.args['id']).replace("'", "").replace('"', '') + "')")
        except Exception as e:
            result = db_con.DbResultsQuery(
            "select fn_get_live_id('" + str(request.args['id']).replace("'", "").replace('"', '') + "')")
        
        if not result:
            return 'False'
        else:
            result_ = result[0][0]
            time_ = {'time': str(datetime.datetime.now())}
            final_result = {}
            final_result.update({'Live id': result_})
            final_result.update({'Timestamp': time_})
            return jsonify(final_result)
    else:
        return ('Please add parameters')


@app.route('/web_portal/search/targets', methods=['GET'])
def surveyor_targets():
    refreshConnection()
    try:
        if 'surveyor_name' in request.args and 'start_date' in request.args and 'end_date' in request.args:
            try:
                result = db_con.DbResultsQuery(
                "select fn_surveyors_not_meeting_target('" + str(request.args['surveyor_name']).replace("'",
                                                                                                        "").replace('"',
                                                                                                                    '') + "','" + str(
                    request.args['start_date']).replace("'", "").replace('"', '') + "','" + str(
                    request.args['end_date']).replace("'", "").replace('"', '') + "')")
            except Exception as e:
                result = db_con.DbResultsQuery(
                "select fn_surveyors_not_meeting_target('" + str(request.args['surveyor_name']).replace("'",
                                                                                                        "").replace('"',
                                                                                                                    '') + "','" + str(
                    request.args['start_date']).replace("'", "").replace('"', '') + "','" + str(
                    request.args['end_date']).replace("'", "").replace('"', '') + "')")
            
            if not result:
                return 'Add Designation correctly'
            else:
                result_ = result[0][0]
                time_ = {'time': str(datetime.datetime.now())}
                final_result = {}
                final_result.update({'Progress Count': result_})
                final_result.update({'Timestamp': time_})
                return jsonify(final_result)
        else:
            return 'Please add parameters'
    except:
        return 'Please add parameters'


@app.route('/web_portal/surveyor_name', methods=['GET'])
def surveyor_name():
    try:
        result = db_con.DbResultsQuery("select fn_get_surveyor_name()")[0][0]
    except Exception as e:
        db_con.refreshConnection()
        result = db_con.DbResultsQuery("select fn_get_surveyor_name()")[0][0]
    return jsonify(result)


@app.route("/web_portal/search/targets/insert", methods=["POST"])
def insert_remarks():
    refreshConnection()
    try:
        params = json.loads(request.data.decode('UTF-8'))
        try:
            db_con.DbModifyQuery("""insert into web_portal.surveyor_feedback(surveyor_name,poi_count,house_count,video_survey,remarks,recorddate)values
        ('""" + params['surveyor_name'] + """',""" + params['poi_count'] + """,""" + params['house_count'] + """,""" +
                             params['video_survey']
                             + """,'""" + params['remarks'] + """','""" + params['recorddate'] + """')""")
        except Exception as e:
            db_con.DbModifyQuery("""insert into web_portal.surveyor_feedback(surveyor_name,poi_count,house_count,video_survey,remarks,recorddate)values
        ('""" + params['surveyor_name'] + """',""" + params['poi_count'] + """,""" + params['house_count'] + """,""" +
                             params['video_survey']
                             + """,'""" + params['remarks'] + """','""" + params['recorddate'] + """')""")
        
        return 'Successfully Inserted'
    except Exception as e:
        return e



@app.route('/select', methods=['GET'])
def selection_func():
    db_con.refreshDbConenction()
    db_con1.refreshDbConenction()
    required_params = ['start_date','end_date','layer_name','resource_name','operation']
    all_params_provided = all([False if param not in request.args else True for param in required_params])
    if all_params_provided:
        try:
            result = db_con_61.DbResultsQuery("select  fn_get_resource_features(%s,%s,%s,%s,%s)", (
            str(request.args['start_date']), str(request.args['end_date']), str(request.args['resource_name']),
            str(request.args['layer_name']),str(request.args['operation'])))
            print("select fn_get_resource_features(%s,%s,%s,%s,%s)", (
            str(request.args['start_date']), str(request.args['end_date']), str(request.args['resource_name']),
            str(request.args['layer_name']),str(request.args['operation'])))
            result=result[0][0]
            print('result', result)
            if not result:
                result=[]
            # result_1 = db_con1.DbResultsQuery("select  fn_get_resource_features(%s,%s,%s,%s,%s)", (
            # str(request.args['start_date']), str(request.args['end_date']), str(request.args['resource_name']),
            # str(request.args['layer_name']),str(request.args['operation'])))
            # print('result1', result_1)

            # result_1 = result_1[0][0]
            # if not result_1:
            result_1=[]


            result=result + result_1

            if not result:
                result = []
            return jsonify(result)

        except Exception as e:
            print(e)
            db_con.refreshDbConenction()
            return str(e)
    else:
        return 'No result'



@app.route('/select/count', methods=['GET'])
def selection_func_count():
    db_con.refreshDbConenction()
    db_con1.refreshDbConenction()
    required_params = ['start_date', 'end_date', 'layer_name', 'resource_name', 'operation']
    all_params_provided = all([False if param not in request.args else True for param in required_params])
    if all_params_provided:
        try:
            try:
                result = db_con_61.DbResultsQuery("select  fn_get_resource_features_count(%s,%s,%s,%s,%s)", (
            str(request.args['start_date']), str(request.args['end_date']), str(request.args['resource_name']),
            str(request.args['layer_name']), str(request.args['operation'])))

                result = result[0][0]
            except Exception as e:
                result = None

            if not result:
                result=0


            # try:
            #     result_1 = db_con1.DbResultsQuery("select  fn_get_resource_features_count(%s,%s,%s,%s,%s)", (
            # str(request.args['start_date']), str(request.args['end_date']), str(request.args['resource_name']),
            # str(request.args['layer_name']),str(request.args['operation'])))

            #     result_1=result_1[0][0]
            # except Exception as e:
            #     result_1 = None
            
            # if not result_1:
            result_1 = 0


            result=result + result_1

            if not result:
                result=0
            return str(result)

        except Exception as e:
            print(e)
            db_con.refreshDbConenction()
            return str(e)
            return 'Note: Parameters are not correct'
    else:
        return ('No result')

# app.run('172.16.130.98')
app.run(host='172.16.130.52', port=8004)
# app.run(host='172.16.130.69', port=8001)

