import dbConfiguration as conf
from threading import Timer

dbCon = conf.DbConfig('172.16.130.23', 'TPLMaps', '5432', 'qgis.plugin', 'assigncity')
dbCon.ConnectDb()

def refreshConnection():
    global dbCon
    dbCon.releaseDbConnection()
    dbCon.ConnectDb()






active_employees = {
    'digitizer': {
        "Active": 0,
        "Total": 0
    },
    'surveyor': {
        "Active": 0,
        "Total": 0
    },
    'analyst': {
        "Active": 0,
        "Total": 0
    },
}

digitized_count = {
    'poi': {
        "Active": 0,
        "Total": 0
    },
    'house': {
        "Active": 0,
        "Total": 0
    },
    'road': {
        "Active": 0,
        "Total": 0
    }
}




def activeEmployees():
    global active_employees
    for employee in active_employees.keys():
        result = dbCon.DbResultsQuery("select fn_active_surveyors_digitizers('{0}')".format(employee))
        try:
            result_ = result[0][0]
        except:
            continue
        final_result = {}
        for r in result_:
            key = r.title()
            value = result_[r]
            final_result[key] = value
        active_employees[employee] = final_result


def digitizedCount():
    global digitized_count
    for layer in digitized_count.keys():
        result = dbCon.DbResultsQuery("select fn_digitized_count('{0}')".format(layer))
        try:
            result_ = result[0][0]
        except:
            continue
        final_result = {}
        for r in result_:
            key = r.title()
            value = result_[r]
            final_result[key] = value if value else 0
        digitized_count[layer] = final_result

def refreshStat():
    print('Refreshing')
    activeEmployees()
    digitizedCount()


# while True:
    # sleep(1* 10)
    # refreshConnection()
    # refreshStat()

# Duration is in seconds
# dbRefreshTimer = Timer(5 * 60, refreshConnection)
# dbRefreshTimer.start()


# Stats refresh timer
# statsRefreshTimer = Timer(1 * 10, refreshStat)
# statsRefreshTimer.start()
# Fetching stats for the first time before the timer kicks in
refreshStat()
dbCon.releaseDbConnection()