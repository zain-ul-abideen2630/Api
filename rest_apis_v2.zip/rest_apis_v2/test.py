from waitress import serve
import falcon
from falcon_cors import CORS
from geojson import Feature, Point
import os
import requests


cors = CORS(allow_all_origins=True, allow_all_headers=True, allow_credentials_all_origins=True, allow_all_methods=True)


class LatLng:
    _required_params = ['points']
    _dot_string = '-----'
    dir = os.path.dirname(__file__)

    def _handleQuery(self, provided_params):
        _required_params = self._required_params
        # Checking whether we are getting all the required parameters. Incomplete parameters will result in an error
        all_params_provided = all([False if param not in provided_params else True for param in _required_params])
        # If we are not getting all the parameters, we gracefully exit with an error statement
        if not all_params_provided:
            return {'Error': 'Missing Parameter. Make Sure all parameters are present. Valid parameters are '
                             '{0}'.format(', '.join(_required_params))}

        points = provided_params['points']
        print(type(points))
        print(points)

        if type(points) == list:
            point1 = float(points[0])
            point2 = float(points[1])
            points = (point1, point2)

            print(points)
            points = Point(points)
            sample_dict = {"compound_address_parents": "Coordinates Location",
                           "lng": 73.2242557136262,
                           "fkey": 1001683319,
                           "name": "Coordinates Location",
                           "id": 5607569,
                           "lat": 34.16841091124579}
            sample_dict["lat"] = point1
            sample_dict["lng"] = point2
            # mypoint = Feature(geometry=points,lat=point1, lng=point2)
            # print(type(mypoint))
            # response = json.dumps([sample_dict])
            print(sample_dict)
            return [sample_dict]
        else:
            geo = requests.get('https://api1.tplmaps.com:8888/search?name='+points+'&location=33.72084085068317;73.0589069333577&apikey=%242a%2410%24bWCSBfSJFAHSsa8yD3g3Sej2QfUC2vGJp1VoJHsZFlw9gwl7XBST2').json()

            return(geo)

    def on_get(self, req, resp):
        params = req.params
        resp.media = self._handleQuery(params)

    def on_post(self, req, resp):
        params = req.media
        resp.media = self._handleQuery(params)


api = falcon.API(middleware=[cors.middleware])
api.add_route('/latlng', LatLng())
serve(api, host='172.16.135.27', port=5226)